<?php

/*
Plugin Name: Crypterium Shortcodes
Plugin URI: http://themeforest.net/user/Ninetheme
Description: Shortcodes for Ninetheme WordPress Themes - Crypterium Theme
Version: 1.4.3
Author: Ninetheme
Author URI: http://themeforest.net/user/Ninetheme
*/

require_once plugin_dir_path(__FILE__) . 'aq_resizer.php';


/*********************************************************
* PRICE POST TYPE
/********************************************************/

function crypterium_price_cpt(){
    $price_display = ot_get_option( 'crypterium_cpt3_display' );
    $price_slug = ot_get_option( 'cpt3' );
    $price_name = $price_slug != '' ? esc_html( $price_slug ) : 'Pricing';

    if ( 'off' != $price_display ){
        return esc_html( $price_name );
    } else {
        return false;
    }

}
add_action( 'after_setup_theme', 'crypterium_price_cpt' );

function crypterium_register_cpts_price(){

    if ( crypterium_price_cpt() ) {

    	/**
     * Post Type: Price Table.
     */

    	$labels = array(
    		"name" => __( crypterium_price_cpt()." Table", "nt-forester" ),
    		"singular_name" => __( crypterium_price_cpt()." Table", "nt-forester" ),
    		"menu_name" => __( crypterium_price_cpt()." Table", "nt-forester" ),
    		"all_items" => __( "All ".crypterium_price_cpt(), "nt-forester" ),
    		"add_new" => __( "Add ".crypterium_price_cpt(), "nt-forester" ),
    		"add_new_item" => __( "Add New ".crypterium_price_cpt(), "nt-forester" ),
    		"edit_item" => __( "Edit ".crypterium_price_cpt(), "nt-forester" ),
    	);

    	$args = array(
    		"label" => __( crypterium_price_cpt()." Table", "nt-forester" ),
    		"labels" => $labels,
    		"description" => "",
    		"public" => true,
    		"publicly_queryable" => true,
    		"show_ui" => true,
    		"delete_with_user" => false,
    		"show_in_rest" => true,
    		"rest_base" => "",
    		"rest_controller_class" => "WP_REST_Posts_Controller",
    		"has_archive" => true,
    		"show_in_menu" => true,
    		"show_in_nav_menus" => true,
    		"exclude_from_search" => false,
    		"capability_type" => "post",
    		"map_meta_cap" => true,
    		"hierarchical" => true,
    		"rewrite" => array( "slug" => strtolower(crypterium_price_cpt()), "with_front" => true ),
    		"query_var" => true,
    		"supports" => array( "title", "editor", "excerpt" ),
            "taxonomies" => array( "post_tag", strtolower(crypterium_price_cpt()) ),
    	);

    	register_post_type( strtolower(crypterium_price_cpt()), $args );


        /**
        * Taxonomy: Price Category.
        */

        $labels = array(
            "name" => __( crypterium_price_cpt()." Category", "nt-forester" ),
            "singular_name" => __( crypterium_price_cpt()." Categories", "nt-forester" ),
        );

        $args = array(
            "label" => __( crypterium_price_cpt()." Category", "nt-forester" ),
            "labels" => $labels,
            "public" => true,
            "publicly_queryable" => true,
            "hierarchical" => true,
            "show_ui" => true,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "query_var" => true,
            "rewrite" => array( 'slug' => strtolower(crypterium_price_cpt()), 'with_front' => true, 'hierarchical' => true ),
            "show_admin_column" => true,
            "show_in_rest" => true,
            "rest_base" => strtolower(crypterium_price_cpt()),
            "rest_controller_class" => "WP_REST_Terms_Controller",
            "show_in_quick_edit" => true,
        );
        register_taxonomy( strtolower(crypterium_price_cpt()), array( strtolower(crypterium_price_cpt()) ), $args );
    }
}

add_action( 'init', 'crypterium_register_cpts_price', 20 );



// plugin version number for body classes
function crypterium_plugin_version($classes) {
  $data = get_plugin_data( __FILE__ );
  $version = $data['Version'];
  $version =  'nt-shortcode-' . $version;
  $classes[] =  $version;
  return $classes;
}
add_filter('body_class','crypterium_plugin_version');

// word limiter
function crypterium_limit_words($string, $limit) {
	$words = explode(' ', $string);
	return implode(' ', array_slice($words, 0, $limit));
}

// element animation if have it
if ( ! function_exists( 'crypterium_aos' ) ) {
  function crypterium_aos( $aos, $delay, $duration, $offset, $easing,  $anchor, $placement, $once ) {

    if ( ( isset( $aos  ) ) && ( $aos  != '' ) ){

      $el_aos = ( isset( $aos       ) && $aos  	!= '' ) ? 'data-aos="'. $aos .'"' : '';
      $el_del = ( isset( $delay     ) && $delay != '' ) ? 'data-aos-delay="'. $delay .'"' : '';
			$el_eas = ( isset( $easing    ) && $easing != '' ) ? 'data-aos-easing="'. $easing .'"' : '';
      $el_dur = ( isset( $duration  ) && $duration != '' ) ? 'data-aos-duration="'. $duration .'"' : '';
      $el_off = ( isset( $offset    ) && $offset != '' ) ? 'data-aos-offset="'. $offset .'"' : '';
			$el_anc = ( isset( $anchor    ) && $anchor != '' ) ? 'data-aos-anchor="'. $anchor .'"' : '';
			$el_pla = ( isset( $placement ) && $placement != '' ) ? 'data-aos-placement="'. $placement .'"' : '';
			$el_once = ( isset( $once      ) && $once != '' ) ? 'data-aos-once="'. $once .'"' : '';

      $data = $el_aos . " " . $el_del . " " . $el_eas . " " . $el_dur . " " . $el_off . " " . $el_anc . " " . $el_pla . " " . $el_once;
      return $data;

    } else { return false; }

  }
}

// visual composer custom css class for design type
if ( ! function_exists( 'crypterium_vc_custom_css_class' ) ) {
  function crypterium_vc_custom_css_class( $var ) {
    $bg = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $var, ' ' ),  $atts );
    return $bg;
  }
}

// typography h1-h6, p elements
if ( ! function_exists( 'crypterium_element' ) ) {
    function crypterium_element( $text='Add your text', $tag='p', $class='', $lineh='', $size='', $color='', $transform='' ) {

		if ( ( isset( $text ) ) && ( $text != '' ) ) {

			$tags = array(
        'div' => array( 'class' => array(),	'id' => array() ),
        'ul' => array( 'class' => array(),	'id' => array() ),
        'li' => array( 'class' => array(),	'id' => array() ),
        'span' => array( 'class' => array(),	'id' => array() ),
        'i' => array( 'class' => array() ),
        'mark' => array(),
        'p' => array( 'class' => array() ),
        'b' => array(),
        'br' => array(),
        'strong'=> array(),
        'a' => array( 'href' => array(),'class' => array(),'title' => array() )
			);
			$text = wp_kses( $text, $tags );

			$el_tag = ( isset( $tag    ) && $tag  	!= '' ) ? $tag : '';
			$el_class = ( isset( $class  ) && $class  != '' ) ? ' class="'.esc_attr( $class ).'"' : '';
			$lineheight = ( isset( $lineh  ) && $lineh  != '' ) ? ' line-height:'.esc_attr( $lineh ).'!important;' 	: '';
			$fontsize = ( isset( $size   ) && $size   != '' ) ? ' font-size:'.esc_attr( $size ).'!important;' 	: '';
			$fontcolor = ( isset( $color  ) && $color  != '' ) ? ' color:'.esc_attr( $color ).'!important;' 		: '';
      $el_transform = ( isset( $transform   ) && $transform   != '' ) ? ' text-transform:'.esc_attr( $transform ).'!important;' 	: '';

      if ( $fontsize != '' || $fontcolor != '' || $lineheight != '' || $el_transform != '' ){
				$style = ' style="'.$fontsize.$fontcolor.$lineheight.$el_transform.'"';
			} else {
				$style = '';
			}

			if ( $el_tag != '' ){
				$element = '<'.$el_tag.''.$el_class.''.$style.'>'.$text.'</'.$el_tag.'>';
			} else {
				$element = $text;
			}

		} else {  return false; } // end $text

      return $element;
    } // end function
} // end function_exists

// icon function
if ( ! function_exists( 'crypterium_icon' ) ) {
    function crypterium_icon( $el_class='fa fa-pencil', $el_size='', $el_color='' ) {

		if ( ( isset( $el_class  ) ) && ( $el_class  != '' ) ){

			$class = ( isset( $el_class  ) && $el_class  != '' ) ? ' class="'.esc_attr( $el_class ).'"' : '';
			$size = ( isset( $el_size   ) && $el_size   != '' ) ? ' font-size:'.esc_attr( $el_size ).' !important;' : '';
			$color = ( isset( $el_color  ) && $el_color  != '' ) ? ' color:'.esc_attr( $el_color ).' !important;' : '';

			if ( $size != '' || $color != '' ){ 	$style = ' style="'.$size.$color.'"'; } else {  $style = '';  }

			$icon = '<i'.$class.''.$style.'></i>';

			return $icon;

		} else {  return false; }

    }
}

//button function
if ( ! function_exists( 'crypterium_btn' ) ) {
    function crypterium_btn(  $el_tag='a', $title='', $el_href='', $el_target='', $el_class='', $el_bg='', $el_color='', $el_icon=false ) {

  		if ( ( isset( $title ) ) && ( $title != '' ) ) {
      	$tag = ( isset( $el_tag    ) && $el_tag   != '' )  ? $el_tag : '';
  			$class = ( isset( $el_class  ) && $el_class  != '' ) 	? 	' class="'.esc_attr( $el_class ).'"' 		: '';
  			$bg = ( isset( $el_bg  ) && $el_bg   != '' ) 	? 	' background-color:'.esc_attr( $el_bg ).'!important;' : '';
  			$color = ( isset( $el_color  ) && $el_color  != '' ) 	? 	' color:'.esc_attr( $el_color ).'!important;' 		: '';
  			$href = ( isset( $el_href   ) && $el_href   != '' ) 	? 	' href="'.esc_url( $el_href ).'"' 			: '';
  			$target = ( isset( $el_target ) && $el_target != '' ) 	? 	' target="'.esc_attr( $el_target ).'"' 		: '';
  			$icon = ( $el_icon != '' ) 	? 	' <i class="'.esc_attr( $el_icon ).'"></i>' 		: '';
  			$style = ( $bg != '' || $color != '' ) ? ' style="'.$bg.$color.'"' : '';

  			$button = ( $title != '' ) ? '<'.$tag.' '.$class.''.$href.''.$target.''.$style.'>'.esc_html( $title ).''.$icon.'</'.$tag.'>' : '';

  			return $button;

  		}else{
  			return false;
  		} // end if $title

    }
}

// button function
if ( ! function_exists( 'crypterium_img' ) ) {
    function crypterium_img( $imgsrc='', $imgclass='', $imgwidth='200', $imgheight='200' ) {

		if ( ( isset( $imgsrc ) ) && ( $imgsrc != '' ) ) {

      // Gets url of the image
      $image = wp_get_attachment_url( $imgsrc,'full' );			// Gets the Image alt
			$image_alt = get_post_meta( $imgsrc, '_wp_attachment_image_alt', true );
			// Gets the image name with exstention
			$image_filename = basename ( get_attached_file( $imgsrc ) );
			// Gets the image name without exstention
			$image_title = get_the_title( $imgsrc );

			if (  $image_alt != '' ) {
				$imagealt = $image_alt;
			}else{
				$imagealt = $image_filename;
			}

      // Gets url of the image
			$img_src = ( isset( $imgsrc    ) && $imgsrc    != '' ) 	? 	' src="'.esc_url( $image ).'"' 			: '';
			$img_class = ( isset( $imgclass  ) && $imgclass  != '' ) 	? 	' class="'.esc_attr( $imgclass ).'"' 	: '';
			$img_width = ( isset( $imgwidth  ) && $imgwidth  != '' ) 	? 	' width="'.esc_attr( $imgwidth ).'"' 	: '';
			$img_height = ( isset( $imgheight ) && $imgheight != '' ) 	? 	' height="'.esc_attr( $imgheight ).'"' 	: '';
			$img_alt = ( $imagealt != '' ) ? ' alt="'.esc_attr( $imagealt ).'"' : '';

			$imageo = '<img'.$img_src . $img_class . $img_width . $img_height . $img_alt.'>';

			return $imageo;
		}
		else{
			return false;
		} // end imgsrc

  } // end crypterium_img
} // end function_exists

/*-----------------------------------------------------------------------------------*/
/*	HERO_HOME
/*-----------------------------------------------------------------------------------*/

function crypterium_home_hero( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"pattern" => '',
  	"img" => '',
  	"css" => '',
  	"count" => '',
  	"count_loop" => '',
  	"scroll" => '',
  	"s_text" => 'scroll down',
  	"title" => '',
  	"desc" => '',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($count_loop);
  $image = wp_get_attachment_url( $img,'full' );

  $out .= '<div id="start-screen" class="start-screen--light start-screen--style-1 crypterium_home_hero_shortcode '.crypterium_vc_custom_css_class($css).'">';
 		$out .= '<div class="start-screen__static-bg jarallax" data-speed="0.3" style="background-image: url('.$image.');">';
      $out .= '<img class="jarallax-img" src="'.$image.'" alt="hero" />';

      if ( $pattern !='hide' ){
   			$out .= '<div class="pattern" style="
   				background: -moz-linear-gradient(0deg, rgba(114,76,253,0.46) 0%, rgba(61,168,243,0.46) 100%);
   				background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(114,76,253,0.46)), color-stop(100%, rgba(61,168,243,0.46)));
   				background: -webkit-linear-gradient(0deg, rgba(114,76,253,0.46) 0%, rgba(61,168,243,0.46) 100%);
   				background: -o-linear-gradient(0deg, rgba(114,76,253,0.46) 0%, rgba(61,168,243,0.46) 100%);
   				background: -ms-linear-gradient(0deg, rgba(114,76,253,0.46) 0%, rgba(61,168,243,0.46) 100%);
   				background: linear-gradient(90deg, rgba(114,76,253,0.46) 0%, rgba(61,168,243,0.46) 100%);
   				">
   			</div>';
      }

 			$out .= '<div class="start-screen__content  text--center">';
 				$out .= '<div class="start-screen__content__inner">';
        $v_align = ( $count !='hide' ) ? 'col--xs-align-bottom'  : '';
          $out .= '<div class="grid grid--container  '.$v_align.'">';
 						$out .= '<div class="row row--xs-middle">';
 							$out .= '<div class="col col--lg-10">';

                if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='__title', $tlineh, $tsize, $tcolor ).''; }
                if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }

 								$out .= ''.do_shortcode( $content ).'';

 							$out .= '</div>';
 						$out .= '</div>';
 					$out .= '</div>'; // end grid--container';

          if ( $count !='hide' ){
   					$out .= '<div class="grid grid--container  col--xs-align-bottom">';
   						$out .= '<div class="facts">';
   							$out .= '<div class="__inner">';
   								$out .= '<div class="row row--xs-middle">';

                    foreach ( $loop as $item ) {

                      $el_from = ( isset( $item['from'] ) !='' ) ? 'data-from="'.$item['from'].'"'  : '';
                      $el_to = ( isset( $item['to'] ) !='' ) ? 'data-to="'.$item['to'].'"'  : '';
                      $el_dec = ( isset( $item['dec'] ) !='' ) ? 'data-decimals="'.$item['dec'].'"'  : '';
                      $el_bef = ( isset( $item['before'] ) !='' ) ? 'data-before="'.$item['before'].'"'  : '';
                      $el_af = ( isset( $item['after'] ) !='' ) ? 'data-after="'.$item['after'].'"'  : '';

                      $datas = array($el_from, $el_to, $el_dec, $el_bef, $el_af, );
                      $data = implode(" ", $datas);

                    	$out .= '<div class="col col--sm-4 col--md-4">';
   											$out .= '<div class="__item text--sm-left">';
   												$out .= '<span class="num js-count"  '. $data .'></span><br> '.$item['datatitle'].'';
   											$out .= '</div>';
   										$out .= '</div>';
                    }

   								$out .= '</div>';
   							$out .= '</div>';
   						$out .= '</div>';
   					$out .= '</div>'; // end grid--container
          }

 				$out .= '</div>';
 			$out .= '</div>';
 		$out .= '</div>';

 		if ( $scroll !='hide' ){ $out .= '<span class="scroll-discover hide show--md">'.$s_text.' <b></b></span>'; }

 	$out.='</div>';

	return $out;
}
add_shortcode('crypterium_home_hero_shortcode', 'crypterium_home_hero');

/*-----------------------------------------------------------------------------------*/
/*	HERO_HOME
/*-----------------------------------------------------------------------------------*/

function crypterium_home_farm_hero( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "btnlink" => '',
    "url" => '',
    "text" => '',
    "img" => '',
    "count" => '',
  	"count_loop" => '',
  	"title" => '',
  	"desc" => '',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
    "css" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($count_loop);
  $image = wp_get_attachment_url( $img,'full' );

  $out .= '<div id="start-screen" class="start-screen--light start-screen--style-8 crypterium_home_hero_fact_shortcode '.crypterium_vc_custom_css_class($css).'">';
  $out .= '<div class="start-screen__static-bg" style="background-image: url('.$image.');    background-position: center bottom;
    background-position: 50% 50%;
    background-repeat: no-repeat;
    -webkit-background-size: cover;
    background-size: cover;">';

  $out .= '<div class="start-screen__content">';
  $out .= '<div class="start-screen__content__inner">';
  $out .= '<div class="grid grid--container ">';
  $out .= '<div class="row row--xs-center">';
  $out .= '<div class="col col--md-7">';

  if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='__title', $tlineh, $tsize, $tcolor ).''; }

	$out .= '<div class="row  col-MB-40">';
  	$out .= '<div class="col col--lg-11 col--xl-9">';

      $out .= ''.do_shortcode( $content ).'';

      if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='div', $class='col-MB-25', $dlineh, $dsize, $dcolor ).''; }

    	$out .= '<div class="row row--xs-center">';
        if (  $btnlink != '' ){
          $out .= '<div class="col col--xs-auto">';
          	$out .= '<div class="row  col-MB-25"></div>';
              $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
              $btnlink = vc_build_link( $btnlink );
              $btn_title = $btnlink['title'];
              $btn_target = $btnlink['target'];
              $btn_href = $btnlink['url'];
              $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-5', $btnbg, $btncolor, $icon=false ).'';
          	$out .= '</div>';
          }
        if (  $text != '' ){
          	$out .= '<div class="col col--xs-auto">';
            	$out .= '<a class="btn-play" data-fancybox="" href="'. $url .'" style="margin-top: 20px;"><i></i>'. $text .'</a>';
          	$out .= '</div>';
          }
			$out .= '</div>'; // row row--xs-center

		$out .= '</div>'; // col col--lg-11 col--xl-9
	$out .= '</div>'; // row  col-MB-40

    if ( $count !='hide' ){
		$out .= '<div class="facts">';
			$out .= '<div class="__inner">';
				$out .= '<div class="row">';

        foreach ( $loop as $item ) {
            $el_from = ( isset( $item['from'] ) !='' ) ? 'data-from="'.$item['from'].'"'  : '';
            $el_to = ( isset( $item['to'] ) !='' ) ? 'data-to="'.$item['to'].'"'  : '';
            $el_dec = ( isset( $item['dec'] ) !='' ) ? 'data-decimals="'.$item['dec'].'"'  : '';
            $el_bef = ( isset( $item['before'] ) !='' ) ? 'data-before="'.$item['before'].'"'  : '';
            $el_af = ( isset( $item['after'] ) !='' ) ? 'data-after="'.$item['after'].'"'  : '';

            $datas = array($el_from, $el_to, $el_dec, $el_bef, $el_af, );
            $data = implode(" ", $datas);

          	$out .= '<div class="col col--xs-auto col--lg-4">';
  						$out .= '<div class="__item text--sm-left">';
  							$out .= '<span class="num js-count"  '. $data .'></span><br> '.$item['datatitle'].'';
  						$out .= '</div>';
  					$out .= '</div>';
          }

				$out .= '</div>';
			$out .= '</div>';
		$out .= '</div>';
    }

  $out .= '</div>';
  $out .= '</div>';
  $out .= '</div>';
  $out.='</div>';
  $out.='</div>';
  $out.='</div>';
  $out.='</div>';

	return $out;
}
add_shortcode('crypterium_home_farm_hero_shortcode', 'crypterium_home_farm_hero');

/*-----------------------------------------------------------------------------------*/
/*	Hero Agency
/*-----------------------------------------------------------------------------------*/

function crypterium_home_agency_hero( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "btnlink" => '',
    "video" => '',
    "url" => '',
    "text" => '',
    "img" => '',
  	"title" => '',
  	"desc" => '',
    "css" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($count_loop);
  $image = wp_get_attachment_url( $img,'full' );

  $out .= '<div id="start-screen"  data-speed="0.3" class="start-screen--light start-screen--style-9 jarallax crypterium_home_agency_hero_shortcode '.crypterium_vc_custom_css_class($css).'">
    <img class="jarallax-img lazy"  data-src="'.$image.'" alt="parallax" />
    <div class="pattern" style="
      background: -moz-linear-gradient(0deg, rgba(114,76,253,0.58) 0%, rgba(61,168,243,0.58) 100%);
      background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(114,76,253,0.58)), color-stop(100%, rgba(61,168,243,0.58)));
      background: -webkit-linear-gradient(0deg, rgba(114,76,253,0.58) 0%, rgba(61,168,243,0.58) 100%);
      background: -o-linear-gradient(0deg, rgba(114,76,253,0.58) 0%, rgba(61,168,243,0.58) 100%);
      background: -ms-linear-gradient(0deg, rgba(114,76,253,0.58) 0%, rgba(61,168,243,0.58) 100%);
      background: linear-gradient(90deg, rgba(114,76,253,0.58) 0%, rgba(61,168,243,0.58) 100%);">
    </div>

    <div class="start-screen__content">
    <div class="start-screen__content__inner">
    <div class="grid grid--container">
    <div class="row rrow--xs-center">
    <div class="col col--md-8 col--lg-7">';

      if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='__title', $tlineh, $tsize, $tcolor ).''; }

      $out .= '<div class="row  col-MB-40">
        <div class="col col--lg-11 col--xl-9">';

          $out .= ''.do_shortcode( $content ).'';

          if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='div', $class='col-MB-25', $dlineh, $dsize, $dcolor ).''; }

          if (  $btnlink != '' ){
            $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
            $btnlink = vc_build_link( $btnlink );
            $btn_title = $btnlink['title'];
            $btn_target = $btnlink['target'];
            $btn_href = $btnlink['url'];
            $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2', $btnbg, $btncolor, $icon=false ).'';
          }

        $out .= '</div>
      </div>
    </div>';

    if ( $video !='hideo' ){
      $out .= '<div class="col col--md-4 col--lg-5  text--center">
        <a class="btn-play" data-fancybox="" href="'. $url .'" style="margin-top: 40px;">
            <i></i><br>'. $text .'
          </a>
      </div>';
    }

  $out .= '
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
  ';

	return $out;
}
add_shortcode('crypterium_home_agency_hero_shortcode', 'crypterium_home_agency_hero');

/*-----------------------------------------------------------------------------------*/
/*	HERO_HOME_PROGRESS
/*-----------------------------------------------------------------------------------*/

function crypterium_home_hero_progress( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"btnlink" => '',
  	"btnlink2" => '',
  	"size" => 'progress--medium',
  	"pitems" => '',
    "bar" => '',
    "max" => '',
  	"scroll" => '',
    "s_text" => 'scroll down',
  	"title" => '',
  	"desc" => '',
    "img" => '',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
    "css" => '',
	), $atts) );

  $p_items = (array) vc_param_group_parse_atts($pitems);
  $image = wp_get_attachment_url( $img,'full' );

  $out .= '<div id="start-screen" class="start-screen--light start-screen--style-3 crypterium_home_hero_progress_shortcode '.crypterium_vc_custom_css_class($css).'">';
 		$out .= '<div class="start-screen__static-bg jarallax" data-speed="0.3" style="background-image: url('.$image.');">';
      $out .= '<img class="jarallax-img" src="'.$image.'" alt="'. get_the_title().'" />';

      $out .= '<div class="start-screen__content  text--center">';
				$out .= '<div class="start-screen__content__inner">';
					$out .= '<div class="grid grid--container">';
						$out .= '<div class="row row--xs-middle">';
							$out .= '<div class="col col--md-10 col--lg-9 col--xl-8">';

                if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='__title', $tlineh, $tsize, $tcolor ).''; }
                if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }

                $out .= '<div class="progress '. $size . '">';
                  $out .= '<div class="progress__inner">';
                    $out .= '<div class="__bar __bar--animate" style="width: '.$bar.'%"></div>';
                      foreach( $p_items as $item ) {
                        if ( isset( $item['percent_title'] ) !='' ){ $out .= '<span class="__label" style="left: '. esc_attr( $item['percent'] ) .'%"><strong>'. esc_html( $item['percent_title'] ) .'</strong></span>'; }
                      }
                    $out .= '<span class="__max-val"><strong>'.$max.'</strong></span>';
                  $out .= '</div>';
                $out .= '</div>'; // progress

 								$out .= ''.do_shortcode( $content ).'';

                                if (  $btnlink != '' OR $btnlink2 != '' ){  $out .= '<p style="margin-top:35px;">'; }

									if (  $btnlink != '' ){
										$btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
										$btnlink = vc_build_link( $btnlink );
										$btn_title = $btnlink['title'];
										$btn_target = $btnlink['target'];
										$btn_href = $btnlink['url'];
										$out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2', $btnbg, $btncolor, $icon=false ).'';
									}
									if (  $btnlink2 != '' ){
										$btnlink2 = ( $btnlink2 == '||' ) ? '' : $btnlink2;
										$btnlink2 = vc_build_link( $btnlink2 );
										$btn_title2 = $btnlink2['title'];
										$btn_target2 = $btnlink2['target'];
										$btn_href2 = $btnlink2['url'];
										$out .= ''.crypterium_btn( $tag='a', $btn_title2, $btn_href2, $btn_target2, $btnclass='custom-btn custom-btn--medium custom-btn--style-4', $btnbg2, $btncolor2, $icon=false ).'';
									}

								if (  $btnlink != '' OR $btnlink2 != '' ){  $out .= '</p>'; }

 							$out .= '</div>';
 						$out .= '</div>';
 					$out .= '</div>'; // end grid--container';

 				$out .= '</div>';
 			$out .= '</div>';
 		$out .= '</div>';

 		if ( $scroll !='hide' ){ $out .= '<span class="scroll-discover hide show--md">'.$s_text.' <b></b></span>'; }

 	$out.='</div>';

	return $out;
}
add_shortcode('crypterium_home_hero_progress_shortcode', 'crypterium_home_hero_progress');

/*-----------------------------------------------------------------------------------*/
/*	HERO_ICO
/*-----------------------------------------------------------------------------------*/

function crypterium_home_hero_ico( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"btnlink" => '',
  	"btnlink1" => '',
  	"img" => '',
  	"css" => '',
  	"count" => '',
  	"social_loop" => '',
  	"scroll" => '',
    "s_text" => 'scroll down',
  	"counttitle" => '',
  	"title" => '',
  	"desc" => '',
  	"align" => '',
  	"date" => '2018-08-12',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
  	"clineh" => '',
  	"csize" => '',
  	"ccolor" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($social_loop);
  $image = wp_get_attachment_url( $img,'full' );
  $el_align = ( $align !='' ) ? $align  : 'text--center';

  $out.='<div id="start-screen" class="start-screen--light start-screen--style-4 crypterium_home_hero_ico_shortcode '.crypterium_vc_custom_css_class($css).'">';
		$out.='<div class="start-screen__static-bg jarallax" data-speed="0.3" style="background-image: url('.$image.');">';
      $out .= '<img class="jarallax-img" src="'.$image.'" alt="parallax" />';
			$out.='<div class="start-screen__content  '.$el_align.'">';
				$out.='<div class="start-screen__content__inner">';
					$out.='<div class="grid grid--container">';
						$out.='<div class="row row--xs-middle">';
							$out.='<div class="col col--md-10 col--lg-8 col--xl-7">';

                $out .= ''.do_shortcode( $content ).'';

                if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='h2 __title', $tlineh, $tsize, $tcolor ).''; }
                if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }

								$out.='<p>';

                  if ( $btnlink != '' ){
                    $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
                    $btnlink = vc_build_link( $btnlink );
                    $btn_title = $btnlink['title'];
                    $btn_target = $btnlink['target'];
                    $btn_href = $btnlink['url'];
                    $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2 mt-20', $btnbg, $btncolor, $icon=false ).'';
                  }

                  if ( $btnlink1 != '' ){
                    $btnlink1 = ( $btnlink1 == '||' ) ? '' : $btnlink1;
                    $btnlink1 = vc_build_link( $btnlink1 );
                    $btn_title1 = $btnlink1['title'];
                    $btn_target1 = $btnlink1['target'];
                    $btn_href1 = $btnlink1['url'];
                    $out .= ''.crypterium_btn( $tag='a', $btn_title1, $btn_href1, $btn_target1, $btnclass='custom-btn custom-btn--medium custom-btn--style-4 mt-20', $btnbg, $btncolor, $icon=false ).'';
                  }

								$out.='</p>';

								$out.='<div class="social-btns">';
                                foreach ( $loop as $item ) {
                                    $out.='<a class="'.$item['icon'].'" target="_blank" href="'.$item['url'].'"></a>';
                                }
								$out.='</div>';

                if ( $counttitle !='' ){
                  $el_ct_align = ( $ct_align !='' ) ? $ct_align  : 'text--center';
                  $out .= ''.crypterium_element( $counttitle, $tag='p', $class=$el_ct_align, $clineh, $csize, $ccolor ).'';
                }

					 if ( $count !='hide' ){ $out.='<div class="countdown js-countdown" data-date="'.$date.'"></div>';  }

                $out .= '</div>';
              $out .= '</div>';
            $out .= '</div>'; // end grid--container


        $out .= '</div>';
      $out .= '</div>';
    $out .= '</div>';

    if ( $scroll !='hide' ){ $out .= '<span class="scroll-discover hide show--md">'.$s_text.' <b></b></span>'; }

  $out.='</div>';

	return $out;
}
add_shortcode('crypterium_home_hero_ico_shortcode', 'crypterium_home_hero_ico');


/*-----------------------------------------------------------------------------------*/
/*	HERO_ICO_2
/*-----------------------------------------------------------------------------------*/

function crypterium_home_hero_2_ico( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"btnlink" => '',
  	"btnlink1" => '',
    "size" => 'progress--small',
    "pitems" => '',
    "bar" => '',
    "soft" => '',
    "raised" => '',
    "max" => '',
  	"img" => '',
  	"img2" => '',
  	"scroll" => '',
    "s_text" => 'scroll down',
  	"title" => '',
  	"desc" => '',
  	"title2" => '',
  	"desc2" => '',
  	"desc3" => '',
  	"align" => '',
  	"vid_url" => '',
  	"count" => '',
  	"date" => '2018-08-12',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
  	"clineh" => '',
  	"csize" => '',
  	"ccolor" => '',
  	"css" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($pitems);
  $image = wp_get_attachment_url( $img,'full' );
  $el_align = ( $align !='' ) ? $align  : 'text--center';

  $out.='<div id="start-screen" class="start-screen--light start-screen--style-2 crypterium_home_hero_2_ico_shortcode '.crypterium_vc_custom_css_class($css).'">';
		$out.='<div class="start-screen__static-bg jarallax" data-speed="0.3" style="background-image: url('.$image.');">';
      $out .= '<img class="jarallax-img" src="'.$image.'" alt="parallax" />';

      $out.='<div class="start-screen__content ">';
				$out.='<div class="start-screen__content__inner">';
					$out.='<div class="grid grid--container">';
						$out.='<div class="row row--xs-center">';
							$out.='<div class="col col--md-7">';

                if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='__title', $tlineh, $tsize, $tcolor ).''; }
                if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }

                $out .= '<div class="row">';
									$out .= '<div class="col col--lg-11 col--xl-9">';
										$out .= '<div class="col-MB-25">';
									 $out .= ''.do_shortcode( $content ).'';
										$out .= '</div>';

										$out .= '<div class="row row--xs-center">';
											$out .= '<div class="col col--xs-auto">';
                        if ( $btnlink != '' ){
                          $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
                          $btnlink = vc_build_link( $btnlink );
                          $btn_title = $btnlink['title'];
                          $btn_target = $btnlink['target'];
                          $btn_href = $btnlink['url'];
                          $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2 mt-20', $btnbg, $btncolor, $icon=false ).'';
                        }
											$out .= '</div>';

											$out .= '<div class="col col--xs-auto">';
												$out .= '<a class="btn-play" data-fancybox href="'.$vid_url.'" style="margin-top: 20px;"><i></i>Video Presentation</a>';
											$out .= '</div>';
										$out .= '</div>';
									$out .= '</div>'; // end column
								$out .= '</div>'; // end row
								$out .= '</div>'; // end row

								$out .= '<div class="col hide--md col-MB-40"></div>';

                	$out .= '<div class="col col--md-5 col--xl-4 col--xl-offset-1">';
  									$out .= '<div class="sales">';
                      if ( $title2 !='' ){ $out .= ''.crypterium_element( $title2, $tag='h3', $class='__title', $tlineh, $tsize, $tcolor ).''; }
                      if ( $desc2 !='' ){ $out .= ''.crypterium_element( $desc2, $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }
                      if ( $count !='hide' ){ $out.='<div class="countdown js-countdown" data-date="'.$date.'"></div>';  }
                    $out .= '<div class="progress '. $size . '">';
                      $out .= '<div class="progress__inner">';
                        $out .= '<div class="__bar __bar--animate" style="width: '.$bar.'%"></div>';
                          foreach( $loop as $item ) {
                            if ( isset( $item['percent_title'] ) !='' ){ $out .= '<span class="__label" style="left: '. esc_attr( $item['percent'] ) .'%"><strong>'. esc_html( $item['percent_title'] ) .'</strong></span>'; }
                          }
                        $out .= '<span class="__max-val" style="line-height: 19px;"><strong>'.$max.'</strong></span>';
                      $out .= '</div>';

                        $out .= '<span class="soft-cap">'.$soft.'</span>';

  								 $out .= '<span class="note fl-r" style="padding-top: 8px">'.$raised.'</span>';
                    $out .= '</div>'; // progress

  									if ( $desc3 !='' ){ $out .= ''.crypterium_element( $desc3, $tag='p', $class='note', $dlineh, $dsize, $dcolor ).''; }

                    if ( $btnlink1 != '' ){
                      $btnlink1 = ( $btnlink1 == '||' ) ? '' : $btnlink1;
                      $btnlink1 = vc_build_link( $btnlink1 );
                      $btn_title1 = $btnlink1['title'];
                      $btn_target1 = $btnlink1['target'];
                      $btn_href1 = $btnlink1['url'];

                      $out .= '<p>'.crypterium_btn( $tag='a', $btn_title1, $btn_href1, $btn_target1, $btnclass='custom-btn custom-btn--style-5 wide buy-btn', $btnbg, $btncolor, $icon=false ).'</p>';
                    }

  									if ( isset( $img2 ) !='' ){ $out .= ''.crypterium_img( $img2, $imgclass='img-responsive', $imgwidth='', $imgheight='' ).''; }
  						 $out .= '</div>';
  					 $out .= '</div>'; // end column

                $out .= '</div>';
              $out .= '</div>';
            $out .= '</div>'; // end grid--container


        $out .= '</div>';
      $out .= '</div>';

    if ( $scroll !='hide' ){ $out .= '<span class="scroll-discover hide show--md">'.$s_text.' <b></b></span>'; }

  $out.='</div>';

	return $out;
}
add_shortcode('crypterium_home_hero_2_ico_shortcode', 'crypterium_home_hero_2_ico');


/*-----------------------------------------------------------------------------------*/
/*	HERO_ICO
/*-----------------------------------------------------------------------------------*/

function crypterium_home_hero_3_ico( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"btnlink" => '',
  	"img" => '',
  	"css" => '',
  	"scroll" => '',
    "s_text" => 'scroll down',
  	"title" => '',
  	"desc" => '',
  	"align" => '',
  	"date" => '2018-08-12',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
  	"clineh" => '',
  	"csize" => '',
  	"ccolor" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($social_loop);
  $image = wp_get_attachment_url( $img,'full' );
  $el_align = ( $align !='' ) ? $align  : 'text--center';

  $out.='<div id="start-screen" class="start-screen--style-5 crypterium_home_hero_3_ico_shortcode '.crypterium_vc_custom_css_class($css).'">';
    $out.='<div class="start-screen__static-bg jarallax" data-speed="0.3" style="background-image: url('.$image.');">';
    $out .= '<img class="jarallax-img" src="'.$image.'" alt="parallax" />';

      $out.='<div class="start-screen__content  text--center">';
        $out.='<div class="start-screen__content__inner">';
          $out.='<div class="grid grid--container">';
            $out.='<div class="row row--xs-middle">';
              $out.='<div class="col col--md-10 col--lg-8">';
                $out.='<div class="col-MB-25 col-md-MB-40 col-lg-MB-50">';
                  $out .= ''.do_shortcode( $content ).'';
                  if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h1', $class='__title', $tlineh, $tsize, $tcolor ).''; }
                  if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $dlineh, $dsize,
                  $dcolor ).''; }
                $out.='</div>';

                $out.='<div class="col-MB-15 col-md-MB-30 col-lg-MB-40">';
                  $out.='<div class="TimeCircles js-TimeCircles" data-date="'.$date.' 00:00:00"></div>';
                    ?>
                    <script type="text/javascript">
                    (function() {
                      var oInterval = setInterval(function() {
                        if (typeof window.jQuery !== 'undefined') {
                          clearInterval(oInterval);

                          jQuery(document).ready(function($) {

                            $('.js-TimeCircles').TimeCircles({
                              "animation": "smooth",
                              "bg_width": 1.1,
                              "fg_width": 0.05,
                              "circle_bg_color": "#d0d7dc",
                              "number_size": 0.2,
                              "time": {
                                "Days": {
                                  "text": "Days",
                                  "color": "#6178f6",
                                  "show": true
                                },
                                "Hours": {
                                  "text": "Hours",
                                  "color": "#6178f6",
                                  "show": true
                                },
                                "Minutes": {
                                  "text": "Minutes",
                                  "color": "#6178f6",
                                  "show": true
                                },
                                "Seconds": {
                                  "text": "Seconds",
                                  "color": "#6178f6",
                                  "show": true
                                }
                              }
                            });
                          });
                        }
                      }, 500);
                    })();
                </script>
                <?php
                $out.='</div>';

                if ( $btnlink !='' ){
                  $btnlink = ( $btnlink == '||' ) ? '' :
                  $btnlink; $btnlink = vc_build_link( $btnlink );
                  $btn_title1 = $btnlink['title'];
                  $btn_target1 = $btnlink['target'];
                  $btn_href1 = $btnlink['url'];
                  $out .= '<p>'.crypterium_btn( $tag='a', $btn_title1, $btn_href1, $btn_target1, $btnclass='custom-btn custom-btn--medium custom-btn--style-5', $btnbg, $btncolor, $icon=false ).'<p>';
                }
              $out.='</div>';
            $out.='</div>';
          $out.='</div>';
        $out.='</div>';
      $out.='</div>';

    $out.='</div>';

    if ( $scroll !='hide' ){ $out .= '<span class="scroll-discover hide show--md">'.$s_text.' <b></b></span>'; }

  $out.='</div>';

	return $out;
}
add_shortcode('crypterium_home_hero_3_ico_shortcode', 'crypterium_home_hero_3_ico');

/*-----------------------------------------------------------------------------------*/
/*	HOMESLIDER
/*-----------------------------------------------------------------------------------*/

function crypterium_home_slider( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"css" => '',
  	"loop" => '',
  	"scroll" => '',
    "s_text" => 'scroll down',
  	"s_text" => '',
  	"title" => '',
  	"img" => '',
	), $atts) );

  $el_loop = (array) vc_param_group_parse_atts($loop);

  $out .= '<div id="start-screen" class="start-screen--light start-screen--style-6 crypterium_home_slider_shortcode '.crypterium_vc_custom_css_class($css).'">';
		$out .= '<div class="start-screen__slider" data-slick=\'{"autoplay": false, "fade": true, "dots": true, "speed": 1200}\'>';

      $count = 1;
      foreach ( $el_loop as $item ) {
        $c = count($el_loop);
        $image = wp_get_attachment_url( $item['img'],'full' );
        $el_align = ( $item['alignment'] !='' ) ? $item['alignment']  : '';
  			$out .= '<div class="__slide __slide--'.$c.'">';
  				$out .= '<div class="start-screen__content '.$el_align.'" style="background-image: url('.$image.')">';
  					$out .= '<div class="start-screen__content__inner">';
  						$out .= '<div class="grid grid--container">';
  							$out .= '<div class="row">';

									$out .= ''.$item['contents'].'';

  							$out .= '</div>';
  						$out .= '</div>';
  					$out .= '</div>';
  				$out .= '</div>';
  			$out .= '</div>';
      }

		$out .= '</div>';

		if ( $scroll !='hide' ){ $out .= '<span class="scroll-discover hide show--md">'.$s_text.' <b></b></span>'; }

	$out .= '</div>';

	return $out;
}
add_shortcode('crypterium_home_slider_shortcode', 'crypterium_home_slider');

/*-----------------------------------------------------------------------------------*/
/*	logos
/*-----------------------------------------------------------------------------------*/
function crypterium_logos( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "sp" => '',
    "bg" => '',
    "css" => '',
    "ploop" => '',
    "type" => '-style-default',
  ), $atts) );

  $loop = (array) vc_param_group_parse_atts($ploop);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

	if ( !empty( $loop ) ){

    $out .= '<div class="crypterium_logos_shortcode '. $el_sp . " " . $el_bg . ' '.crypterium_vc_custom_css_class($css).'">';
  		$out .= '<div class="grid grid--container">';
  			$out .= '<div class="logos">';
  				$out .= '<div class="__inner">';
  					$out .= '<div class="row row--xs-center row--xs-around">';

              foreach ( $loop as $item ) {
                $el_column = ( $item['column'] != '' ) ? $item['column']  : '';
    						$out .= '<div class="col col--xs-auto '. $el_column .'">';
                  $image = wp_get_attachment_url( $item['img'],'full' );
                  $out .= '<a href="'.esc_url($item['href']).'" target="'.esc_attr($item['target']).'">';
    							$out .= '<img class="lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="'.get_the_title().'" />';
                  $out .= '</a>';
    						$out .= '</div>';
              }

  					$out .= '</div>';
  				$out .= '</div>';
  			$out .= '</div>';
  		$out .= '</div>';
  	$out .= '</div>';

	}
	return $out;
}
add_shortcode('crypterium_logos_shortcode', 'crypterium_logos');

/*-----------------------------------------------------------------------------------*/
/*	logos
/*-----------------------------------------------------------------------------------*/
function crypterium_projects( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "loop" => '',
  ), $atts) );

  $el_loop = (array) vc_param_group_parse_atts($loop);

	if ( !empty( $el_loop ) ){
  	$out .= '<div class="projects projects--slider" data-slick=\'{"autoplay": true, "dots": true, "speed": 1000}\'>';
      foreach ( $el_loop as $item ) {
  			$out .= '<div class="__item">
  			<figure class="__image">';
          $image = wp_get_attachment_url( $item['img'],'full' );
  				$out .= '<img class="lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="'.get_the_title().'" />';
  			$out .= '</figure>

  			<div class="__content">';

          if (  $item['btnlink'] != '' ){
            $btnlink = ( $item['btnlink'] == '||' ) ? '' : $item['btnlink'];
            $btnlink = vc_build_link( $btnlink );
            $btn_title = $btnlink['title'];
            $btn_target = $btnlink['target'];
            $btn_href = $btnlink['url'];
            $out .= '<p class="__category">'.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='', $btnbg, $btncolor, $icon=$item['i'] ).'</p>';
          }

          if (  $item['btnlink'] != '' ){
            $btnlink2 = ( $item['btnlink2'] == '||' ) ? '' : $item['btnlink2'];
            $btnlink2 = vc_build_link( $btnlink2 );
            $btn_title2 = $btnlink2['title'];
            $btn_target2 = $btnlink2['target'];
            $btn_href2 = $btnlink2['url'];
            $out .= '<h3 class="__title h5">'.crypterium_btn( $tag='a', $btn_title2, $btn_href2, $btn_target2, $btnclass='', $btnbg, $btncolor, $icon=$item['i'] ).'</h3>';
          }

  			$out .= '
  			</div>
  		</div>';
    }
  $out .= '</div>';
	}
	return $out;
}
add_shortcode('crypterium_projects_shortcode', 'crypterium_projects');

/*-----------------------------------------------------------------------------------*/
/* FEATURES
/*-----------------------------------------------------------------------------------*/
function crypterium_features( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => 'left',
    "sp" => '',
    "bg" => '',
    "offset" => '',
    "ploop" => '',
    "title" => '',
    "subtitle" => '',
    "desc" => '',
    "img" => '',
    "icon" => '',
    "alignment" => '',
    // animate
    "aos" => 'fade-left',
    "delay" => '150',
    "duration" => '',
    "easing" => '',
    "offsetaos" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
  ), $atts) );

  $loop = (array) vc_param_group_parse_atts($ploop);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

	$out = '';
  $out .= '<section class="crypterium_features_shortcode '. $el_sp . " " . $el_bg . ' '.crypterium_vc_custom_css_class($css).'">';
    $out .= '<div class="grid">';

    foreach ( $loop as $item ) {

      $ttlineh = $item['ttlineh'] ;
      $ttsize = $item['ttsize'] ;
      $ttcolor = $item['ttcolor'] ;
      $tlineh = $item['tlineh'] ;
      $tsize = $item['tsize'] ;
      $tcolor = $item['tcolor'] ;
      $dlineh = $item['dlineh'] ;
      $dsize = $item['dsize'] ;
      $dcolor = $item['dcolor'] ;

      $aos = $item['aos'] ;
      $delay = $item['delay'] ;
      $duration = $item['duration'] ;
      $offsetaos = $item['offsetaos'] ;
      $easing = $item['easing'] ;
      $anchor = $item['anchor'] ;
      $placement = $item['placement'] ;
      $once = $item['once'] ;

      $offset = ( $item['offset']  != '' ) ?  $item['offset']  : '';
      $col = ( $item['offset']  != '' ) ?  'col--lg-5'  : 'col--lg-6';
      $align = ( $item['type']  != 'left' ) ? 'row--md-reverse'  : '';
      $imargin = ( $item['imargin']  != '' ) ? $item['imargin']  : '';
      $style = ( $item['type'] == 'left' ) ? 'style="margin-right: auto;max-width: 570px;"'  : 'style="margin-left: auto;max-width: 570px;"';

      $out .= '<div class="row row--md-center  '.$align . ' col-MB-' . $imargin .'">';

          $out .= '<div class="col col--md-5 col--lg-6 col--no-gutters">';
             if ( isset( $item['img'] ) !='' ){ $out .= ''.crypterium_img( $item['img'], $imgclass='img-responsive', $imgwidth='', $imgheight='' ).''; }
          $out .= '</div>';

          if ( $item['type'] == 'left' ){ $out .= '<div class="col hide--md col-MB-40"></div>'; }

          $out .= '<div class="col col--md-7 '.$col.' '.$offset.'">';
            $out .= '<div class="content-grid" '.$style.' >';
              $out .= '<div '. crypterium_aos( $aos, $delay, $duration, $offsetaos, $easing, $anchor, $placement, $once ) .'>';

                $el_color = ( $item['h_color'] !='default' ) ? 'section-heading--white' : '' ;
                $el_margin = ( $item['margin'] !='' ) ? $item['margin'] : '30' ;
                $out .= '<div class="section-heading  '. $el_color .' col-MB-'. $el_margin .' '. $item['alignment'] .'">';
                  if ( isset( $item['subtitle'] ) !='' ){ $out .= ''.crypterium_element( $item['subtitle'], $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
                  if ( isset( $item['title'] ) !='' ){ $out .= ''.crypterium_element( $item['title'], $tag='h2', $class='title', $tlineh, $tsize, $tcolor ).''; }
                $out .= '</div>';

                if ( isset( $item['desc'] ) !='' ){ $out .= ''.crypterium_element( $item['desc'], $tag='p', $class='col-MB-35', $dlineh, $dsize, $dcolor ).''; }

                if (  $item['btnlink'] != '' ){
                    $el_btnstyle = ( $item['btnstyle']  != '' ) ?  $item['btnstyle']  : 'custom-btn--style-1';
                    $btnlink = ( $item['btnlink'] == '||' ) ? '' : $item['btnlink'];
                    $btnlink = vc_build_link( $btnlink );
                    $btn_title = $btnlink['title'];
                    $btn_target = $btnlink['target'];
                    $btn_href = $btnlink['url'];
                    $out .= '<p>'.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium '.$el_btnstyle.'', $btnbg, $btncolor, $icon=$item['i'] ).'</p>';
                }

              $out .= '</div>';
            $out .= '</div>';
          $out .= '</div>';

        if ( $item['type'] != 'left' ){ $out .= '<div class="col hide--md col-MB-40"></div>'; }
      $out .= '</div>';
    }
    $out .= '</div>';
  $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_features_shortcode', 'crypterium_features');

/*-----------------------------------------------------------------------------------*/
/*	FEATURES 2
/*-----------------------------------------------------------------------------------*/
function crypterium_features_2( $atts, $content = null ) {
   extract( shortcode_atts(array(
   	"img" => '',
   	"toptitle" => '',
    "sp" => '',
    "bg" => '',
   	"title" => '',
   	"toptitle" => '',
   	"desc" => '',
   	//custom style
   	"ttlineh" => '',
   	"ttsize" => '',
   	"ttcolor" => '',
   	"tlineh" => '',
   	"tsize" => '',
   	"tcolor" => '',
   	"dlineh" => '',
   	"dsize" => '',
   	"dcolor" => '',
    "h_color" => 'section-heading--white',
    "margin" => '',
    "alignment" => '',
    // animate
    "aos" => 'fade-up',
    "delay" => '150',
    "duration" => '',
    "easing" => 'ease-out-cubic',
    "anchor" => '',
    "placement" => '',
    "once" => '',
    //buton
    "btnbg" => '',
    "btncolor" => '',
   	//bg style
   	"css" => '',
   	//btn
   	"btnlink" => '',

	), $atts) );
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

	$out = '';
  $out .= '<section class="crypterium_features_2_shortcode '. $el_sp . " " . $el_bg . ' section--custom-01 '.crypterium_vc_custom_css_class($css).'">';
    $out .= '<style type="text/css">
      @media only screen and (min-width: 768px) {   .section--custom-01 .img-wrap { 	position: absolute; top: 0; left: 15px; right: 0; 	bottom: 0; 	margin-left: 42%; overflow: hidden; 	}   }
      @media only screen and (min-width: 992px) {   .section--custom-01 .__content { margin-bottom: 90px; 	} .section--custom-01 .img-wrap { 	margin-left: 45%; 	}   }
    </style>';

    $out .= '<div class="grid grid--container">';
      $out .= '<div class="row">';
        $out .= '<div class="col col--md-5 col--lg-5">';
          $out .= '<div '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
            $out .= '<div class="__content">';

              $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
              $el_margin = ( $margin !='' ) ? $margin : '30' ;
              $out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
                if ( $toptitle != '' ){ $out .= ''.crypterium_element( $toptitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
                if ( $title != '' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
              $out .= '</div>';

              if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='col-MB-35', $dlineh, $dsize, $dcolor ).''; }
              if ( $img !='' ){ $out .= '<p class="hide--md">'.crypterium_img( $img, $imgclass='img-responsive', $imgwidth='', $imgheight='' ).'</p>'; }

              if (  $btnlink != '' ){
                $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
                $btnlink = vc_build_link( $btnlink );
                $btn_title = $btnlink['title'];
                $btn_target = $btnlink['target'];
                $btn_href = $btnlink['url'];
                $out .= '<p>'.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2', $btnbg, $btncolor, $icon=$item['i'] ).'</p>';
              }

              $out .= ''.do_shortcode( $content ).'';

            $out .= '</div>';
          $out .= '</div>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</div>';

    $out .= '<div class="img-wrap jarallax  hide show--md" data-speed="0.3">';
      $image = wp_get_attachment_url( $img,'full' );
      $out .= '<img class="jarallax-img" src="'.$image.'" alt="'.get_the_title().'" />';
    $out .= '</div>';
  $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_features_2_shortcode', 'crypterium_features_2');

/*-----------------------------------------------------------------------------------*/
/* FEATURES_3
/*-----------------------------------------------------------------------------------*/
function crypterium_features_3( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => '1',
    "ploop" => '',
    "title" => '',
    "subtitle" => '',
    "sp" => '',
    "bg" => '',
    "desc" => '',
    "img" => '',
    "img_w" => '34',
    "img_h" => '60',
    "btnlink" => '',
    "icon" => '',
    "css" => '',
    //buton
    "btnbg" => '',
    "btncolor" => '',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
  ), $atts) );

  $loop = (array) vc_param_group_parse_atts($ploop);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes
  $el_type = ( $type =='type1' ) ? 'section--custom-02'  : 'section--custom-01'; // section padding classes

	$out = '';
  $out .= '<section class="crypterium_features_3_shortcode '. $el_sp . " " . $el_bg . " " . $el_type . ' section--custom-02 '.crypterium_vc_custom_css_class($css).'">';

    if ( $type =='type1' ){
    $out .= '<div class="feature feature--style-1  text--center text--sm-left">';
      $out .= '<div class="row row--no-gutters">';

        foreach ( $loop as $item ) {

        $aos = $item['aos'] ;
        $delay = $item['delay'] ;
        $duration = $item['duration'] ;
        $offset = $item['offset'] ;
        $easing = $item['easing'] ;
        $anchor = $item['anchor'] ;
        $placement = $item['placement'] ;
        $once = $item['once'] ;

        $color = ( $item['type']  != '' ) ? $item['type']  : '__item--first';
        $out .= '<div class="col col--no-gutters col--sm-6 col--lg-4 col--sm-flex">';
          $out .= '<div class="__item  '.$color.'" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
            $out .= '<div class="__content">';

              $image = wp_get_attachment_url( $item['img'],'full' );
              if ( isset( $item['img'] ) !='' ){
                $out .= '<i class="__ico">';
                  $out .= '<img class="img-responsive lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="'.get_the_title().'" width="'.$item['img_w'].'" height="'.$item['img_h'].'" />';
                $out .= '</i>';
              }

              if ( isset( $item['title'] ) !='' ){ $out .= ''.crypterium_element( $item['title'], $tag='h3', $class='__title', $tlineh, $tsize, $tcolor ).''; }
              if ( isset( $item['desc'] ) !='' ){ $out .= ''.crypterium_element( $item['desc'], $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }


                $btnlink = ( $item['btnlink'] == '||' ) ? '' : $item['btnlink'];
                $btnlink = vc_build_link( $btnlink );
                $btn_title = $btnlink['title'];
                $btn_target = $btnlink['target'];
                $btn_href = $btnlink['url'];

                if ( $btn_href !='' ){ $out .= '<p><a class="__more" href="'.$btn_href.'" target="'.$btn_target.'"><i class="fontello-right-1"></i></a></p>'; }


            $out .= '</div>';
          $out .= '</div>';
        $out .= '</div>';
      } // end item

    $out .= '  </div>';
    $out .= '</div>';
  }
  if ( $type =='type2' ){

      $out .= '<style type="text/css">
      @media only screen and (min-width: 768px) {
        .section--custom-01 .feature--style-1 {
          width: 65vw;
        }

        .section--custom-01 .feature--style-1 .slick-dots {
          text-align: left;
        }
      }

      @media only screen and (min-width: 992px) {
        .section--custom-01 .feature--style-1 {
          margin-left: 0 !important;
          margin-right: 0 !important;
        }
      }
    </style>';

      $out .= '<div class="grid grid--container">';
        $out .= '<div class="row row--xs-center">';

          $out .= '<div class="col col--md-6 col--lg-5 col--xl-4">';
            $out .= '<div class="col-MB-35 col-md-MB-0" data-aos="fade-up" data-aos-easing="ease-out-cubic">';
            $out .= '<div class="section-heading section-heading--white  col-MB-30">';
              if ( $subtitle != '' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
              if ( $title != '' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
              $out .= '</div>';

              if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }

            $out .= '</div>';
          $out .= '</div>';

        $out .= '<div class="col col--md-6 col--lg-7 col--xl-7 col--xl-offset-1">';

          $out .= '<div class="feature feature--style-1 feature--slider  text--center text--sm-left" data-slick=\'{
              "autoplay": true,
              "arrows": false,
              "dots": true,
              "speed": 1000,
              "responsive": [
                {
                  "breakpoint":560,
                  "settings":{
                    "centerMode": true,
                    "centerPadding": "20%"
                  }
                },
                {
                  "breakpoint":767,
                  "settings":{
                    "centerMode": false,
                    "slidesToShow": 2
                  }
                },
                {
                  "breakpoint":1500,
                  "settings":{
                    "slidesToShow": 3
                  }
                }
              ]}\'>';

              foreach ( $loop as $item ) {

              $aos = $item['aos'] ;
              $delay = $item['delay'] ;
              $duration = $item['duration'] ;
              $offset = $item['offset'] ;
              $easing = $item['easing'] ;
              $anchor = $item['anchor'] ;
              $placement = $item['placement'] ;
              $once = $item['once'] ;

              $color = ( $item['type']  != '' ) ? $item['type']  : '__item--first';
                $out .= '<div class="__item  '.$color.'" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
                  $out .= '<div class="__content">';

                    $image = wp_get_attachment_url( $item['img'],'full' );
                    if ( isset( $item['img'] ) !='' ){
                      $out .= '<i class="__ico">';
                        $out .= '<img class="img-responsive"  src="'.$image.'" alt="'.get_the_title().'" width="'.$item['img_w'].'" height="'.$item['img_h'].'" />';
                      $out .= '</i>';
                    }

                    if ( isset( $item['title'] ) !='' ){ $out .= ''.crypterium_element( $item['title'], $tag='h3', $class='__title', $tlineh, $tsize, $tcolor ).''; }
                    if ( isset( $item['desc'] ) !='' ){ $out .= ''.crypterium_element( $item['desc'], $tag='p', $class='', $dlineh, $dsize, $dcolor ).''; }

                    if ( $btn_href !='' ){
                      $btnlink = ( $item['btnlink'] == '||' ) ? '' : $item['btnlink'];
                      $btnlink = vc_build_link( $btnlink );
                      $btn_title = $btnlink['title'];
                      $btn_target = $btnlink['target'];
                      $btn_href = $btnlink['url'];

                      $out .= '<p><a class="__more" href="'.$btn_href.'" target="'.$btn_target.'"><i class="fontello-right-1"></i></a></p>';
                    }

                $out .= '</div>';
              $out .= '</div>';
            } // end item

          $out .= '</div>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</div>';

  }
  $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_features_3_shortcode', 'crypterium_features_3');

/*-----------------------------------------------------------------------------------*/
/*	FEATURES_4
/*-----------------------------------------------------------------------------------*/
function crypterium_features_4( $atts, $content = null ) {
   extract( shortcode_atts(array(
   	"img" => '',
   	"img1" => '',
   	"img2" => '',
    "sp" => '',
    "bg" => '',
   	"subtitle" => '',
   	"title" => '',
   	"desc" => '',
   	//custom style
   	"ttlineh" => '',
   	"ttsize" => '',
   	"ttcolor" => '',
   	"tlineh" => '',
   	"tsize" => '',
   	"tcolor" => '',
   	"dlineh" => '',
   	"dsize" => '',
   	"dcolor" => '',
    "h_color" => '',
    "margin" => '',
    "alignment" => '',
    // animate
    "aos" => 'fade-right',
    "delay" => '',
    "duration" => '',
    "offset" => '0',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
    // animate
    "aos2" => 'fade-left',
    "duration2" => '',
    "offset2" => '',
    "easing2" => '',
    "anchor2" => '',
    "placement2" => '',
    "once2" => '',
    //buton
    "btnbg" => '',
    "btncolor" => '',
   	//bg style
   	"css" => '',
   	//btn
   	"btnlink" => '',
   	"btnlink1" => '',
	), $atts) );

  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

	$out = '';
  $out .= '<section class="crypterium_features_4_shortcode '. $el_sp . " " . $el_bg . ' section--light-blue-bg '.crypterium_vc_custom_css_class($css).'">';
    $out .= '<div class="grid grid--container">';
      $out .= '<div class="row row--xs-center">';

        $out .= '<div class="col col--lg-5">';
          $out .= '<div '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';

            $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
            $el_margin = ( $margin !='' ) ? $margin : '30' ;
            $out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
              $out .= ''.do_shortcode( $content ).'';
              if (  $subtitle != '' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
              if (  $title != '' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
            $out .= '</div>';

            if (  $desc != '' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='col-MB-35', $dlineh, $dsize, $dcolor ).''; }

            $out .= '<div class="b-table" style="width: auto;">';
              $image1 = wp_get_attachment_url( $img1,'full' );
              $image2 = wp_get_attachment_url( $img2,'full' );

              $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
              $btnlink = vc_build_link( $btnlink );
              $btn_title = $btnlink['title'];
              $btn_target = $btnlink['target'];
              $btn_href = $btnlink['url'];

              $btnlink1 = ( $btnlink1 == '||' ) ? '' : $btnlink1;
              $btnlink1 = vc_build_link( $btnlink1 );
              $btn_title1 = $btnlink1['title'];
              $btn_target1 = $btnlink1['target'];
              $btn_href1 = $btnlink1['url'];

              if (  $image1 != '' ){
                $out .= '<a class="cell v-middle" href="'.$btn_href.'" target="'.$btn_target.'">
                <img class="img-responsive lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image1.'" alt="'.get_the_title().'" />
                </a> &nbsp;';
              }
              if (  $image2 != '' ){
                $out .= '<a class="cell v-middle" href="'.$btn_href1.'" target="'.$btn_target1.'">
                <img class="img-responsive lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image2.'" alt="'.get_the_title().'" />
                </a>';
              }
            $out .= '</div>';
          $out .= '</div>';
        $out .= '</div>';

        $out .= '<div class="col hide--md col-MB-40"></div>';

        $out .= '<div class="col col--lg-7">';
          $out .= '<div '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .'>';
            $image = wp_get_attachment_url( $img,'full' );
            if (  $image != '' ){ $out .= '<img class="img-responsive center-block lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="'.get_the_title().'" />'; }
          $out .= '</div>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</div>';
  $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_features_4_shortcode', 'crypterium_features_4');

/*-----------------------------------------------------------------------------------*/
/*	FEATURES_5
/*-----------------------------------------------------------------------------------*/
function crypterium_features_5( $atts, $content = null ) {
   extract( shortcode_atts(array(
   	"img" => '',
    "img_w" => '34',
    "img_h" => '60',
   	"title" => '',
   	"desc" => '',
   	"alignment" => 'text--sm-center',
    // animate
    "aos" => 'slide-up',
    "delay" => '0',
    "duration" => '800',
    "offset" => '-250',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
   	//custom style
   	"tlineh" => '',
   	"tsize" => '',
   	"tcolor" => '',
   	"dlineh" => '',
   	"dsize" => '',
   	"dcolor" => '',
   	//bg style
   	"css" => '',
	), $atts) );

	$out = '';
  $out .= '<div class="crypterium_features_5_shortcode feature feature--style-2  text--center '. $alignment .' crypterium_features_5_shortcode '.crypterium_vc_custom_css_class($css).'">';
    $out .= '<div class="__item" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
      $out .= '<div class="__content">';
        $out .= '<i class="__ico">';
        $image = wp_get_attachment_url( $img,'full' );
        if (  $image != '' ){ $out .= '<img class="img-responsive lazy" src="'. get_theme_file_uri() .'/images/blank.gif" width="'.$img_w.'" height="'.$img_h.'" data-src="'.$image.'" alt="'.get_the_title().'" />'; }
        $out .= '</i>';

        if ( $title != '' ){ $out .= ''.crypterium_element( $title, $tag='h3', $class='__title', $tlineh, $tsize, $tcolor ).''; }
        if ( $desc != '' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='col-MB-35', $dlineh, $dsize, $dcolor ).''; }

        $out .= ''.do_shortcode( $content ).'';

      $out .= '</div>';
    $out .= '</div>';
  $out .= '</div>';

    $outx .= '.feature {display:flex-wrap !important;}';
  wp_add_inline_style( 'crypterium-custom-style', $outx );

	return $out;
}
add_shortcode('crypterium_features_5_shortcode', 'crypterium_features_5');

/*-----------------------------------------------------------------------------------*/
/*	SECTION_HEADING
/*-----------------------------------------------------------------------------------*/
function crypterium_section_heading( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"title" => '',
  	"titletag" => 'h2',
  	"subtitle" => '',
  	"subtag" => 'h5',
  	"desc" => '',
  	"desctag" => 'p',
    "h_color" => 'default',
  	"margin" => '',
  	"alignment" => 'text--center',
    // animate
    "aos" => '',
    "delay" => '',
    "duration" => '',
    "offset" => '',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
  	//custom style
  	"ttlineh" => '',
  	"ttsize" => '',
  	"ttcolor" => '',
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dtlineh" => '',
  	"dtsize" => '',
  	"dtcolor" => '',
  	//bg style
  	"css" => '',
	), $atts) );

	$m = ( $margin !='' ) ? $margin : '' ;
	$el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;

	$out = '';
  $out .= '<div class="section-heading  '. $el_color .' col-MB-'. $m .' '. $alignment .' '.crypterium_vc_custom_css_class($css).'" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
    if ( $subtitle !='' ){ $out .= ''.crypterium_element( $heading=$subtitle, $tag=$subtag, $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
    if ( $title !='' ){ $out .= ''.crypterium_element( $heading=$title, $tag=$titletag, $class='__title', $tlineh, $tsize, $tcolor ).''; }
  	if ( $desc !='' ){ $out .= ''.crypterium_element( $heading=$desc, $tag=$desctag, $class='col-MB-35', $dtlineh, $dtsize, $dtcolor ).''; }
	$out .= '</div>';

	return $out;
}
add_shortcode('crypterium_section_heading_shortcode', 'crypterium_section_heading');

/*-----------------------------------------------------------------------------------*/
/* CALCULATOR
/*-----------------------------------------------------------------------------------*/
function crypterium_crypto_calc( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "give" => 'Give',
    "get" => 'Get',
    "btnlink" => '',
    "sp" => '',
    "bg" => '',
    "pattern" => '',
    "title" => '',
    "subtitle" => '',
    "bgcss" => '',
    "h_color" => '',
    "margin" => '',
    "alignment" => 'text--center',
    // style
    "tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"ttlineh" => '',
  	"ttsize" => '',
  	"ttcolor" => '',
  ), $atts) );

  $lab = $label =='y' ? '-has-label' : '';
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

	$out = '';
  $out .= '<section class="crypterium_crypto_calc_shortcode '. $el_sp . " " . $el_bg . ' '. crypterium_vc_custom_css_class($bgcss) .'">';
      if ( $pattern !='hide' ){
        $out .= '<div
          class="pattern"
          style="background: -moz-linear-gradient(0deg, rgba(114,76,253,0.66) 0%, rgba(61,168,243,0.66) 100%);
            background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(114,76,253,0.66)), color-stop(100%, rgba(61,168,243,0.66)));
            background: -webkit-linear-gradient(0deg, rgba(114,76,253,0.66) 0%, rgba(61,168,243,0.66) 100%);
            background: -o-linear-gradient(0deg, rgba(114,76,253,0.66) 0%, rgba(61,168,243,0.66) 100%);
            background: -ms-linear-gradient(0deg, rgba(114,76,253,0.66) 0%, rgba(61,168,243,0.66) 100%);
            background: linear-gradient(90deg, rgba(114,76,253,0.66) 0%, rgba(61,168,243,0.66) 100%);">
          </div>';
       }
      $out .= '<div class="grid grid--container">';

        $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
        $el_margin = ( $margin !='' ) ? $margin : '60' ;
         $out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
           if ( $subtitle !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
           if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
         $out .= '</div>';

        $out .= '<div class="row row--xs-middle">';
          $out .= '<div class="col col--md-10 col--lg-8">';

            $out .= '<div class="calculator">';

                $out .= '<div class="row">';

                  $out .= '<div class="col col--sm-6  col-MB-20 col-sm-MB-0">';
                    $out .= '<span>'.$give.'</span>';
                    $out .= '<form onsubmit="myFunction(); return false;">';
                    $out .= '<div class="input-wrp">';
                      $out .= '<input class="textfield amount-input" type="number"  id="currency1-amount" value="1" />';

                      $out .= '<select id="currency1-name" class="js-select calculator-select currency1-name">';
                        $out .= '<option value="USD selected">US Dollars (USD)</option>';
            			  $out .= '<option value="EUR">Euro (EUR)</option>';
            			  $out .= '<option value="GBP">Great British Pound (GBP)</option>';
             			 $out .= '<option value="BTC" selected>Bitcoin (BTC)</option>';
                      $out .= '</select>';
                    $out .= '</div>';

                    $out .= '<span id="summary-currency1-amount" class="__desc summary-currency1-amount" style="margin-right: 5px;"></span><span class="summary-currency1-name"></span>';
                    $out .= '<span class="summary-currency1-name"> is</span>';
                  $out .= '</form>';
                $out .= '</div>';

                 $out .= '<div class="col col--sm-6">';
                    $out .= '<span>'.$get.'</span>';
                    $out .= '<form onsubmit="myFunction(); return false;">';
                      $out .= '<div class="input-wrp">';
                        $out .= '<input class="textfield amount-input" type="number"  id="currency2-amount"/>';

                        $out .= '<select id="currency2-name" class="js-select calculator-select currency2-name">';
                        $out .= '<option value="USD">US Dollars (USD)</option>';
                         $out .= '<option value="EUR">Euro (EUR)</option>';
                         $out .= '<option value="GBP">Great British Pound (GBP)</option>';
                        $out .= '<option value="BTC" selected>Bitcoin (BTC)</option>';
                        $out .= '</select>';
                      $out .= '</div>';
                    $out .= '<span id="summary-currency2-amount" class="__desc summary-currency2-amount" style="margin-right: 5px;"></span><span class="summary-currency2-name"></span>';

                  $out .= '</form>';
                $out .= '</div>';
              $out .= '</div>';

                if (  $btnlink != '' ){
                  $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
                  $btnlink = vc_build_link( $btnlink );
                  $btn_title = $btnlink['title'];
                  $btn_target = $btnlink['target'];
                  $btn_href = $btnlink['url'];
                  $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2 wide mt-30', $btnbg, $btncolor, $icon=false ).'';
                }

            $out .= '</div>';
         $out .= ' </div>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_crypto_calc_shortcode', 'crypterium_crypto_calc');

/*-----------------------------------------------------------------------------------*/
/*	LATEST BLOG crypterium
/*-----------------------------------------------------------------------------------*/
function crypterium_blog( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => '',
    "subtitle" => '',
    "title" => '',
    "desc" => '',
    "h_color" => 'default',
    "margin" => '',
    "alignment" => 'text--center',
    "sp" => '',
    "bg" => '',
    "showimg" => 'no',
    //post
    "limit" => '120',
    "perpage" => '9',
    "order" => 'DESC',
    "orderby" => 'date',
    "postcat" => 'all',
    //custom style
    "tlineh" => '',
    "tsize" => '',
    "tcolor" => '',
    //bg css
    "bgcss" => '',
  ), 	$atts));

	$posts_args = array(
		'post_type' => 'post',
		'posts_per_page' => $perpage,
		'order' => $order,
		'orderby' => $orderby,
		'post_status' => 'publish'
	);

	if( $postcat != 'all' ){
		$str = $postcat;
		$arr = explode(',', $str);
		$posts_args['tax_query'][] = array(
			'taxonomy' => 'category',
			'field' => 'slug',
			'terms' => $arr
		);
	}

  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes
  $el_type = ( $type == 'b2' ) ? 'grid--container'  : ''; // section padding classes

  $out = '';

   $out .= '<section class="'. $el_sp . " " . $el_bg . ' '. crypterium_vc_custom_css_class($bgcss) .'">';
     $out .= '<div class="grid '. $el_type . '">';
      if ( $title !='' ){
        $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
        $el_margin = ( $margin !='' ) ? $margin : '60' ;
        $out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
          if ( $subtitle !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
          if ( $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
          if ( $desc !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='', $tlineh, $tsize, $tcolor ).''; }
        $out .= '</div>';
      }
      if ( $type == 'b1') {
        $out .= '<div class="posts posts--slider" data-slick=\'{"autoplay": true, "dots": true, "speed": 1000}\'>';

          $post_query = new WP_Query($posts_args);
          if( $post_query->have_posts() ) : while ($post_query->have_posts()) : $post_query->the_post();

          $out .= '<div class="__item __item--preview">';

           // post image
           if ( has_post_thumbnail() AND $showimg =='yes' ) {

              $img_w = $img_width ? $img_width : 642;
              $img_h = $img_height ? $img_height : 430;

              $id = get_post_thumbnail_id();
              $img_url_out = wp_get_attachment_url( $id, 'full' );
              $img_url = crypterium_aq_resize( $img_url_out, $img_w, $img_h , true, true, true );

               $out .= '<figure class="__image">';
                 $out .= '<a  href="'.get_permalink().'"><img src="'.$img_url.'" alt="'.get_the_title().'"></a>';
               $out .= '</figure>';
           }

           $out .= '<div class="__content">';
            //date
            $archive_year = get_the_time('Y');
            $archive_month = get_the_time('m');
            $archive_day = get_the_time('d');
            $categoriess = get_the_category_list( ' - ', '', $post->ID );
            $out .= '<p class="__category">'.$categoriess.'</p>';

             $out .= '<h3 class="__title h4"><a href="'.get_permalink().'">'.get_the_title().'</a></h3>';

             if ( has_excerpt() ) {
              $content = get_the_excerpt();
              $limit = ( $limit != '' ) ? $limit : '';
              $total_content = ( $limit != '' ) ? substr ( $content, 0, $limit ) : $content;
              $out .= '<p class="__text" '.$dtstyle.'>'.$total_content.'</p>';
            }else{
              $content = get_the_content();
              $limit = ( $limit != '' ) ? $limit : '';
              $total_content = ( $limit != '' ) ? substr ( $content, 0, $limit ) : $content;
              $out .= $total_content;
            }

           $out .= '<span class="__date-post">'.get_the_date().'</span>';

         $out .= '</div>'; // __content
      $out .= ' </div>'; // item

       endwhile;
     endif;

    $out .= '</div>';
    } else {
      $out .= '<div class="posts">';
        $out .= '<div class="__inner">';
          $out .= '<div class="row  js-masonry" data-masonry-options=\'{
              "itemSelector": ".js-masonry__item",
              "transitionDuration": "0.8s",
              "percentPosition": "true",
              "masonry": { "columnWidth": ".js-masonry__sizer" }
            }\'>';

            $out .= '<div class="col col--sm-6 col--lg-4  js-masonry__sizer"></div>';

            $post_query = new WP_Query($posts_args);
            if( $post_query->have_posts() ) : while ($post_query->have_posts()) : $post_query->the_post();

            $out .= '<!-- start item -->';
            $out .= '<div class="col col--sm-6 col--lg-4  js-masonry__item">';
              $out .= '<div data-aos="zoom-in-up" data-aos-delay="100" data-aos-offset="0">';
                $out .= '<div class="__item __item--preview">';

                // post image
                if ( has_post_thumbnail() AND $showimg =='yes' ) {

                   $img_w = $img_width ? $img_width : 642;
                   $img_h = $img_height ? $img_height : 430;

                   $id = get_post_thumbnail_id();
                   $img_url_out = wp_get_attachment_url( $id, 'full' );
                   $img_url = crypterium_aq_resize( $img_url_out, $img_w, $img_h , true, true, true );

                    $out .= '<figure class="__image">';
                      $out .= '<a  href="'.get_permalink().'"><img src="'.$img_url.'" alt="'.get_the_title().'"></a>';
                    $out .= '</figure>';
                }

                  $out .= '<div class="__content">';
                   //date
                   $archive_year = get_the_time('Y');
                   $archive_month = get_the_time('m');
                   $archive_day = get_the_time('d');
                   $categoriess = get_the_category_list( '- ', '', $post->ID );
                   $out .= '<p class="__category">'.$categoriess.'</p>';

                    $out .= '<h3 class="__title h4"><a href="'.get_permalink().'">'.get_the_title().'</a></h3>';

                     if ( has_excerpt() ) {
                       $content = get_the_excerpt();
                       $limit = ( $limit != '' ) ? $limit : '';
                       $total_content = ( $limit != '' ) ? $content = substr ( $content, 0, $limit ) : $content;
                       $out .= '<p class="__text" '.$dtstyle.'>'.$total_content.'</p>';
                     }else{
                       $content = get_the_content(); $limit = ( $limit != '' ) ? $limit : '';
                       $total_content = ( $limit != '' ) ? $content = substr ( $content, 0, $limit ) : $content;
                       $out .= '<p class="__text" '.$dtstyle.'>'.$total_content.'</p>';
                     }

                  $out .= '<span class="__date-post">'.get_the_date().'</span>';

                $out .= '</div>'; // __content

                $out .= '</div>';
              $out .= '</div>';
            $out .= '</div>';
            $out .= '<!-- end item -->';
            endwhile;
          endif;
          $out .= '</div>';
        $out .= '</div>';


      $out .= '</div>';
    }
     $out .= '</div>';
   $out .= '</section>';

   wp_reset_query();
	return $out;

}
add_shortcode('crypterium_blog_shortcode', 'crypterium_blog');

/*-----------------------------------------------------------------------------------*/
/*	TESTIMONIAL
/*-----------------------------------------------------------------------------------*/
function crypterium_testimonial( $atts, $content = null ) {
  extract( shortcode_atts(array(
   	//testi loop
   	"icon_v" => '',
   	"testiloop" => '',
   	"quote" => '',
   	"sp" => '',
   	"bg" => '',
   	"name" => '',
   	"job" => '',
   	"icon" => '“',
   	"align" => 'left',
   	"dots" => 'left',
   	"item" => '1',
   	//testi style
   	"qsize" => '',
   	"qlineh" => '',
   	"qcolor" => '',
   	"nsize" => '',
   	"nlineh" => '',
   	"ncolor" => '',
   	"jsize" => '',
   	"jlineh" => '',
   	"jcolor" => '',
	), $atts) );

	$testi_loop = (array) vc_param_group_parse_atts($testiloop);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes
  $el_icon_v = ( $icon_v !='no' ) ? 'col--md-10'  : 'col--md-12'; // section padding classes

  $out = '';
	if ( !empty( $testi_loop ) ){

    $out .= '<section class="crypterium_testimonial_shortcode '. $el_sp . " " . $el_bg . ' '. crypterium_vc_custom_css_class($bgcss) .'">';
			$out .= '<div class="grid grid--container">';
				$out .= '<div class="row">';

        if ( $icon_v !='no' ){
					$out .= '<div class="col col--md-2  hide show--md">';
							$out .= '<i class="testimonial-ico">“</i>';
					$out .= '</div>';
        }

					$out .= '<div class="col col--md-10">';
						$out .= '<div class="testimonial testimonial--slider" data-slick=\'{"autoplay": true, "arrows": false, "dots": true, "speed": 1000}\'>';

              foreach ( $testi_loop as $t ) {
           $out .= '	<div class="__item">';
  								$out .= '<div class="__text">';
  							 if ( isset( $t['quote'] ) !='' ){ $out .= ''.crypterium_element( $t['quote'], $tag='p', $class='', $qlineh, $qsize, $qcolor ).''; }
  								$out .= '</div>';

  								$out .= '<div class="__author">';
                    if ( isset( $t['name'] ) !='' ){ $out .= ''.crypterium_element( $t['name'], $tag='h5', $class='__author--name', $nlineh, $nsize, $ncolor ).''; }
                    if ( isset( $t['job'] ) !='' ){ $out .= ''.crypterium_element( $t['job'], $tag='span', $class='__author--position', $plineh, $psize, $pcolor ).''; }
  								$out .= '</div>';
  							$out .= '</div>';
              }

						$out .= '</div>';
					$out .= '</div>';
				$out .= '</div>';
			$out .= '</div>';
		$out .= '</section>';

 	}

	return $out;
}
add_shortcode('crypterium_testimonial_shortcode', 'crypterium_testimonial');

/*-----------------------------------------------------------------------------------*/
/*	TESTIMONIAL
/*-----------------------------------------------------------------------------------*/
function crypterium_reviews( $atts, $content = null ) {
  extract( shortcode_atts(array(
   	// loop
   	"type" => 'r2',
   	"loop" => '',
   	"quote" => '',
   	"name" => '',
   	"job" => '',
   	"img" => '',
   	"a_img" => '',
   	// style
   	"qsize" => '',
   	"qlineh" => '',
   	"qcolor" => '',
   	"nsize" => '',
   	"nlineh" => '',
   	"ncolor" => '',
   	"jsize" => '',
   	"jlineh" => '',
   	"jcolor" => '',
	), $atts) );

	$el_loop = (array) vc_param_group_parse_atts($loop);
  $out = '';

  if ( $type =='r2' ){
  	$out .= '<div
    class="review review--slider  review--style-2"
    data-slick=\'{"autoplay": true, "arrows": false, "dots": true, "speed": 1000, "responsive": [{ "breakpoint":768,"settings":{"slidesToShow": 1} }]}\'>';
  } else {
    $out .= '<div
    class="review review--slider  review--style-2"
    data-slick=\'{"autoplay": true, "arrows": false, "dots": true, "speed": 1000}\'>';
  }

    foreach ( $el_loop as $t ) {
      if ( $type =='r2' ){
      	$out .= '<div class="__item">';
        	$out .= '<div class="row">';

          	$out .= '<div class="col col--md-4">';
            	$out .= '<div class="text--center  col-MB-25 col-md-MB-0">';

              	$out .= '<i class="__logo">';
                  $out .= ''.crypterium_img( $t['img'], $imgclass='img-responsive', $imgwidth='232', $imgheight='87' ).'';
              	$out .= '</i>';

              	$out .= '<div class="__author">';
                  $out .= ''.crypterium_img( $t['a_img'], $imgclass='__author--image  center-block circled', $imgwidth='78', $imgheight='78' ).'';
               if ( isset( $t['name'] ) !='' ){ $out .= ''.crypterium_element( $t['name'], $tag='h5', $class='__author--name', $nlineh, $nsize, $ncolor ).''; }
               if ( isset( $t['job'] ) !='' ){ $out .= ''.crypterium_element( $t['job'], $tag='span', $class='__author--position', $plineh, $psize, $pcolor ).''; }
              	$out .= '</div>';

            	$out .= '</div>';
        	$out .= '  </div>';

          	$out .= '<div class="col col--md-8 col--lg-7 col--lg-offset-1">';
            	$out .= '<div class="__text">';
              	if ( isset( $t['quote'] ) !='' ){ $out .= ''.crypterium_element( $t['quote'], $tag='p', $class='', $qlineh, $qsize, $qcolor ).''; }
            	$out .= '</div>';
          	$out .= '</div>';
        	$out .= '</div>';

      	$out .= '</div>';
      } else {

    	$out .= '<div class="__item">';
      	$out .= '<div class="__text  text--center">';
        $out .= '<i class="__logo">';
          $out .= ''.crypterium_img( $t['img'], $imgclass='img-responsive', $imgwidth='232', $imgheight='87' ).'';
        $out .= '</i>';

        if ( isset( $t['quote'] ) !='' ){ $out .= ''.crypterium_element( $t['quote'], $tag='p', $class='', $qlineh, $qsize, $qcolor ).''; }
      	$out .= '</div>';

      	$out .= '<div class="__author  text--center">';
        $out .= ''.crypterium_img( $t['a_img'], $imgclass='__author--image  center-block circled', $imgwidth='78', $imgheight='78' ).'';
        if ( isset( $t['name'] ) !='' ){ $out .= ''.crypterium_element( $t['name'], $tag='h5', $class='__author--name', $nlineh, $nsize, $ncolor ).''; }
        if ( isset( $t['job'] ) !='' ){ $out .= ''.crypterium_element( $t['job'], $tag='span', $class='__author--position', $plineh, $psize, $pcolor ).''; }
      	$out .= '</div>';
    	$out .= '</div>';
    } // if
    } // foreach
	$out .= '</div>';

	return $out;
}
add_shortcode('crypterium_reviews_shortcode', 'crypterium_reviews');

/*-----------------------------------------------------------------------------------*/
/*	CONTACT
/*-----------------------------------------------------------------------------------*/
function crypterium_contact( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"type" => 'c1',
  	"title" => '',
    "sp" => '',
    "bg" => '',
  	"img" => '',
    "img_w" => '44',
    "img_h" => '34',
  	"number" => '',
  	"icon" => '',
  	"infoloop" => '',
    "h_color" => 'white',
    "margin" => '',
    "alignment" => 'text--center',
  	//custom style
  	"tlineh" => '',
  	"tsize" => '',
  	"tcolor" => '',
  	"dtlineh" => '',
  	"dtsize" => '',
  	"dtcolor" => '',
  	//bg style
  	"bgcss" => '',
	), $atts) );

    $info_loop = (array) vc_param_group_parse_atts($infoloop);
    $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
    $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes
    $image = wp_get_attachment_url( $img,'full' );
	$out = '';

  if ( $type =='c1' ){

    $out .= '<section class="'. $el_sp . " " . $el_bg . ' jarallax '. crypterium_vc_custom_css_class($bgcss) .'" data-speed="0.5">';

 if (  $image != '' ){ $out .= '<img class="jarallax-img" src="'.$image.'" alt="'.get_the_title().'" />'; }
			$out .= '<div class="pattern" style="background-color: rgba(0, 0, 0, 0.53);"></div>';

			$out .= '<div class="grid grid--container">';

            if (  $title !='' ){
                $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
                $el_margin = ( $margin !='' ) ? $margin : '45' ;
                $out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
                    $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).'';
                $out .= '</div>';
            }

				$out .= '<div class="row row--xs-middle">';
					$out .= '<div class="col col--xs-10">';

						$out .= '<div class="company-contacts  text--center">';
							$out .= '<div class="__inner">';
								$out .= '<div class="row row--xs-between">';
                  $count=1;
                  foreach ( $info_loop as $i ) {
                    $class = ($count > 1 ) ? 'col--sm-6' : '';
  									$out .= '<div class="col col--lg-4 col--xl-3 '. $class .'">';
  										$out .= '<div class="__item">';
  											if ( isset( $i['info'] ) !='' ){ $out .= ''.crypterium_element( $i['info'], $tag='p', $class='', $dtlineh, $dtsize, $dtcolor ).''; }
  										$out .= '</div>';
  									$out .= '</div>';
                    $count++;
                  }
								$out .= '</div>';
							$out .= '</div>';
						$out .= '</div>';

					$out .= '</div>';
				$out .= '</div>';
			$out .= '</div>';
		$out .= '</section>';

  } else {
    $out .= '<address class="company-address">';
      $out .= '<div class="__item">';
        $out .= '<i class="__ico">';
          if (  $image != '' ){
            $out .= '<img class="img-responsive lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" width="'.$img_w.'" height="'.$img_h.'" alt="'.get_the_title().'" />';
          }
        $out .= '</i>';

        $out .= '<div>';
          if (  $title !='' ){ $out .= ''.crypterium_element( $title, $tag='h4', $class='__title h5', $tlineh, $tsize, $tcolor ).''; }

          $out .= '<span>';
            $out .= ''.do_shortcode( $content ).'';
          $out .= '</span>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</address>';
  }

	return $out;
}
add_shortcode('crypterium_contact_shortcode', 'crypterium_contact');

/*-----------------------------------------------------------------------------------*/
/*	MAP
/*-----------------------------------------------------------------------------------*/
function crypterium_maps( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"api" => '',
    "long" => '',
    "lat" => '',
  	"img" => '',
	), $atts) );

  $image = wp_get_attachment_url( $img,'full' );
	$out = '';
  $out .= '<div id="g_map--0001"
  class="g_map"
  data-api-key="'.$api.'"
  data-longitude="'.$long.'"
  data-latitude="'.$lat.'"
  data-marker="'.$image.'">
  </div>

	<style type="text/css">
		#g_map--0001 {
			height: 380px
		}

		@media only screen and (min-width: 560px) {
			#g_map--0001 {
				height: 475px
			}
		}
	</style>';

	return $out;
}
add_shortcode('crypterium_maps_shortcode', 'crypterium_maps');

/*-----------------------------------------------------------------------------------*/
/*	GALLERY
/*-----------------------------------------------------------------------------------*/

function crypterium_gallery( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => 'slider',
    "gallery_loop" => '',
    "img" => '',
    "img_width" => '',
    "img_height" => '',
    "css" => '',
  ), $atts) );

  $gallery_loop = (array) vc_param_group_parse_atts($gallery_loop);

  $out = '';

  if ( $type !='grid' ){
  $out .= '<div class="crypterium_gallery_shortcode screenshots screenshots--slider '. crypterium_vc_custom_css_class($css) .'" data-slick=\'{"autoplay": true, "arrows": false, "dots": true, "speed": 1200}\'>';
    foreach ($gallery_loop as $item) {
      $out .= '<div class="__item">';
        if ( isset( $item['img'] ) !='' ){
          $out .= ''.crypterium_img( $item['img'], $imgclass='c-gallery-1-image', $imgwidth='', $imgheight='' ).'';
        }
      $out .= '</div>';
    }
  $out .= '</div>';

  } else {

  $out .= '<div class="gallery">';
  $out .= '  <div class="__inner">';
  $out .= '<div class="row">';
    foreach ($gallery_loop as $item) {

      $aos = $item['aos'] ;
      $delay = $item['delay'] ;
      $duration = $item['duration'] ;
      $offsetaos = $item['offsetaos'] ;
      $easing = $item['easing'] ;
      $anchor = $item['anchor'] ;
      $placement = $item['placement'] ;
      $once = $item['once'] ;
      $column = $item['column'] ;
      $el_column = ( $item['column'] != '' ) ? $item['column']  : 'col--md-5';
      $el_datay = ( $item['datay'] != '' ) ? 'data-y="'.$item['datay'].'"'  : 'data-y="2"';
      $image = wp_get_attachment_url( $item['img'],'full' );
        $out .= '<div class="col col--sm-6 '. $el_column .'">';
          $out .= '<div class="__item" '. $el_datay .' '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
            $out .= '<figure class="__image">';
              $out .= '<img class="lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'. $image .'" alt="'. get_the_title() .'" />';
          $out .= '  </figure>';

            $out .= '<div class="__content">';
              $out .= '<p>'. $item['title'].'</p>';
              $out .= '<a class="__link" href="'. $image .'" data-fancybox="gallery"></a>';
            $out .= '</div>';
          $out .= '</div>';
      $out .= '  </div>';
    }
  $out .= '</div>';
  $out .= '</div>';
  $out .= '</div>';
  }

	return $out;
}
add_shortcode('crypterium_gallery_shortcode', 'crypterium_gallery');


/*-----------------------------------------------------------------------------------*/
/*	BUTTON crypterium
/*-----------------------------------------------------------------------------------*/
function crypterium_button( $atts, $content = null ) {
   extract( shortcode_atts(array(
   	//buton
   	"btnlink" => '',
   	"linktype" => '',
   	"btnstyle" => '',
   	"btnsize" => '',
   	"btnpos" => '',
   	"radius" => '50px',
    // animate
    "aos" => '',
    "delay" => '',
    "duration" => '',
    "offset" => '',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
   	//custom style
   	"btnbg" => '',
   	"border_width" => '',
   	"btnborder" => '',
   	"btncolor" => '',
   	"padding" => '',
   	"margin" => '',
   	"icon_class" => '',
   	//buton2
   	"btnlink2" => '',
   	"linktype2" => '',
   	"btnstyle2" => '',
   	"btnsize2" => '',
   	"btnpos2" => '',
   	"radius2" => '50px',
   	//custom style
   	"btnbg2" => '',
   	"border_width2" => '',
   	"btnborder2" => '',
   	"btncolor2" => '',
   	"padding2" => '',
   	"margin2" => '',
   	"icon_class2" => '',
	), $atts) );

  // btn1
	$btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
	$btnlink = vc_build_link( $btnlink );
	$btn_href = $btnlink['url'];
	$btn_title = $btnlink['title'];
	$btn_target = $btnlink['target'];
	$target = ( $btn_target != '' ) ? ' target="'.$btn_target.'" ' :'';
	$href = ( $btn_href != '' ) ? ' href="'.$btn_href.'" ' :'';
  // btn2
	$btnlink2 = ( $btnlink2 == '||' ) ? '' : $btnlink2;
	$btnlink2 = vc_build_link( $btnlink2 );
	$btn_href2 = $btnlink2['url'];
	$btn_title2 = $btnlink2['title'];
	$btn_target2 = $btnlink2['target'];
	$target2 = ( $btn_target2 != '' ) ? ' target="'.$btn_target2.'" ' :'';
	$href2 = ( $btn_href2 != '' ) ? ' href="'.$btn_href2.'" ' :'';

	if ( $btn_title !='' ){
    // btn1
    $icon = ( $icon_class != '' ) ? ' <i class="'.$icon_class.'"></i> ' :'';
		$link_type = ( $linktype =='internal' ) ? ' data-scroll'  : '';
		$btn_pos = ( $btnpos   != '' ) ? $btnpos   : 'text--center';
		$btn_size = ( $btnsize   !='custom-btn--medium' ) ? ' '.$btnsize  : ' custom-btn--medium';
		$btn_style = ( $btnstyle != '' ) ? $btnstyle : 'custom-btn--style-1';
		$btn_bg = ( $btnbg  != '' ) ? ' background-color:'.$btnbg.';' : '';
		$btn_color = ( $btncolor != '' ) ? ' color:'.$btncolor.';'         : '';
		$btn_border = ( $btnborder !='' ) ? ' border-color:'.$btnborder.';' : '';
		$btn_brdr_w = ( $border_width !='' ) ? ' border-width:'.$border_width.';' : '';
		$btn_padding = ( $padding !='' ) ? ' padding:'.$padding.';' : '';
		$btn_radius = ( $radius !='' ) ? ' border-radius:'.$radius.';' : '';
		$btn_margin = ( $margin !='' ) ? ' margin:'.$margin.';' : '';
		$customstyle = ( $btn_radius   != '' || $btn_bg   != '' || $btn_color !='' || $btn_border !='' || $btn_padding !='' || $btn_margin !='' || $btn_border_width !='' ) ? ' style="'.$btn_radius.$btn_color.$btn_bg.$btn_border.$btn_padding.$btn_margin.$btn_border_width.'"' : '';
    // btn2
    $icon2 = ( $icon_class2 != '' ) ? ' <i class="'.$icon_class2.'"></i> ' :'';
		$link_type2 = ( $linktype2 =='internal' ) ? ' data-scroll'  : '';
		$btn_pos2 = ( $btnpos2   != '' ) ? $btnpos2   : 'text--center';
		$btn_size2 = ( $btnsize2   !='custom-btn--medium' ) ? ' '.$btnsize2  : ' custom-btn--medium';
		$btn_style2 = ( $btnstyle2 != '' ) ? $btnstyle2 : 'custom-btn--style-1';
		$btn_bg2 = ( $btnbg2  != '' ) ? ' background-color:'.$btnbg2.';' : '';
		$btn_color2 = ( $btncolor2 != '' ) ? ' color:'.$btncolor2.';'         : '';
		$btn_border2 = ( $btnborder2 !='' ) ? ' border-color:'.$btnborder2.';' : '';
		$btn_brdr_w2 = ( $border_width2 !='' ) ? ' border-width:'.$border_width2.';' : '';
		$btn_padding2 = ( $padding2 !='' ) ? ' padding:'.$padding2.';' : '';
		$btn_radius2 = ( $radius2 !='' ) ? ' border-radius:'.$radius2.';' : '';
		$btn_margin2 = ( $margin2 !='' ) ? ' margin:'.$margin2.';' : '';
		$customstyle2 = ( $btn_radius2   != '' || $btn_bg2   != '' || $btn_color2 !='' || $btn_border2 !='' || $btn_padding2 !='' || $btn_margin2 !='' || $btn_border_width2 !='' ) ? ' style="'.$btn_radius2.$btn_color2.$btn_bg2.$btn_border2.$btn_padding2.$btn_margin2.$btn_border_width2.'"' : '';


    $out .= '<p class="'.$btn_pos.'" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'
>';
      if ( $btn_title !='' ){ $out .= '<a class="custom-btn   col-MB-20 '. $btn_size .' '. $btn_style .'" '.$link_type.' '. $href . $target.'  '.$customstyle.' >'.esc_html( $btn_title ).''. $icon .'</a>'; }
      if ( $btn_title2 !='' ){ $out .= '<a class="custom-btn   col-MB-20 '. $btn_size2 .' '. $btn_style2 .'" '.$link_type2.' '. $href2 . $target2.'  '.$customstyle2.' >'.esc_html( $btn_title2 ).''. $icon2 .'</a>'; }
      $out .= '</p>';

	} else {
    'please add title';
  }

	return $out;
}
add_shortcode('crypterium_button_shortcode', 'crypterium_button');

/*-----------------------------------------------------------------------------------*/
/*	VIDEO
/*-----------------------------------------------------------------------------------*/
function crypterium_video( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "url" => '',
    "img" => '',
    "max" => '300',
    "bg" => '',
    "icon" => '',
    "title" => '',
    // animate
    "aos" => 'fade-up',
    "delay" => '',
    "duration" => '',
    "offset" => '',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
    //custom style
    "tlineh" => '',
    "tsize" => '',
    "tcolor" => '',
  ), $atts) );

  $image = wp_get_attachment_url( $img,'full' );
  $bg_url = wp_get_attachment_url( $bg,'full' );
  $el_bg = ( $bg != '' ) ? 'data-src="'. $bg_url .'"' : '';
  $el_max = ( $max != '' ) ? 'style="max-width:'. $max .'px"' : '';
  $el_bg_c = ( $bg != '' ) ? ' __bg lazy ' : '';

	$out = '';
  $out .= '<div class="video-container" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
    if (  $image != '' ){ $out .= '<img class="img-responsive center-block lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="'.get_the_title().'" />'; }
    $out .= '<div class="__video" '.$el_max.'>';
      $out .= '<div class="__wrp">';
        $out .= '<div class="embed-responsive '.$el_bg_c.'" '.$el_bg.'>';
          $out .= '<div class="__bg embed-responsive-item">';
            $out .= '<div class="__btn_wrp">';
              $out .= '<a class="__play-btn  circled" data-fancybox href="'. $url .'"></a>';

              if (  $title !='' ){ $out .= ''.crypterium_element( $title, $tag='span', $class='__desc color-black', $tlineh, $tsize, $tcolor ).''; }
            $out .= '</div>';
          $out .= '</div>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</div>';
  $out .= '</div>';

	return $out;
}
add_shortcode('crypterium_video_shortcode', 'crypterium_video');

/*-----------------------------------------------------------------------------------*/
/*	HERO_HOME
/*-----------------------------------------------------------------------------------*/

function crypterium_facts( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"row" => 'row--xs-middle',
  	"column" => 'col--sm-4 col--md-4',
  	"type" => 'facts--light-color',
  	"css" => '',
  	"count_loop" => '',
	), $atts) );

  $loop = (array) vc_param_group_parse_atts($count_loop);

	$out .= '<div class="facts '. $type .' text--center text--sm-left '.crypterium_vc_custom_css_class($css).'">';
		$out .= '<div class="__inner">';
			$out .= '<div class="row '. $row .'">';

        foreach ( $loop as $item ) {

          $el_from = ( isset( $item['from'] ) !='' ) ? 'data-from="'.$item['from'].'"'  : '';
          $el_to = ( isset( $item['to'] ) !='' ) ? 'data-to="'.$item['to'].'"'  : '';
          $el_dec = ( isset( $item['dec'] ) !='' ) ? 'data-decimals="'.$item['dec'].'"'  : '';
          $el_bef = ( isset( $item['before'] ) !='' ) ? 'data-before="'.$item['before'].'"'  : '';
          $el_af = ( isset( $item['after'] ) !='' ) ? 'data-after="'.$item['after'].'"'  : '';
          $el_color = ( isset( $item['color'] ) !='' ) ? 'style="color:'.$item['color'].'"'  : '';

          $datas = array($el_from, $el_to, $el_dec, $el_bef, $el_af, );
          $data = implode(" ", $datas);

        	$out .= '<div class="col '.$item['column'].'">';
  						$out .= '<div class="__item text--sm-left" '. $el_color .'>';
  							$out .= '<span class="num js-count" '. $data .' '. $el_color .'></span><br> '.$item['datatitle'].'';
  						$out .= '</div>';
  					$out .= '</div>';
        }

			$out .= '</div>';
		$out .= '</div>';
	$out .= '</div>';

	return $out;
}
add_shortcode('crypterium_facts_shortcode', 'crypterium_facts');


/*-----------------------------------------------------------------------------------*/
/*	TIMELINE
/*-----------------------------------------------------------------------------------*/
function crypterium_timeline( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"current" => '',
  	"title" => '',
    "sp" => '',
    "bg" => '',
  	"subtitle" => '',
  	"type" => 'timeline--style-2',
  	"type_color" => 'timeline--dark-color',
  	"desc" => '',
  	"items" => '',
  	"active" => '',
  	"date" => '',
  	"desc" => '',
    "h_color" => 'default',
    "margin" => '',
    "alignment" => 'text--center',
  ), $atts) );

  $t_items = (array) vc_param_group_parse_atts($items);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

  $out = '';
	$out .= '<section class="crypterium_timeline_shortcode '. $el_sp . " " . $el_bg . ' '.crypterium_vc_custom_css_class($css).'">';
  	$out .= '<div class="grid grid--container">';

      $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
      $el_margin = ( $margin !='' ) ? $margin : '60' ;
    	$out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
        if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
        if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
    	$out .= '</div>';

      if (  $type =='timeline--style-2' ){
    	$out .= '<div class="row row--xs-middle">';
      	$out .= '<div class="col col--md-10">';
      }
        	$out .= '<div class="timeline '. $type .' '. $type_color .'">';

          if (  $type =='timeline--style-1' ){
          $out .= '<div class="row row--xs-middle row--no-gutters">
            <div class="col col--xs-10">
              <div class="row row--xs-middle row--xs-center row--no-gutters" style="min-width: 750px;">';
            }
                foreach( $t_items as $item ) {
                  $el_active = (  $item['active'] =='y' ) ? '__item--active' : '';
                  $el_active2 = (  $item['active'] =='y' AND  $item['current']  !='y' ) ? '__line--active' : '';
                  $el_current = (  $item['current'] =='y' ) ? '__item--current' : '';
                	$out .= '<div class="__item '. $el_active .' '. $el_current .'">';
                                                          $out .= '<i class="__point"></i>';
                      if (  $type =='timeline--style-2' OR $type =='' ){ $out .= '<span class="__line '. $el_active2 .'"></span>'; }
                  		if ( isset( $item['date'] ) != '' ){ $out .= '<span class="__text __text--first">'.  $item['date']  .'</span>'; }
                   if ( isset( $item['title'] ) !='' ){ $out .= '<h5 class="__text __text--second">'.  $item['title']  .'</h5>'; }
                  		if (  $type =='timeline--style-2' OR $type =='' ){ if ( isset( $item['desc'] ) != '' ){ $out .= '<p>'.  $item['desc']  .'</p>'; } }

                	$out .= '</div>';
                  if (  $type =='timeline--style-1' ){ $out .= '<span class="__line '. $el_active2 .'"></span>'; }
                } // end item

            	$out .= '</div>'; //
          if (  $type =='timeline--style-1' ){
                $out .= '</div>'; //
        	$out .= '</div>'; //
        	$out .= '</div>'; // end timeline
        }

          if (  $type =='timeline--style-2' ){
      	$out .= '</div>';
    	$out .= '</div>';
    }
  	$out .= '</div>';
	$out .= '</section>';

	return $out;

}
add_shortcode('crypterium_timeline_shortcode', 'crypterium_timeline');

/*-----------------------------------------------------------------------------------*/
/*	HOWITWORKS
/*-----------------------------------------------------------------------------------*/
function crypterium_howitworks( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"current" => '',
  	"title" => '',
    "sp" => '',
    "bg" => '',
  	"subtitle" => '',
  	"type" => '1',
  	"desc" => '',
  	"items" => '',
  	"active" => '',
  	"date" => '',
  	"desc" => '',
    "h_color" => '',
    "margin" => '',
    "alignment" => 'text--center',
    // animate
    "aos" => 'fade',
    "delay" => '100',
    "duration" => '',
    "offset" => '100',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
  ), $atts) );

  $t_items = (array) vc_param_group_parse_atts($items);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

  $out = '';
	$out .= '<section class="crypterium_howitworks_shortcode '. $el_sp . " " . $el_bg . ' '.crypterium_vc_custom_css_class($css).'">';
  	$out .= '<div class="grid grid--container">';

      $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
      $el_margin = ( $margin !='' ) ? $margin : '60' ;
    	$out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
        if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
        if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
    	$out .= '</div>';

    	$out .= '<div class="steps text--center">';
      	$out .= '<div class="__inner">';
        	$out .= '<div class="row">';

          foreach( $t_items as $item ) {

            $aos = $item['aos'] ;
            $delay = $item['delay'] ;
            $duration = $item['duration'] ;
            $offsetaos = $item['offsetaos'] ;
            $easing = $item['easing'] ;
            $anchor = $item['anchor'] ;
            $placement = $item['placement'] ;
            $once = $item['once'] ;

            $out .= '<div class="col col--xs-6 col--md-4 col--lg-2">';
              $out .= '<div class="__item" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
                $out .= '<i class="__point"></i>';

                 if ( isset( $item['title'] ) !='' ){ $out .= '<h5 class="__title">'. esc_attr( $item['title'] ) .'</h5>'; }
              $out .= '</div>';
            $out .= '</div>';
          } // end item

          $out .= '</div>';
      	$out .= '</div>';
    	$out .= '</div>';

  	$out .= '</div>';
	$out .= '</section>';

	return $out;

}
add_shortcode('crypterium_howitworks_shortcode', 'crypterium_howitworks');

/*-----------------------------------------------------------------------------------*/
/*	PROGRESS
/*-----------------------------------------------------------------------------------*/
function crypterium_progress( $atts, $content = null ) {
   extract( shortcode_atts(array(
   	"size" => 'progress--big',
   	"pitems" => '',
   	"citems" => '',
    "sp" => '',
    "bg" => '',
   	"percent" => '',
   	"title" => '',
   	"subtitle" => '',
    "h_color" => 'default',
    "margin" => '',
    "alignment" => 'text--center',
    "btnlink" => '',
    "bar" => '',
    "max" => '',
    //custom style
    "ttlineh" => '',
    "ttsize" => '',
    "ttcolor" => '',
    "tlineh" => '',
    "tsize" => '',
    "tcolor" => '',
    "dlineh" => '',
    "dsize" => '',
    "dcolor" => '',
   	"css" => '',
	), $atts) );

  $p_items = (array) vc_param_group_parse_atts($pitems);
  $c_items = (array) vc_param_group_parse_atts($citems);
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

	$out = '';

     $out .= '<section class="crypterium_progress_shortcode '. $el_sp . " " . $el_bg . ' '.crypterium_vc_custom_css_class($css).'">';
       $out .= '<div class="grid grid--container">';

        $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
        $el_margin = ( $margin !='' ) ? $margin : '60' ;
         $out .= '<div class="section-heading '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
           if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
           if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
         $out .= '</div>';

         $out .= '<div class="row row--xs-middle">';
           $out .= '<div class="col col--md-10">';
             $out .= '<div class="token-sale">';

               $out .= '<div class="progress '. $size . '">';
                 $out .= '<div class="progress__inner">';
                   $out .= '<div class="__bar __bar--animate" style="width: '.$bar.'%"></div>';
                     foreach( $p_items as $item ) {
                       if ( isset( $item['percent_title'] ) !='' ){ $out .= '<span class="__label" style="left: '. esc_attr( $item['percent'] ) .'%"><strong>'. esc_html( $item['percent_title'] ) .'</strong></span>'; }
                     }
                   $out .= '<span class="__max-val"><strong>'.$max.'</strong></span>';
                 $out .= '</div>';
               $out .= '</div>'; // progress

               $out .= '<div class="row row--md-between row--no-gutters">';
                 $out .= '<div class="col-MB-20">';
                   $out .= '<div class="__inner">';

                    foreach( $c_items as $items ) {

                      $image = wp_get_attachment_url( $items['img'],'full' );
                      $out .= '<div class="__item">';
                        $out .= '<div class="b-table">';
                         $out .= '<div class="cell v-top">';
                          if ( isset( $items['img'] ) !='' ){ $out .= '<img class="__ico lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="'.get_the_title().'" />'; }
                         $out .= '</div>';

                         $out .= '<div class="cell v-top">';
                           $out .= '<span class="__num">'. esc_html( $items['coin_total'] ) .'</span> '. esc_html( $items['coin_title'] ) .'';
                         $out .= '</div>';
                        $out .= '</div>';
                      $out .= '</div>'; // item

                    }

                   $out .= '</div>';
                 $out .= '</div>';

                 $out .= '<div class="col-MB-20">';

                   if (  $btnlink != '' ){
                     $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
                     $btnlink = vc_build_link( $btnlink );
                     $btn_title = $btnlink['title'];
                     $btn_target = $btnlink['target'];
                     $btn_href = $btnlink['url'];
                     $out .= '<p>'.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-1', $btnbg, $btncolor, $icon=false ).'</p>';
                   }
                 $out .= '</div>'; // button

               $out .= '</div>';
             $out .= '</div>'; // token-sale

           $out .= '</div>';
         $out .= '</div>';
       $out .= '</div>';
     $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_progress_shortcode', 'crypterium_progress');

/*-----------------------------------------------------------------------------------*/
/*	DOCUMENTS
/*-----------------------------------------------------------------------------------*/
function crypterium_documents( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"items" => '',
    // animate
    "aos" => 'zoom-in',
    "delay" => '100',
    "duration" => '100',
    "offset" => '',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
  ), $atts) );

  $t_items = (array) vc_param_group_parse_atts($items);

  $out = '';
  $out .= '<div class="documents documents--style-2 '.crypterium_vc_custom_css_class($css).'">';
    $out .= '<div class="__inner">';
      $out .= '<div class="row">';

        foreach( $t_items as $item ) {

          $tlineh = $item['tlineh'] ;
          $tsize = $item['tsize'] ;
          $tcolor = $item['tcolor'] ;
          $isize = $item['isize'] ;
          $icolor = $item['icolor'] ;

          $aos = $item['aos'] ;
          $delay = $item['delay'] ;
          $duration = $item['duration'] ;
          $offsetaos = $item['offsetaos'] ;
          $easing = $item['easing'] ;
          $anchor = $item['anchor'] ;
          $placement = $item['placement'] ;
          $once = $item['once'] ;

          $out .= '<div class="col col--xs-6 col--sm-3">';
            $el_url = (  $item['url'] != ''  ) ? 'href="'.$item['url'].'"'  : 'href="#0"';

            $out .= '<a '.$el_url.' class="__document" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
           if ( isset( $item['icon'] ) !='' ){ $out .= ''.crypterium_icon( $item['icon'], $isize, $icolor ).''; }
              if ( isset( $item['title'] ) !='' ){ $out .= ''.crypterium_element( $item['title'], $tag='span', $class='h5', $tlineh, $tsize, $tcolor ).''; }
            $out .= '</a>';

          $out .= '</div>';
        } // end item

      $out .= '</div>';
    $out .= '</div>';
  $out .= '</div>';

	return $out;

}
add_shortcode('crypterium_documents_shortcode', 'crypterium_documents');

/*-----------------------------------------------------------------------------------*/
/*	TABLE - LIST
/*-----------------------------------------------------------------------------------*/
function crypterium_table( $atts, $content = null ) {
  extract( shortcode_atts(array(
  	"type" => 'table',
  	"items" => '',
    // animate
    "aos" => 'fade-right',
    "delay" => '',
    "duration" => '',
    "offset" => '20',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
  ), $atts) );

  $t_items = (array) vc_param_group_parse_atts($items);

  $out = '';

  if ( $type =='table' ){
    $out .= '<div class="crypterium_table_shortcode '.crypterium_vc_custom_css_class($css).'" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
      $out .= '<table class="theme-table col-MB-35" style="line-height: 2;">';
        foreach( $t_items as $item ) {
          $out .= '<tr>';
            $out .= '<td>';
              if ( isset( $item['title'] ) !='' ){ $out .= ''.crypterium_element( $item['title'], $tag='h5', $class='h5', $tlineh, $tsize, $tcolor ).''; }
            $out .= '</td>';
            $out .= '<td>'. $item['desc'] .'</td>';
          $out .= '</tr>';
        }
      $out .= '</table>';
    $out .= '</div>';
  } else {
    $out .= '<div class="crypterium_table_shortcode list-with-ico '.crypterium_vc_custom_css_class($css).'">';
      foreach( $t_items as $item ) {

        $aos2 = $item['aos2'] ;
        $delay2 = $item['delay2'] ;
        $duration2 = $item['duration2'] ;
        $offsetaos2 = $item['offsetaos2'] ;
        $easing2 = $item['easing2'] ;
        $anchor2 = $item['anchor2'] ;
        $placement2 = $item['placement2'] ;
        $once2 = $item['once2'] ;

        $out .= '<div class="list__item" '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .'>';
          $out .= '<div class="b-table">';
            $out .= '<div class="cell v-middle">';
              	$out .= ''.crypterium_icon( $item['icon'], $isize, $icolor ).'';
            $out .= '</div>';

            $out .= '<div class="cell v-middle">';
                if ( isset( $item['title'] ) !='' ){ $out .= ''.crypterium_element( $item['title'], $tag='h5', $class='h5', $tlineh, $tsize, $tcolor ).''; }
              $out .= '</div>';
            $out .= '</div>';
        $out .= '</div>';
      }
    $out .= '</div>';
  }

	return $out;

}
add_shortcode('crypterium_table_shortcode', 'crypterium_table');

/*-----------------------------------------------------------------------------------*/
/*	TEAM_VC
/*-----------------------------------------------------------------------------------*/
function crypterium_team_vc_type( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => '',
    "icon" => '',
    "img" => '',
    "img_w" => '110',
    "img_h" => '110',
    "title" => '',
    "subtitle" => '',
    "desc" => '',
    "url" => '',
    // animate
    "aos" => 'zoom-in',
    "delay" => '50',
    "duration" => '300',
    "offset" => '50',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
    //custom style
    "tlineh" => '',
    "tsize" => '',
    "tcolor" => '',
    "nlineh" => '',
    "nsize" => '',
    "ncolor" => '',
  ), $atts) );

  $image = wp_get_attachment_url( $img, 'full' );
  $el_type = ( $type !='') ? $type : 'team--style-2';

  $out = '';
  $out .= '<div class="team '.$el_type.' team--dark-color">';
    $out .= '<!-- start item -->';

      $out .= '<div class="__item  text--center" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
       $out .= '<figure class="__image  center-block circled">';

        if ( $img !='' ){ $out .= '<img class="img-responsive circled lazy" src="'. get_theme_file_uri() .'/images/blank.gif" width="'.$img_w.'" height="'.$img_h.'" data-src="'.$image.'" alt="'.get_the_title().'" />'; }

         $out .= '<div class="social-btns">';
           $out .= '<a class="'.$icon.'  circled" target="_blank" href="'.$url.'"></a>';
         $out .= '</div>';
      $out .= '</figure>';

      $out .= '<div class="__content">';
        if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h5', $class='__title', $tlineh, $tsize, $tcolor ).''; }
        if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='span', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
        if ( $type =='2' ){
          if ( isset( $desc ) !='' ){ $out .= ''.crypterium_element( $desc, $tag='span', $class='__desc', $ttlineh, $ttsize, $ttcolor ).''; }
        } else {
          if ( isset( $desc ) !='' ){ $out .= ''.crypterium_element( $desc, $tag='p', $class='__desc', $ttlineh, $ttsize, $ttcolor ).''; }
        }

      $out .= '</div>';

     $out .= '</div>';
    $out .= '</div>';

	return $out;
}
add_shortcode('crypterium_team_vc_type_shortcode', 'crypterium_team_vc_type');

/*-----------------------------------------------------------------------------------*/
/*	CALL TO ACTION
/*-----------------------------------------------------------------------------------*/
function crypterium_calltoaction( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => 'type1',
    "btnlink" => '',
    // animate
    "aos" => 'fade-right',
    "delay" => '',
    "duration" => '',
    "offset" => '50',
    "easing" => 'ease',
    "anchor" => '',
    "placement" => '',
    "once" => '',
    // animate2
    "aos2" => 'fade-left',
    "duration2" => '',
    "offset2" => '50',
    "easing2" => 'ease',
    "anchor2" => '',
    "placement2" => '',
    "once2" => '',
  ), $atts) );

  $out = '';
  if (  $type =='type1' OR $type =='' ){
	$out .= '<div class="crypterium_calltoaction_shortcode row row--xs-middle row--xs-center  text--center">';
		$out .= '<div class="col col--lg-auto">';
			$out .= '<div '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
				$out .= ''.do_shortcode( $content ).'';
			$out .= '</div>';
		$out .= '</div>';

		$out .= '<div class="col col--lg-auto">';
			$out .= '<div '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .'>';
				$out .= '<br class="hide--lg">';
        if (  $btnlink != '' ){
          $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
          $btnlink = vc_build_link( $btnlink );
          $btn_title = $btnlink['title'];
          $btn_target = $btnlink['target'];
          $btn_href = $btnlink['url'];
          $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2', $btnbg, $btncolor, $icon=false ).'';
        }
			$out .= '</div>';
		$out .= '</div>';
	$out .= '</div>';
} else {
  $out .= '<div class="call-to-action  text--center text--md-left">
    <div class="row row--md-center row--md-between">
      <div class="col col--md-auto">
        <div class="section-heading section-heading--white">
          	'.do_shortcode( $content ).'
        </div>
      </div>

      <div class="col hide--md col-MB-30"></div>

      <div class="col col--md-auto">';
        if (  $btnlink != '' ){
          $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
          $btnlink = vc_build_link( $btnlink );
          $btn_title = $btnlink['title'];
          $btn_target = $btnlink['target'];
          $btn_href = $btnlink['url'];
          $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-6', $btnbg, $btncolor, $icon=false ).'';
        }
      $out .= '</div>

    </div>
  </div>';
}
	return $out;
}
add_shortcode('crypterium_calltoaction_shortcode', 'crypterium_calltoaction');

/*-----------------------------------------------------------------------------------*/
/*	sign_in
/*-----------------------------------------------------------------------------------*/
function crypterium_login( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "type" => 'logs',
    "title" => '',
    "img" => '',
    "btnlink" => '',
    "forgot" => 'I forgot my password',
    "sp" => '',
    "bg" => '',
  ), $atts) );

  $logo = wp_get_attachment_url( $img,'full' );
  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

  $out = '';

	$out .= '<section class="crypterium_login_shortcode '. $el_sp . " " . $el_bg . '">';
  	$out .= '<div class="grid grid--container">';
    	$out .= '<div class="authorization authorization--login">';

        if (  $logo != '' ){
        	$out .= '<a class="site-logo" href="'. esc_url( home_url( '/' ) ) .'">';
          	$out .= '<img class="img-responsive" width="175" height="42" src="'. $logo .'" alt="demo">';
        	$out .= '</a>';
        }

      	$out .= '<div id="login-register-password">';
        if (  $type =='log' ){
        	$out .= '<form class="authorization__form" method="post" action="'. home_url() .'/wp-login.php">';
          	if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h3', $class='__title', $tlineh, $tsize, $tcolor ).''; }

          	$out .= '<div class="input-wrp">';
            	$out .= '<input class="textfield" id="user_login" name="log" type="text"  placeholder="Username" />';
          	$out .= '</div>';

          	$out .= '<div class="input-wrp">';
            	$out .= '<i class="textfield-ico fontello-eye"></i>';
            	$out .= '<input class="textfield" id="user_pass" name="pwd" type="password"  placeholder="Password" />';
          	$out .= '</div>';

          	$out .= '<p>';
            	$out .= '<label class="checkbox" for="rememberme">';
              	$out .= '<input type="checkbox" name="rememberme" value="forever" checked="checked" id="rememberme" tabindex="13" />';
              	$out .= '<i class="fontello-check"></i><span>Remember me</span>';
            	$out .= '</label>';
          	$out .= '</p>';
          	$out .= '<p>';
            	$out .= '<a href="'. wp_lostpassword_url( home_url() ) .'">'.$forgot.'</a>';

            	$out .= ''. do_action('login_form') .'';

            	$out .= '<input class="custom-btn custom-btn--medium custom-btn--style-2 wide" type="submit" name="user-submit" value="login" tabindex="14" />';
            	$out .= '<input type="hidden" name="redirect_to" value="'. esc_attr($_SERVER['REQUEST_URI']).'" />';
  						$out .= '<input type="hidden" name="user-cookie" value="1" />';

          	$out .= '</p>';

            if (  $btnlink != '' ){
              $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
              $btnlink = vc_build_link( $btnlink );
              $btn_title = $btnlink['title'];
              $btn_target = $btnlink['target'];
              $btn_href = $btnlink['url'];
              $out .= '<p class="text--center">'.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='', $btnbg, $btncolor, $icon=false ).'</p>';
            }
        	$out .= '</form>';

        } else {
        	$out .= '<div class="row row--xs-middle">';
        	$out .= '<div class="col">';
            $out .= '<form class="authorization__form" method="post" action="'. site_url('wp-login.php?action=register', 'login_post') .'">';
              if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h3', $class='__title', $tlineh, $tsize, $tcolor ).''; }

              $out .= '<div class="input-wrp">';
                $out .= '<input class="textfield" id="user_login" name="user_login" type="text"  placeholder="E-mail" />';
              $out .= '</div>';

              $out .= '<div class="input-wrp">';
                $out .= '<i class="textfield-ico fontello-eye"></i>';
                $out .= '<input class="textfield" id="user_email" name="user_email" type="password"  placeholder="Password" />';
              $out .= '</div>';

              $out .= '<p>';
                $out .= '<a href="'. wp_lostpassword_url( home_url() ) .'">'.$forgot.'</a>';

                $out .= ''. do_action('register_form') .'';
                $out .= '<input class="custom-btn custom-btn--medium custom-btn--style-2 wide" type="submit" name="user-submit" value="Sign Up" tabindex="14" />';
                  $out .= '<input type="hidden" name="redirect_to" value="'. esc_attr($_SERVER['REQUEST_URI']) . '?register=true' .'" />';
                  $out .= '<input type="hidden" name="user-cookie" value="1" />';
              $out .= '</p>';

              if (  $btnlink != '' ){
                $btnlink = ( $btnlink == '||' ) ? '' : $btnlink;
                $btnlink = vc_build_link( $btnlink );
                $btn_title = $btnlink['title'];
                $btn_target = $btnlink['target'];
                $btn_href = $btnlink['url'];
                $out .= '<p class="text--center">'.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='', $btnbg, $btncolor, $icon=false ).'</p>';
              }
            $out .= '</form>';
          $out .= '</div>';
          $out .= '</div>';

        }

      	$out .= '</div>'; // login-register-password

    	$out .= '</div>';
  	$out .= '</div>';
	$out .= '</section>';

	return $out;
}
add_shortcode('crypterium_login_shortcode', 'crypterium_login');

/*-----------------------------------------------------------------------------------*/
/*	search-form
/*-----------------------------------------------------------------------------------*/
function crypterium_searchform( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "bg" => '',
    "pbg" => '',
    "pc" => '',
  ), $atts) );

  $out = '';
	$out .= '<form class="form--horizontal" role="search" method="get" id="searchform" action="' . esc_url( home_url( '/' ) ) . '" style="background-color:'.$bg.';">
  	<div class="b-table">
  		<div class="cell v-middle">
  			<div class="input-wrp">
  				<input class="textfield" type="text" value="' . get_search_query() . '" placeholder="'. esc_attr__( 'Search for...', 'crypterium' ) .'" name="s" id="s" >
  			</div>
  		</div>

  		<div class="cell v-middle">
  			<button class="custom-btn custom-btn--medium custom-btn--style-2" id="searchsubmit" type="submit" role="button" style="background-color:'.$pbg.'; color:'.$pc.'">'. esc_html__( 'Search for...', 'crypterium' ) .'</button>
  		</div>
  	</div>
  </form>
  ';

	return $out;
}
add_shortcode('crypterium_searchform_shortcode', 'crypterium_searchform');

/*-----------------------------------------------------------------------------------*/
/*	play button
/*-----------------------------------------------------------------------------------*/
function crypterium_play_btn( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "url" => '',
    "style" => '',
    "class" => '',
  ), $atts) );

  $id = '_playbutton' . uniqid() ;
  if ( $style != '' ) {
    $out = '<style>.'.$id.' { '. $style .' }</style>';
  }

	$out .= '<a class="btn-play--big '.$id.' '.$class.'" data-fancybox="" href="'. $url .'"></a>';

	return $out;
}
add_shortcode('crypterium_play_btn_shortcode', 'crypterium_play_btn');

/*-----------------------------------------------------------------------------------*/
/*	tabs
/*-----------------------------------------------------------------------------------*/
function crypterium_banner( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "items" => '',
    "title" => '',
    "subtitle" => '',
    "price" => '',
    "img" => '',
    "simg" => '',
    "url" => '',
    "style" => '',
    "class" => '',
    "bg" => '',
    "sp" => '',
    // animate
    "aos" => '',
    "delay" => '',
    "duration" => '',
    "offset" => '',
    "easing" => '',
    "anchor" => '',
    "placement" => '',
    "once" => '',
    //custom style
   	"ttlineh" => '',
   	"ttsize" => '',
   	"ttcolor" => '',
   	"tlineh" => '',
   	"tsize" => '',
   	"tcolor" => '',
   	"dlineh" => '',
   	"dsize" => '',
   	"dcolor" => '',
  ), $atts) );

  $simage = wp_get_attachment_url( $simg,'full' );
  $image = wp_get_attachment_url( $img,'full' );
  $id = 'crypterium_banner' . uniqid() ;
  if ( $style != '' ) {
    $out = '<style>.'.$id.' { '. $style .' }</style>';
  }

  $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--light-blue-bg';
  $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

  $out .= '<section class="'. $el_sp . " " . $el_bg . ' banner" style="  background-repeat: no-repeat;  background-position: left 54vw bottom 67%; background-image: url('.$image.');">';
    $out .= '<div class="grid grid--container">';
      $out .= '<div class="row row--xs-center">';
        $out .= '<div class="col col--md-9 col--lg-6">';
          $out .= '<div '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
            $out .= '<div class="section-heading  col-MB-30">';
              if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
              if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
            $out .= '</div>';

            $out .= '<div class="content-container">';
              $out .= ''.do_shortcode( $content ).'';
            $out .= '</div>';
          $out .= '</div>';
        $out .= '</div>';

        $out .= '<div class="col col-MB-40 col-lg-MB-0"></div>';

        $out .= '<div class="col">';
          $out .= '<div class="img-place">';
            $out .= '<div class="hide--lg">';

              $out .= '<img class="img-responsive center-block  lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$simage.'" alt="demo" />';
            $out .= '</div>';
            $out .= '<span class="price">'.$price.'</span>';
          $out .= '</div>';
        $out .= '</div>';
      $out .= '</div>';
    $out .= '</div>';
  $out .= '</section>';

	return $out;
}
add_shortcode('crypterium_banner_shortcode', 'crypterium_banner');

/*-----------------------------------------------------------------------------------*/
/*	events
/*-----------------------------------------------------------------------------------*/
function crypterium_events( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "items" => '',
  ), $atts) );

  $el_items = (array) vc_param_group_parse_atts($items);

  $out .= '<div class="grid">';
    $out .= '<div class="events events--slider" data-slick=\'{"autoplay": true, "dots": true, "speed": 1000}\'>';
      foreach( $el_items as $item ) {
        $out .= '<div class="__item __item--preview">
          <div class="__content">

            <span class="__date-post">
              <span class="b-table">
                <span class="cell v-middle"><span class="__day">'.$item['day'].'</span></span>
                <span class="cell v-middle">'.$item['month'].' <br> '.$item['year'].'</span>
              </span>
            </span>';

            $out .= '<h3 class="__title h4">';

              if (   $item['btnlink'] != '' ){
                $btnlink = ( $item['btnlink'] == '||' ) ? '' : $item['btnlink'];
                $btnlink = vc_build_link( $btnlink );
                $btn_title = $btnlink['title'];
                $btn_target = $btnlink['target'];
                $btn_href = $btnlink['url'];
                $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='', $btnbg, $btncolor, $icon=false ).'';
              }

            $out .= '</h3>';

            if ( isset( $item['contents'] ) !='' ){ $out .= ''.crypterium_element( $item['contents'], $tag='p', $class='__text', $tlineh, $tsize, $tcolor ).''; }

          $out .= '</div>';
        $out .= '</div>';
      }
    $out .= '</div>';
  $out .= '</div>';

	return $out;
}
add_shortcode('crypterium_events_shortcode', 'crypterium_events');

/*-----------------------------------------------------------------------------------*/
/*	tabs
/*-----------------------------------------------------------------------------------*/
function crypterium_tabs( $atts, $content = null ) {
  extract( shortcode_atts(array(
    "items" => '',
    "url" => '',
    "style" => '',
    "class" => '',
  ), $atts) );
  $el_items = (array) vc_param_group_parse_atts($items);
  $id = '_playbutton' . uniqid() ;
  if ( $style != '' ) {
    $out = '<style>.'.$id.' { '. $style .' }</style>';
  }

  $out .= '<div class="pricing-tab">';
    $out .= '<div class="tab-container">';
      $out .= '<nav class="tab-nav  text--center">';

      foreach( $el_items as $item ) {
        $out .= '<a href="javascript:void(0);">';
        $image = wp_get_attachment_url( $item['img'],'full' );

            if ( isset( $item['img'] ) !='' ){  $out .= '<img class="lazy" width="25" height="25" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" alt="demo" />'; }
            if ( isset( $item['contents'] ) !='' ){ $out .= ''.crypterium_element( $item['contents'], $tag='strong', $class='h5', $tlineh, $tsize, $tcolor ).''; }
        $out .= '</a>';
      }

      $out .= '</nav>';

      $out .= '<div class="tab-content">';
      	$out .= ''.do_shortcode( $content ).'';
      $out .= '</div>'; // tab-content

    $out .= '</div>';
  $out .= '</div>';

	return $out;
}
add_shortcode('crypterium_tabs_shortcode', 'crypterium_tabs');

/*-----------------------------------------------------------------------------------*/
/*	PRICE LOOP TABLE
/*-----------------------------------------------------------------------------------*/
function crypterium_pricing($atts){
	extract(shortcode_atts(array(
  	'custompost'=> 'pricing',
  	'perpage' => '',
  	'order' => '',
  	'orderby' => '',
  	'postcat' => 'all',
  	'type' => 'type1',
    "title" => '',
    "subtitle" => '',
    "desc" => '',
    "h_color" => '',
    "margin" => '',
    "alignment" => 'text--center',
    "tabs" => 'no',
    // animate
    "aos" => 'fade-right',
    "delay" => '',
    "duration" => '',
    "offset" => '',
    "easing" => '',
    "anchor" => '#row--aos-anchor001',
    "placement" => '',
    "once" => '',

  	//custom style start
  	"hlineh" => '',
  	"hsize" => '',
  	"hcolor" => '',
  	"dlineh" => '',
  	"dsize" => '',
  	"dcolor" => '',
  	//price item
  	"tsize" => '',
  	"tlineh" => '',
  	"tcolor" => '',
  	"prcsize" => '',
  	"prclineh" => '',
  	"prccolor" => '',
  	"prysize" => '',
  	"prylineh" => '',
  	"prycolor" => '',
  	"listsize" => '',
  	"listlineh" => '',
  	"listcolor" => '',
  	"btnbg" => '',
  	"btncolor" => '',
	), $atts));

	if( $custompost != '' ){ $customposttype = $custompost; }else{ $customposttype = 'pricing'; }

	if ( post_type_exists( $customposttype ) ) {

		$crypterium_price_args = array(
			'post_type' => ''.$customposttype.'',
			'posts_per_page' => $perpage,
			'order' => $order,
			'orderby' => $orderby,
			'post_status' => 'publish'
		);

		if($postcat != 'all'){
			$str = $postcat;
			$arr = explode(',', $str);
			$crypterium_price_args['tax_query'][] = array( 'taxonomy' => ''.$customposttype.'', 'field' => 'slug', 'terms' => $arr );
		}

    $el_bg = ( $bg !='secton-no-bg' ) ? $bg : 'section--base-bg';
    $el_sp = ( $sp != '' ) ? $sp  : 'section'; // section padding classes

		$out = '';
    if ($type == 'type1' ){

  	$out .= '<section class="'. $el_sp . " " . $el_bg . '">';
			$out .= '<div class="grid grid--container">';
				$out .= '<div class="row row--md-center" id="row--aos-anchor001">';
					$out .= '<div class="col col--md-8 col--lg-4">';

						$out .= '<div class="row">';
							$out .= '<div class="col col--xl-10">';
								$out .= '<div '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';

                  $el_color = ( $h_color !='default' ) ? 'section-heading--white' : '' ;
                  $el_margin = ( $margin !='' ) ? $margin : '20' ;
									$out .= '<div class="section-heading  '. $el_color .' col-MB-'. $el_margin .' '. $alignment .'">';
                    if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h5', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
                    if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h2', $class='__title', $tlineh, $tsize, $tcolor ).''; }
									$out .= '</div>';
                  if ( isset( $desc ) !='' ){ $out .= ''.crypterium_element( $desc, $tag='span', $class='__desc', $ttlineh, $ttsize, $ttcolor ).''; }

								$out .= '</div>';
							$out .= '</div>';
						$out .= '</div>';

				$out .= '</div>';

					$out .= '<div class="col hide--lg col-MB-40"></div>';

					$out .= '<div class="col col--lg-8">';
					$out .= '<div class="pricing-table pricing-table--style-1">';
						$out .= '<div class="__inner">';
							$out .= '<div class="row">';

              $crypterium_price_query = new WP_Query($crypterium_price_args);
              if( $crypterium_price_query->have_posts() ) :
                while ($crypterium_price_query->have_posts()) : $crypterium_price_query->the_post();

                  // price button
                  $p_column = get_post_meta( get_the_ID(), 'crypterium_price_column', true );
                  $p_btntitle = get_post_meta( get_the_ID(), 'crypterium_prcbtntitle', true );
                  $p_btntarget = get_post_meta( get_the_ID(), 'crypterium_prcbtntarget', true );
                  $p_btnlink = get_post_meta( get_the_ID(), 'crypterium_prcbtnlink', true );
                  $p_btnbg = get_post_meta( get_the_ID(), 'crypterium_prcbtnbg', true );
                  $btntarget = ( $p_btntarget != '' ) ? ' target="'.esc_html( $p_btntarget ).'"' : '';

                  // price settings
                  $price = get_post_meta( get_the_ID(), 'crypterium_price', true );
                  $period = get_post_meta( get_the_ID(), 'crypterium_period', true );
                  $price_f = get_post_meta( get_the_ID(), 'crypterium_features_list', true );
                  $p_bgcolor = get_post_meta( get_the_ID(), 'crypterium_prc_bgcolor', true );
                  $p_bgcolor = ( $p_bgcolor != '' ) ? ' style="background-color:'.esc_attr( $p_bgcolor ).';"' : '';

                  // animates
                  $aos2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos', true );
                  $delay2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_delay', true );
                  $duration2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_duration', true );
                  $offsetaos2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_offsetaos', true );
                  $easing2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_easing', true );
                  $anchor2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_anchor', true );
                  $placement2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_placement', true );
                  $once2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_once', true );

                  if ( !empty( $p_column ) ) {
						 $out .= '<div class="col '.$p_column.' col--sm-flex">';
                  } else {
                  $out .= '<div class="col col--md-4 col--sm-flex">';
                  }

							 $out .= '<div class="__item" '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .' '.$p_bgcolor.'>';
								 $out .= '<div>';

                      $out .= ''.crypterium_element( $heading=$price, $tag='h4', $class='__title', $prclineh, $prcsize, $prccolor ).'';

											$out .= '<p class="__price"><strong>'. get_the_title().'</strong></p>';

								 $out .= '</div>';

                      if ( !empty( $price_f ) ) {
                        $out .= '<ul class="__desc-list">';
                        	foreach ( $price_f as $list ) {
                            $out .= ''.crypterium_element( $heading=$list, $tag='li', $class='mt10 mb10', $listlineh, $listsize, $listcolor ).'';
                          }
                        $out .= '</ul>';
                      }

                    if ( $p_btntitle !='' ){ $out .= ''.crypterium_btn( $tag='a', $p_btntitle, $p_btnlink, $btntarget,  $btnclass='custom-btn custom-btn--medium custom-btn--style-2 wide', $btnbg, $btncolor ).''; }
							 $out .= '</div>';
						 $out .= '</div>';
                endwhile;
              endif;

							$out .= '</div>';
						$out .= '</div>';
					$out .= '</div>'; // pricing-table

    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</section>';

  }

  if ( $type == 'type2' OR  $type == 'type3' OR  $type == 'type4' ){

  if ( $type == 'type2' ) {
		$typeclass = '2';
	}else if ( $type == 'type3' ){
		$typeclass = '3';
	}else if ( $type == 'type4' ){
		$typeclass = '4';
	}else if ( $type == 'type6' ){
		$typeclass = '6';
	}else{
		$typeclass = '2';
	}

  if ($tabs != 'yes' ){
  $out .= '<section class="'. $el_sp . " " . $el_bg . '">';
    $out .= '<div class="grid grid--container">';
        $out .= '<div class="section-heading section-heading--center  col-MB-60" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
          if ( isset( $subtitle ) !='' ){ $out .= ''.crypterium_element( $subtitle, $tag='h2', $class='__subtitle', $ttlineh, $ttsize, $ttcolor ).''; }
          if ( isset( $title ) !='' ){ $out .= ''.crypterium_element( $title, $tag='h5', $class='__title', $tlineh, $tsize, $tcolor ).''; }
          if ( isset( $desc ) !='' ){ $out .= ''.crypterium_element( $desc, $tag='span', $class='__desc', $ttlineh, $ttsize, $ttcolor ).''; }
        $out .= '</div>';
  } // tabs
        if ($tabs == 'yes' ){  $out .= '<div class="tab-content__item">'; }
        $out .= '<div class="pricing-table pricing-table--style-'. $typeclass . '">';
          $out .= '<div class="__inner">';
            $out .= '<div class="row">';

            $countitem = 0;
            $crypterium_price_query = new WP_Query($crypterium_price_args);
            if( $crypterium_price_query->have_posts() ) :
              while ($crypterium_price_query->have_posts()) : $crypterium_price_query->the_post();
                $p_column = get_post_meta( get_the_ID(), 'crypterium_price_column', true );
                // price button
                $p_btntitle = get_post_meta( get_the_ID(), 'crypterium_prcbtntitle', true );
                $p_btntarget= get_post_meta( get_the_ID(), 'crypterium_prcbtntarget', true );
                $p_btnlink = get_post_meta( get_the_ID(), 'crypterium_prcbtnlink', true );
                $p_btnbg = get_post_meta( get_the_ID(), 'crypterium_prcbtnbg', true );
                $btntarget = ( $p_btntarget != '' ) ? ' target="'.esc_html( $p_btntarget ).'"' : '';

                // price settings
                $image = wp_get_attachment_url( rwmb_meta('crypterium_price_image'),'full' );
                $img_w = get_post_meta( get_the_ID(),  'crypterium_price_img_width', '35' );
                $img_h = get_post_meta( get_the_ID(),  'crypterium_price_img_height', '35' );
                $color_type = get_post_meta( get_the_ID(), 'crypterium_prc_type', 'type1' );
                $active = get_post_meta( get_the_ID(), 'crypterium_pricing_active', true );
               $active_title= get_post_meta( get_the_ID(), 'crypterium_pricing_active_title', true );
                $price = get_post_meta( get_the_ID(), 'crypterium_price_price', true );
                $period = get_post_meta( get_the_ID(), 'crypterium_period', true );
                $price_f = get_post_meta( get_the_ID(), 'crypterium_features_list', true );
                $p_bgcolor = get_post_meta( get_the_ID(), 'crypterium_prc_bgcolor', true );
                $p_bgcolor = ( $p_bgcolor != '' ) ? ' style="background-color:'.esc_attr( $p_bgcolor ).';"' : '';
                $el_img_w = ( $img_w != '' ) ? 'width="'. $img_w .'"' : 'width="34"';
                $el_img_h = ( $img_h != '' ) ? 'height="'. $img_h .'"' : 'width="60"';

                // animates
                $aos2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos', true );
                $delay2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_delay', true );
                $duration2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_duration', true );
                $offsetaos2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_offsetaos', true );
                $easing2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_easing', true );
                $anchor2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_anchor', true );
                $placement2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_placement', true );
                $once2 = get_post_meta( get_the_ID(), 'crypterium_prc_aos_once', true );

                if ( $type == 'type2' ){

                  if ( $color_type == 'type1' ){
                    $el_color_type ='__item--color-1';
                  } elseif ($color_type == 'type2' ) {
                    $el_color_type ='__item--color-2';
                  } elseif ($color_type == 'type3' ) {
                    $el_color_type ='__item--color-3';
                  } elseif ($color_type == 'type4' ) {
                    $el_color_type ='__item--color-4';
                  } else {
                    $el_color_type ='__item--color-1';
                  }

                  if ( !empty( $p_column ) ) {
                  $out .= '<div class="col '.$p_column.' col--sm-flex">';
                  } else {
                  $out .= '<div class="col col--sm-6  col--sm-flex">';
                  }

                    $out .= '<div class="__item '.$el_color_type.' " '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .'>';
                      $out .= '<div>';
                      if ( $active == 1 ){ $out .= '<span class="__label">'.$active_title.'</span>'; }
                      if ( $image !='' ){
                        $out .= '<i class="__ico">';
                          $out .= '<img class="img-responsive lazy" src="'. get_theme_file_uri() .'/images/blank.gif" data-src="'.$image.'" '.$el_img_w.' '.$el_img_h.' alt="'.get_the_title().'" />';
                        $out .= '</i>';
                      }
                        $out .= ''.crypterium_element( get_the_title(), $tag='h4', $class='__title', $prclineh, $prcsize, $prccolor ).'';

                        $out .= '<p class="__price">';
                        $out .= ''.esc_html( $price ).'';
                        if ( $period !='' ){ $out .= '<sub>/'.esc_html( $period ).'</sub>'; }
                        $out .= '</p>';

                      $out .= '</div>';

                      if ( !empty( $price_f ) ) {
                        $out .= '<ul class="__desc-list   text--left">';
                        	foreach ( $price_f as $list ) {
                            $out .= ''.crypterium_element( $heading=$list, $tag='li', $class='mt10 mb10', $listlineh, $listsize, $listcolor ).'';
                          }
                        $out .= '</ul>';
                      }

                      if ( $p_btntitle !='' ){ $out .= ''.crypterium_btn( $tag='a', $p_btntitle, $p_btnlink, $btntarget,  $btnclass='custom-btn custom-btn--medium custom-btn--style-2 wide', $btnbg, $btncolor ).''; }
                    $out .= '</div>';
                  $out .= '</div>'; // end item
                  $countitem++;
                }

                if ( $type == 'type3' OR $type == 'type6' ){
                  $typeclass = ( $active == 1 ) ? '__item--active' : '';

                  if ( !empty( $p_column ) ) {
                  $out .= '<div class="col '.$p_column.' col--sm-flex">';
                  } else {
                  $out .= '<div class="col col--md-4 col--sm-flex">';
                  }

                    $out .= '	<div class="__item '. $typeclass . '" '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .'>';

                      if ( $active == 1 ){ $out .= '<span class="__label">'.$active_title.'</span>'; }

                      $out .= '<div>';
                        $out .= ''.crypterium_element( get_the_title(), $tag='h4', $class='__title', $prclineh, $prcsize, $prccolor ).'';

                        $out .= '<p class="__price">';
                        $out .= ''.esc_html( $price ).'';
                        if ( $period !='' ){ $out .= '<sub>/'.esc_html( $period ).'</sub>'; }
                        $out .= '</p>';

                      $out .= '</div>';

                      if ( !empty( $price_f ) ) {
                        $out .= '<ul class="__desc-list">';
                        	foreach ( $price_f as $list ) {
                            $out .= ''.crypterium_element( $heading=$list, $tag='li', $class='', $listlineh, $listsize, $listcolor ).'';
                          }
                        $out .= '</ul>';
                      }

                      if ( $p_btntitle !='' ){ $out .= ''.crypterium_btn( $tag='a', $p_btntitle, $p_btnlink, $btntarget,  $btnclass='custom-btn custom-btn--medium custom-btn--style-2 wide', $btnbg, $btncolor ).''; }
                    $out .= '</div>';
                  $out .= '</div>'; // end item
                  $countitem++;
                }
                if ( $type == 'type4' ){

                  $typeclass = ( $active == 1 ) ? '__item--active' : '';

                  if ( $color_type == 'type1' ){
                    $el_color_type ='__item--color-1';
                  } elseif ($color_type == 'type2' ) {
                    $el_color_type ='__item--color-2';
                  } elseif ($color_type == 'type3' ) {
                    $el_color_type ='__item--color-3';
                  } elseif ($color_type == 'type4' ) {
                    $el_color_type ='__item--color-4';
                  } else {
                    $el_color_type ='__item--color-1';
                  }

                    if ( !empty( $p_column ) ) {
                    $out .= '<div class="col '.$p_column.' col--sm-flex">';
                    } else {
                    $out .= '<div class="col col--md-4 col--sm-flex">';
                    }

                    $out .= '	<div class="__item '. $typeclass . ' '.$el_color_type.'" '. crypterium_aos( $aos2, $delay2, $duration2, $offset2, $easing2, $anchor2, $placement2, $once2 ) .'>';

                      if ( $active == 1 ){ $out .= '<span class="__label">'.$active_title.'</span>'; }

                      $out .= '<div>';
                        $out .= ''.crypterium_element( get_the_title(), $tag='h4', $class='__title', $prclineh, $prcsize, $prccolor ).'';

                        $out .= '<p class="__price">';
                        $out .= ''.esc_html( $price ).'';
                        if ( $period !='' ){ $out .= '<sub>/'.esc_html( $period ).'</sub>'; }
                        $out .= '</p>';

                      $out .= '</div>';

                      if ( !empty( $price_f ) ) {
                        $out .= '<ul class="__desc-list">';
                        	foreach ( $price_f as $list ) {
                            $out .= ''.crypterium_element( $heading=$list, $tag='li', $class='', $listlineh, $listsize, $listcolor ).'';
                          }
                        $out .= '</ul>';
                      }

                      if ( $p_btntitle !='' ){ $out .= ''.crypterium_btn( $tag='a', $p_btntitle, $p_btnlink, $btntarget,  $btnclass='custom-btn custom-btn--medium custom-btn--style-2 wide', $btnbg, $btncolor ).''; }
                    $out .= '</div>';
                  $out .= '</div>'; // end item
                  $countitem++;
                }

              endwhile;
            endif;

            $out .= '</div>';
          $out .= '</div>';
        $out .= '</div>';
        if ($tabs == 'yes' ){  $out .= '</div>'; } // tabs shortcode
        if ($tabs != 'yes' ){
      $out .= '</div>';
    $out .= '</section>';
  }
  }

  wp_reset_postdata();
	return $out;
	}
}
add_shortcode('crypterium_pricing_shortcode', 'crypterium_pricing');


/*-----------------------------------------------------------------------------------*/
/*	TESTIMONIAL
/*-----------------------------------------------------------------------------------*/
function crypterium_products( $atts, $content = null ) {
  extract( shortcode_atts(array(
   	"loop" => '',
   	//testi style
   	"qsize" => '',
   	"qlineh" => '',
   	"qcolor" => '',
   	"nsize" => '',
   	"nlineh" => '',
   	"ncolor" => '',
   	"jsize" => '',
   	"jlineh" => '',
   	"jcolor" => '',
   	"css" => '',
	), $atts) );

	$el_loop = (array) vc_param_group_parse_atts($loop);

  $out = '';
	if ( !empty( $el_loop ) ){

  	$out .= '<style>';
  	$out .= '.goods ul {list-style:none;}';
  	$out .= '</style>';
  	$out .= '<div class="goods '. crypterium_vc_custom_css_class($bgcss) .'">';
    	$out .= '<div class="__inner">';
     $out .= '<div class="row">';

        foreach ( $el_loop as $item ) {
          $image = wp_get_attachment_url( $item['img'],'full' );
          $btnlink = ( $item['btnlink'] == '||' ) ? '' : $item['btnlink'];
          $btnlink = vc_build_link( $btnlink );
          $btn_title = $btnlink['title'];
          $btn_target = $btnlink['target'];
          $btn_href = $btnlink['url'];

          $aos = $item['aos'] ;
          $delay = $item['delay'] ;
          $duration = $item['duration'] ;
          $offsetaos = $item['offsetaos'] ;
          $easing = $item['easing'] ;
          $anchor = $item['anchor'] ;
          $placement = $item['placement'] ;
          $once = $item['once'] ;

          $title = $item['title'] ;
          $price = $item['price'] ;
          $perpage = $item['perpage'] ;

          if ( $perpage == 2 ) {
            $column = 'col col--sm-6 col--md-4 col--lg-6';
          }else if ( $perpage == 3 ){
            $column = 'col col--sm-6 col--md-4 col--lg-4';
          }else if ( $perpage == 4 ){
            $column = 'col col--sm-6 col--md-3 col--lg-3';
      		}else{
      			$column = 'col col--sm-6 col--md-4 col--lg-6';
      		}

      	$out .= '<div class="'. $column .'">';
        	$out .= '<div class="__item" '. crypterium_aos( $aos, $delay, $duration, $offset, $easing, $anchor, $placement, $once ) .'>';
          	if (  isset( $item['img'] ) != '' ){
              $out .= '<figure class="__image">';
            	$out .= '<img class="lazy" src="'. get_theme_file_uri() .'/images/blank.gif" width="215" height="240" data-src="'. $image .'" alt="demo" />';
              	$out .= '<a href="'. $btn_href .'"></a>';
           $out .= '</figure>';
            }
          	$out .= '<div class="__content">';
            	if (  isset( $item['title'] ) != '' ){ $out .= '<h5 class="__title"><a href="'. $btn_href .'">'. $title .'</a></h5>'; }
								$out .= ''. $item['desc'] .'';
           if (  isset( $item['price'] ) != '' ){ $out .= '<span class="__price">'. $price .'</span>'; }
              if (  isset( $item['btnlink'] ) != '' ){
              	$out .= '<p class="text--center">';
                  $out .= ''.crypterium_btn( $tag='a', $btn_title, $btn_href, $btn_target, $btnclass='custom-btn custom-btn--medium custom-btn--style-2', $btnbg, $btncolor, $icon=$item['i'] ).'';
              	$out .= '</p>';
              }
            $out .= '</div>';
      		$out .= '</div>';
      	$out .= '</div>';
      }
      $out .= '</div>';
		$out .= '</div>';
	$out .= '</div>';

 	}

	return $out;
}
add_shortcode('crypterium_products_shortcode', 'crypterium_products');
