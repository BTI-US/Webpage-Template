<?php
/**
 * The sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Crypterium
 * @since Crypterium 1.0
 */

if (  is_active_sidebar( 'sidebar-1' )  ) :  dynamic_sidebar( 'sidebar-1' );  endif; ?>
