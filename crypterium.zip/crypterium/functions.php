<?php

	// Theme functions
	include_once get_template_directory() . '/includes/theme-init.php';
