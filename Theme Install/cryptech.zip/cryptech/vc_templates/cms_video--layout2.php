<?php
extract(shortcode_atts(array(                           
    'video_bg_image' => '',                  
    'btn_video_text' => '',                  
    'video_url' => 'https://www.youtube.com/watch?v=ytPzZBDbpTE',                  
    'animation' => '',                  
    'el_class' => '',                  
), $atts));
$html_id = cmsHtmlID('cms-video');
$image_url = '';
if (!empty($atts['video_bg_image'])) {
    $attachment_image = wp_get_attachment_image_src($atts['video_bg_image'], 'full');
    $image_url = $attachment_image[0];
}
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>
<div class="cms-video-wrapper <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>">
    <div class="cms-video-image"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/bg-macbook.png" /></div>
    <div class="cms-video-bg bg-image bg-overlay" style="background-image: url(<?php echo esc_url($image_url); ?>);"></div>
    <div id="<?php echo esc_attr($html_id);?>" class="cms-video cms-video-layout2">
        <div class="cms-video-inner">
            <a class="cms-video-button" href="<?php echo esc_url($video_url); ?>">
                <span class="video-icon"><i class="fa fa-play"></i></span>
                <?php if(!empty($btn_video_text)) { ?>
                    <span class="video-text"><?php echo esc_attr($btn_video_text); ?></span>
                <?php } ?>
            </a>
        </div>
    </div>
</div>