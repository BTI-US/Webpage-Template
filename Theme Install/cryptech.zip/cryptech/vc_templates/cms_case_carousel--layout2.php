<?php 
extract(shortcode_atts(array(   

    'source'               => '',
    'orderby'              => 'date',
    'order'                => 'DESC',
    'limit'                => '6',
    'post_ids'             => '',
    'el_class'             => '',  
    'animation'             => '',  
    'img_size'             => '585x435',  
    'rows'             => '1',  

), $atts));

wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-carousel-case');
extract(cms_get_posts_of_grid('case', $atts));
extract(cryptech_get_param_carousel($atts));
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
$counter = 0;
?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-grid-case-layout2 owl-carousel <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>
    <?php if (is_array($posts)):
        $sizes = explode(',',$img_size);
        $i = 0;
        foreach ($posts as $post) { 
            $default_size = end($sizes);
            if(!empty($sizes[$i])){
                $default_size = $sizes[$i];
            }
            $img_id = get_post_thumbnail_id($post->ID);
            $img = wpb_getImageBySize( array(
                'attach_id'  => $img_id,
                'thumb_size' => $default_size,
                'class'      => '',
            ));
            $thumbnail = $img['thumbnail'];
            $counter++;
            if($rows == 1){
                echo '<div class="cms-carousel-item-wrap">';
            }else{
                if($counter % $rows == 1){
                    echo '<div class="cms-carousel-item-wrap">';
                }
            }
            ?>
            <div class="grid-item">
                <div class="grid-item-inner">
                    <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) : ?>
                        <div class="grid-case-media overlay-link">
                            <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>">
                            </a>
                            <?php echo wp_kses_post($thumbnail); ?>
                        </div>
                    <?php endif; ?>
                    <div class="grid-case-meta">
                        <div class="grid-case-category post-category">
                            <?php the_terms( $post->ID, 'case-category', '', ', ' ); ?>
                        </div>
                        <h3 class="grid-case-title">
                            <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>"><?php echo esc_attr(get_the_title($post->ID)); ?></a>
                        </h3>
                    </div>
                </div>
            </div>
            <?php if($rows == 1){
                echo '</div>';
            } else {
                if($counter % $rows == 0){
                    echo '</div>';
                }
            }
        $i++;
        }
    endif; ?>
</div>