<?php
extract(shortcode_atts(array(                     
    'title' => '',              
    'wallet_bitcon' => '',              
    'qr_code' => '',              
    'el_class' => '',
    'animation' => '',

), $atts));

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );

$qr_image_url = '';
if (!empty($qr_code)) {
    $attachment_image = wp_get_attachment_image_src($qr_code, 'full');
    $qr_image_url = $attachment_image[0];
} ?>

<div class="cms-donation bg-gradient <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>">
    <h3 class="cms-donation-title">
        <?php echo wp_kses_post( $title ); ?>
    </h3>
    <div class="cms-donation-wallet">
        <?php echo wp_kses_post( $wallet_bitcon ); ?>
    </div>
	<img src="<?php echo esc_url( $qr_image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>"/>
</div>