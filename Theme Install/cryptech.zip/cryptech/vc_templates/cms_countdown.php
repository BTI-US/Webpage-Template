<?php
extract(shortcode_atts(array(   

    'date_count_down'  => '', 
    'el_class'         => '',  
    'animation'        => '',   

), $atts));
$date_count_down = !empty($date_count_down) ? $date_count_down : '2018/10/10';
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
$month = esc_html__('Month', 'cryptech');
$months = esc_html__('Months', 'cryptech');
$day = esc_html__('Day', 'cryptech');
$days = esc_html__('Days', 'cryptech');
$hour = esc_html__('Hour', 'cryptech');
$hours = esc_html__('Hours', 'cryptech');
$minute = esc_html__('Minute', 'cryptech');
$minutes = esc_html__('Minutes', 'cryptech');
$second = esc_html__('Second', 'cryptech');
$seconds = esc_html__('Seconds', 'cryptech'); ?>
<div class="cms-countdown-wraper clearfix <?php echo esc_attr( $animation_classes.' '.$el_class ); ?>" 
	data-month="<?php echo esc_attr($month) ?>"
	data-months="<?php echo esc_attr($months) ?>"
	data-day="<?php echo esc_attr($day) ?>"
	data-days="<?php echo esc_attr($days) ?>"
	data-hour="<?php echo esc_attr($hour) ?>"
	data-hours="<?php echo esc_attr($hours) ?>"
	data-minute="<?php echo esc_attr($minute) ?>"
	data-minutes="<?php echo esc_attr($minutes) ?>"
	data-second="<?php echo esc_attr($second) ?>"
	data-seconds="<?php echo esc_attr($seconds) ?>">
	<div id="getting-started" class="cms-countdown-inner" data-count-down="<?php echo esc_attr($date_count_down);?>"></div>
</div>
