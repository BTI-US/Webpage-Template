<?php
extract(shortcode_atts(array(                     
    'title' => '',              
    'title_color' => '',
    'title_font_size' => '',
    'title_line_height' => '',
    'font_weight' => '600',

    'description' => '',              
    'description_color' => '',

    'button_text' => '',
    'button_link' => '',

    'icon_type' => 'icon',                                  
    'icon_list' => 'fontawesome',
    'icon_fontawesome' => '',
    'icon_material_design' => '',
    'icon_etline' => '',
    'icon_image' => '',
    'icon_color' => '',
    'content_align' => 'center',
    'el_class' => '',
    'animation' => '',
    'icon_margin_bottom' => '',

), $atts));
$uqid = uniqid();

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );

$icon_image_url = '';
if (!empty($icon_image)) {
    $attachment_image = wp_get_attachment_image_src($icon_image, 'full');
    $icon_image_url = $attachment_image[0];
}
$icon_name = "icon_" . $icon_list;
$icon_class = isset(${$icon_name}) ? $ {$icon_name} : '';

$link = vc_build_link($button_link);
$a_href = '';
$a_target = '';
if (strlen($link['url']) > 0) {
    $a_href = $link['url'];
    $a_target = strlen($link['target']) > 0 ? $link['target'] : '_self';
} ?>

<div id="cms-fancybox-<?php echo esc_attr($uqid);?>" class="cms-fancybox-layout4 <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>">
	<div class="cms-fancybox-inner text-<?php echo esc_attr( $content_align ); ?> clearfix">
		<?php if(!empty($icon_image_url) && $icon_type == 'image' ) { ?>
            <div class="cms-fancybox-icon icon-image" <?php if(!empty($icon_margin_bottom)) { ?> style="margin-bottom: <?php echo esc_attr($icon_margin_bottom).'px'; ?>" <?php } ?>>
                <img src="<?php echo esc_url( $icon_image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>"/>
            </div>
        <?php } else { ?>
            <?php if($icon_class):?>
                <div class="cms-fancybox-icon">
                    <i class="<?php echo esc_attr($icon_class); ?>" style="color:<?php echo esc_attr( $icon_color ); ?>;"></i>
                </div>
            <?php endif;?>
        <?php } ?>

        <div class="cms-fancybox-content">
            <?php if(!empty($title)) : ?>
                <h3 class="cms-fancybox-title" style="color:<?php echo esc_attr( $title_color ); ?>;font-size:<?php echo esc_attr( $title_font_size ); ?>;line-height:<?php echo esc_attr( $title_line_height ); ?>;font-weight:<?php echo esc_attr( $font_weight ); ?>;">
                    <?php echo wp_kses_post( $title ); ?>
                </h3>
            <?php endif;?>
            <?php if($description) : ?>
                <div class="cms-fancybox-description" style="color:<?php echo esc_attr( $description_color ); ?>;">
                    <?php echo wp_kses_post( $description ); ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($button_link) : ?>
            <a href="<?php echo esc_url($a_href); ?>" target="<?php echo esc_attr($a_target); ?>"></a>
        <?php endif; ?>
	</div>
</div>