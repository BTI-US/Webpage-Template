<?php
$atts_extra = shortcode_atts(array(
    'source'               => '',
    'orderby'              => 'date',
    'order'                => 'DESC',
    'limit'                => '6',
    'gap'                  => '30',
    'post_ids'             => '',
    'col_lg'               => 4,
    'col_md'               => 3,
    'col_sm'               => 2,
    'col_xs'               => 1,
    'layout'               => 'basic',
    'pagination_type'      => 'loadmore',
    'filter'               => 'true',
    'filter_default_title' => 'All',
    'filter_alignment'     => 'center',
    'el_class'             => '',
    'img_size'             => '680x451',
    'readmore_button'             => 'hide',
    'title_font_size'             => '',
    'content_length'             => '22',
), $atts);
$atts = array_merge($atts_extra, $atts);
extract($atts);
$tax = array();
extract(cms_get_posts_of_grid('post', $atts));
$filter_default_title = !empty($filter_default_title) ? $filter_default_title : 'All';

$col_lg = 12 / $col_lg;
$col_md = 12 / $col_md;
$col_sm = 12 / $col_sm;
$col_xs = 12 / $col_xs;
$grid_sizer = "col-xl-{$col_lg} col-lg-{$col_md} col-md-{$col_sm} col-sm-{$col_xs} col-xs-{$col_xs}";

$gap_item = intval($gap / 2);

wp_enqueue_style(
    'inline-style',
    get_template_directory_uri() . '/assets/css/inline-style.css'
);
$custom_css = "
        .cms-grid-inner {
            margin: 0 -{$gap_item}px;
        }
        .cms-grid-inner .grid-item {
            padding: {$gap_item}px;
        }";
wp_add_inline_style('inline-style', $custom_css);
wp_enqueue_script( 'waypoints' );
wp_enqueue_style( 'animate-css' );
$grid_class = '';
if ($layout == 'masonry') {
    wp_enqueue_script('isotope');
    wp_enqueue_script('imagesloaded');
    wp_enqueue_script('cryptech-isotope', get_template_directory_uri() . '/assets/js/cms-isotope.js', array('jquery'), '1.0.0', true);
    $grid_class = 'cms-grid-inner cms-grid-masonry row';
    if($pagination_type == 'loadmore' || $pagination_type === 'pagination') {
        $html_id = str_replace('-', '_', $html_id);
        wp_enqueue_script('cms-loadmore-grid', get_template_directory_uri() . '/assets/js/cms-loadmore-grid.js', array('jquery'), 'all', true);
        wp_localize_script('cms-loadmore-grid', 'cms_load_more_' . $html_id, array(
            'startPage' => $paged,
            'maxPages'  => $max,
            'total'     => $total,
            'perpage'   => $limit,
            'nextLink'  => $next_link,
            'layout'    => $layout
        ));
    }
} else {
    $grid_class = 'cms-grid-inner row';
}
?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-grid cms-grid-blog <?php echo esc_attr($el_class); ?>">

    <?php if ($filter == "true" and $layout == 'masonry'): ?>
        <div class="grid-filter-wrap align-<?php echo esc_attr($filter_alignment); ?>">
            <span class="filter-item active" data-filter="*"><?php echo esc_html($filter_default_title); ?></span>
            <?php foreach ($categories as $category): ?>
                <?php $category_arr = explode('|', $category); ?>
                <?php $tax[] = $category_arr[1]; ?>
                <?php $term = get_term_by('slug',$category_arr[0], $category_arr[1]); ?>

                <span class="filter-item" data-filter="<?php echo esc_attr('.' . $term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                </span>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="<?php echo esc_attr($grid_class); ?> animation-time" data-gutter="<?php echo esc_attr($gap_item); ?>">
        <?php if ($layout == 'masonry') : ?>
            <div class="grid-sizer <?php echo esc_attr($grid_sizer); ?>"></div>
        <?php endif; ?>
        <?php
        if (is_array($posts)):
            $sizes = explode(',',$img_size);
            $i = 0;
            foreach ($posts as $post) {
                $default_size = end($sizes);
                if(!empty($sizes[$i])){
                    $default_size = $sizes[$i];
                }
                $img_id = get_post_thumbnail_id($post->ID);
                $img = wpb_getImageBySize( array(
                    'attach_id'  => $img_id,
                    'thumb_size' => $default_size,
                    'class'      => '',
                ));
                $thumbnail = $img['thumbnail'];
                $item_class = "grid-item col-xl-{$col_lg} col-lg-{$col_md} col-md-{$col_sm} col-sm-{$col_xs} col-xs-{$col_xs}";
                $filter_class = cms_get_term_of_post_to_class($post->ID, array_unique($tax));
                ?>
                    <div class="single-hentry <?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                        <div class="grid-item-inner wpb_animate_when_almost_visible wpb_fadeIn fadeIn">
                            <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) : ?>
                                <div class="entry-featured">
                                    <div class="post-image">
                                        <a class="overlay-gradient grid-readmore-icon" href="<?php echo esc_url(get_permalink( $post->ID )); ?>">
                                            <?php echo wp_kses_post($thumbnail); ?>
                                            <span></span>
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="entry-holder">
                                <ul class="entry-meta">
                                    <li><?php the_terms( $post->ID, 'category', '', ', ' ); ?></li>
                                </ul>
                                <h3 class="entry-title" style="<?php if(!empty($title_font_size)) { echo 'font-size: '.$title_font_size.';'; } ?>">
                                    <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>"><?php echo esc_attr(get_the_title($post->ID)); ?></a>
                                </h3>
                                <div class="entry-content">
                                    <?php echo wp_trim_words( $post->post_content, $num_words = $content_length, $more = null ); ?>
                                </div>
                                <ul class="entry-meta entry-meta-bottom">
                                    <?php if($readmore_button == 'show') { ?>
                                        <li class="entry-more">
                                            <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>">
                                                <i class="cms-icon-plus"></i>
                                                <?php echo esc_html__('Read More', 'cryptech'); ?>
                                            </a>
                                        </li>
                                    <?php } else { ?>
                                        <li class="entry-date"><?php echo esc_attr(get_the_date('', $post->ID)); ?></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php $i++;
            }
        endif; ?>
    </div>
    <?php if ($layout == 'masonry' && $pagination_type == 'pagination') { ?>
        <div class="cms-grid-pagination">
            <?php cryptech_posts_pagination(); ?>
        </div>
    <?php } ?>
    <?php if (!empty($next_link) && $layout == 'masonry' && $pagination_type == 'loadmore') { ?>
        <div class="cms-load-more text-center">
            <span class="btn btn-round">
                <i class="fa fa-plus"></i>
                <?php echo esc_html__('Load more', 'cryptech') ?>
            </span>
        </div>
    <?php } ?>
</div>