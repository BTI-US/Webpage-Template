<?php 
extract(shortcode_atts(array(
    'cms_history_list' => '',
    'el_class' => '',
), $atts));
$html_id = cmsHtmlID('cms-history');
$cms_history = array();
$cms_history = (array) vc_param_group_parse_atts($cms_history_list);
if(!empty($cms_history)) : ?>
    <div id="<?php echo esc_attr($html_id);?>" class="cms-history-layout1 <?php echo esc_attr( $el_class); ?>">
        <?php foreach ($cms_history as $key => $value) {
            $year = isset($value['year']) ? $value['year'] : '';
            $day = isset($value['day']) ? $value['day'] : '';
            $title = isset($value['title']) ? $value['title'] : '';
            $desc = isset($value['desc']) ? $value['desc'] : '';
            $item_class = '';
            if ($key % 2 == 0) {
                $item_class = 'item-even';
            } else {
                $item_class = 'item-odd';
            }
            ?>
            <div class="cms-history-item <?php echo esc_attr($item_class); ?>">
                <div class="cms-history-item-space"></div>
                <div class="cms-history-item-inner">
                    <div class="cms-history-time">
                        <span class="fa fa-clock-o"></span>
                        <?php if($day):?>
                            <span class="cms-history-day f-main">
                                <?php echo esc_attr($day); ?>       
                            </span>
                        <?php endif;?>
                        <?php if($year):?>
                            <span class="cms-history-year">
                                <?php echo esc_attr($year); ?>       
                            </span>
                        <?php endif;?>
                    </div>
                    <div class="cms-history-content">
                        <?php if($title):?>
                            <h3 class="cms-history-title"><?php echo apply_filters('the_title',$title);?></h3>
                        <?php endif;?>
                        <?php echo esc_html( $desc ); ?>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
<?php endif; ?>