<?php
extract(shortcode_atts(array(
    'id'        => '',
    'el_title'        => '',
    'animation' => '',       
    'el_class'  => '',         
    'style'  => 'default',      
), $atts));
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
if(class_exists('WPCF7')) { ?>
    <div class="cms-contact-form cms-contact-form-style1 style-<?php echo esc_attr( $style ); ?>  <?php echo esc_attr( $el_class.' '.$animation_classes )?>">
    	<?php if(!empty($el_title)) : ?>
    		<h3 class="el-title"><?php echo esc_attr( $el_title ); ?></h3>
    	<?php endif; ?>
        <?php echo do_shortcode('[contact-form-7 id="'.esc_attr( $id ).'"]'); ?>
    </div>
<?php } ?>