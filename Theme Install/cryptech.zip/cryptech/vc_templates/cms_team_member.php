<?php
extract(shortcode_atts(array( 
    'title'             => '',
    'position'             => '',
    'image'             => '',
    'social'             => '',
    'animation'             => '',
    'el_class'             => '',
), $atts));

$html_id = cmsHtmlID('cms-team-member');
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
$team_image_url = '';
if (!empty($image)) {
    $attachment_image = wp_get_attachment_image_src($image, 'cryptech-team');
    $team_image_url = $attachment_image[0];
}
$el_social = (array) vc_param_group_parse_atts($social);

?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-team-member <?php echo esc_attr($el_class.' '.$animation_classes); ?>">
    <div class="cms-team-member-inner">
        <?php if (!empty($image)) : ?>
            <div class="cms-team-image">
                 <img src="<?php echo esc_url($team_image_url); ?>" alt="<?php echo esc_attr( $title ); ?>" />
            </div>
        <?php endif; ?>
        <div class="cms-team-holder">
            <div class="cms-team-social">
                <?php foreach ($el_social as $key => $value) {
                    $social_link = isset($value['social_link']) ? $value['social_link'] : '';
                    $icon_class = isset($value['icon']) ? $value['icon'] : ''; ?>
                    <a href="<?php echo esc_url($social_link); ?>"><i class="<?php echo esc_attr( $icon_class ); ?>"></i></a>
                <?php } ?>
            </div>
            <h3 class="cms-team-title"><?php echo esc_attr( $title ); ?></h3>
            <div class="cms-team-position"><?php echo esc_attr( $position ); ?></div>
        </div>
        <div class="overlay-gradient"></div>
    </div>
</div>