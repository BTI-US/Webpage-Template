<?php
extract(shortcode_atts(array(
    'title' => '',
    'price' => '',
    'percentage' => '',
    'description' => '',
    'text_button' => '',
    'link_button' => '',

    'icon_type' => 'icon',                                  
    'icon_list' => 'fontawesome',
    'icon_fontawesome' => '',
    'icon_material_design' => '',
    'icon_etline' => '',
    'icon_image' => '',
    'icon_image_hover' => '',
    'icon_color' => '',

    'feature' => 'item-normal',
    'el_class' => '',
    'animation' => '',
), $atts));

$link = vc_build_link($link_button);
$a_href = '';
$a_target = '_self';
if ( strlen( $link['url'] ) > 0 ) {
    $a_href = $link['url'];
    $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
} 
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
$icon_image_url = '';
$icon_image_hover_url = '';
if (!empty($icon_image)) {
    $attachment_image = wp_get_attachment_image_src($icon_image, 'full');
    $icon_image_url = $attachment_image[0];
}
if (!empty($icon_image_hover)) {
    $attachment_image_hover = wp_get_attachment_image_src($icon_image_hover, 'full');
    $icon_image_hover_url = $attachment_image_hover[0];
}
$icon_name = "icon_" . $icon_list;
$icon_class = isset(${$icon_name}) ? $ {$icon_name} : '';
?>

<div class="cms-pricing-wrapper <?php echo esc_attr($el_class.' '.$animation_classes.' '.$feature); ?>">
    <div class="cms-pricing-body">
        <?php if(!empty($icon_image_url) && $icon_type == 'image' ) { ?>
            <div class="cms-pricing-icon">
                <img class="icon-image" src="<?php echo esc_url( $icon_image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>"/>
                <?php if(!empty($icon_image_hover_url)) : ?>
                    <img class="icon-image-hover" src="<?php echo esc_url( $icon_image_hover_url ); ?>" alt="<?php echo esc_attr( $title ); ?>"/>
                <?php endif; ?>
            </div>
        <?php } else { ?>
            <?php if($icon_class):?>
                <div class="cms-pricing-icon">
                    <i class="<?php echo esc_attr($icon_class); ?>" style="color:<?php echo esc_attr( $icon_color ); ?>;"></i>
                </div>
            <?php endif;?>
        <?php } ?>
        <?php if(!empty($title)) : ?>
            <h3 class="cms-pricing-title h-main"><?php echo esc_attr($title);?></h3> 
        <?php endif;?>
        <?php if(!empty($percentage)) : ?>
            <div class="cms-pricing-percentage f-main"><?php echo esc_attr($percentage);?></div>
        <?php endif;?>
        <?php if(!empty($description)) : ?>
            <div class="cms-pricing-content"><?php echo wp_kses_post($description);?></div>
        <?php endif;?>
        <?php if(!empty($text_button)) : ?>
            <div class="cms-pricing-button">
                <a class="btn btn-round btn-outline" href="<?php echo esc_url($a_href);?>" target="<?php echo esc_attr( $a_target ); ?>">
                    <?php echo esc_attr($text_button);?>
                </a>
            </div>
        <?php endif; ?>
    </div>
    <?php if(!empty($title)) : ?>
        <div class="cms-pricing-footer">
            <?php echo esc_attr($price);?>  
        </div>
    <?php endif;?>
</div>