<?php
extract(shortcode_atts(array(
    'image_list' => '',
), $atts));
extract(cryptech_get_param_carousel($atts));
wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-image-carousel');
$cms_content_list = array();
$cms_content_list = (array) vc_param_group_parse_atts( $image_list );
?>
<div id="<?php echo esc_attr($html_id);?>" class="cms-image-carousel owl-carousel" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>

    <?php foreach ($cms_content_list as $key => $value) {
        $item_link = isset($value['item_link']) ? $value['item_link'] : '';
        $link = vc_build_link($item_link);
        $a_href = '';
        $a_target = '';
        if ( strlen( $link['url'] ) > 0 ) {
            $a_href = $link['url'];
            $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
        }
        $image = isset($value['image']) ? $value['image'] : '';
        $img = wpb_getImageBySize( array(
            'attach_id'  => $image,
            'thumb_size' => 'full',
            'class'      => '',
        ));
        $thumbnail = $img['thumbnail'];
        ?>
        <div class="cms-image-item">
            <a href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>">
                <?php echo wp_kses_post($thumbnail); ?>
            </a>
        </div>
    <?php } ?>

</div>
