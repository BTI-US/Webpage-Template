<?php 
extract(shortcode_atts(array(   

    'client_items'         => '',
    'row'         => '1',
    'el_class'             => '',  
    'animation'             => '',  

), $atts));
wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-carousel-client');
$atts['html_id'] = $html_id;
$client_items_tmp = (array) vc_param_group_parse_atts($client_items);
extract(cryptech_get_param_carousel($atts));
$counter = 0;
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-carousel-client owl-carousel cms-carousel-<?php echo esc_attr( $row ); ?>row <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>
    <?php foreach ($client_items_tmp as $key => $value) {
        $client_title = isset($value['client_title']) ? $value['client_title'] : '';
        $client_image = isset($value['client_image']) ? $value['client_image'] : '';
        $client_link = isset($value['client_link']) ? $value['client_link'] : '';

        $image_url = '';
        if (!empty($client_image)) {
            $attachment_image = wp_get_attachment_image_src($client_image, 'full');
            $image_url = $attachment_image[0];
        }

        $link = vc_build_link($client_link);
        $a_href = '';
        $a_target = '';
        if ( strlen( $link['url'] ) > 0 ) {
            $a_href = $link['url'];
            $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
        }
        $counter++;
        if($row == 1){
            echo '<div class="cms-carousel-item-wrap">';
        }else{
            if($counter % $row == 1){
                echo '<div class="cms-carousel-item-wrap">';
            }
        }
        ?>
        <div class="cms-carousel-item">
            <div class="cms-carousel-media">
                <a href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>" title="<?php echo esc_attr( $client_title ); ?>">
                    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $client_title ); ?>" />
                </a>
            </div>
        </div>
        <?php if($row == 1){
            echo '</div>';
        } else {
            if($counter % $row == 0){
                echo '</div>';
            }
        }
    } ?>
</div>