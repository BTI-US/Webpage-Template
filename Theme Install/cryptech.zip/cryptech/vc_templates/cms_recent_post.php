<?php
$atts_extra = shortcode_atts(array(
    'source'               => '',
    'orderby'              => 'date',
    'order'                => 'DESC',
    'limit'                => '6',
    'post_ids'             => '',
    'el_class'             => '',
    'img_size'             => '300x200',
), $atts);
$atts = array_merge($atts_extra, $atts);
extract($atts);
$tax = array();
extract(cms_get_posts_of_grid('post', $atts));
?>

<div id="<?php echo esc_attr($html_id) ?>" class="widget_cms_recent_posts <?php echo esc_attr($el_class); ?>">

    <div class="posts-list">
        <?php
        if (is_array($posts)):
            $sizes = explode(',',$img_size);
            $i = 0;
            foreach ($posts as $post) {
                $default_size = end($sizes);
                if(!empty($sizes[$i])){
                    $default_size = $sizes[$i];
                }
                $img_id = get_post_thumbnail_id($post->ID);
                $img = wpb_getImageBySize( array(
                    'attach_id'  => $img_id,
                    'thumb_size' => $default_size,
                    'class'      => '',
                ));
                $thumbnail = $img['thumbnail']; ?>
                    <div class="entry-brief clearfix">
                        <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) : ?>
                            <div class="entry-media">
                                <a class="br-2px overlay-gradient" href="<?php echo esc_url(get_permalink( $post->ID )); ?>">
                                    <?php echo wp_kses_post($thumbnail); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="entry-content">
                            <h3 class="entry-title">
                                <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>"><?php echo esc_attr(get_the_title($post->ID)); ?></a>
                            </h3>
                            <ul class="entry-meta">
                                <li><?php the_terms( $post->ID, 'category', '', ', ' ); ?></li>
                                <li><?php echo esc_attr(get_the_date('', $post->ID)); ?></li>
                            </ul>
                        </div>
                    </div>
                <?php $i++;
            }
        endif; ?>
    </div>
</div>