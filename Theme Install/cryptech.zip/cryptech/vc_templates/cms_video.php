<?php
extract(shortcode_atts(array(         
    'video_height' => '',                  
    'video_bg_image' => '',                  
    'btn_video_text' => '',                  
    'video_url' => 'https://www.youtube.com/watch?v=ytPzZBDbpTE',                  
    'animation' => '',                  
    'el_class' => '',                  
    'border_box' => 'no-border-box',                  
), $atts));
$html_id = cmsHtmlID('cms-video');
$image_url = '';
if (!empty($atts['video_bg_image'])) {
    $attachment_image = wp_get_attachment_image_src($atts['video_bg_image'], 'full');
    $image_url = $attachment_image[0];
}
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>
<div id="<?php echo esc_attr($html_id);?>" class="cms-video cms-video-layout1 bg-image bg-overlay <?php echo esc_attr( $border_box.' '.$el_class.' '.$animation_classes ); if(!empty($image_url)) { echo ' intro-added'; } ?>" style="height:<?php echo esc_attr( $video_height ); ?>;background-image: url(<?php echo esc_url($image_url); ?>);">
    <div class="cms-video-inner">
        <a class="cms-video-button" href="<?php echo esc_url($video_url); ?>">
            <span class="video-icon"><i class="fa fa-play"></i></span>
            <?php if(!empty($btn_video_text)) { ?>
                <span class="video-text"><?php echo esc_attr($btn_video_text); ?></span>
            <?php } ?>
        </a>
    </div>
</div>