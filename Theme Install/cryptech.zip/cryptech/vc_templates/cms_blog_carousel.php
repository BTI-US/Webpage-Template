<?php 
extract(shortcode_atts(array(   

    'source'               => '',
    'orderby'              => 'date',
    'order'                => 'DESC',
    'limit'                => '6',
    'post_ids'             => '',
    'el_class'             => '',  
    'animation'             => '',  

), $atts));

wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-carousel-post');
$atts['html_id'] = $html_id;

extract(cms_get_posts_of_grid('post', $atts));
extract(cryptech_get_param_carousel($atts));

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-blog-carousel-layout1 owl-carousel <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>
    <?php if (is_array($posts)):
        foreach ($posts as $post) { ?>
            <div class="cms-carousel-item">
                <div class="single-hentry">
                    <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) :
                        $size = 'large';
                        $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), $size, false);
                        $thumbnail = get_the_post_thumbnail($post->ID, $size); ?>
                        <div class="entry-featured">
                            <div class="post-image">
                                <a class="overlay-gradient grid-readmore-icon" href="<?php echo esc_url(get_permalink( $post->ID )); ?>">
                                    <?php echo wp_kses_post($thumbnail); ?>
                                    <span></span>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="entry-holder">
                        <ul class="entry-meta">
                            <li><?php the_terms( $post->ID, 'category', '', ', ' ); ?></li>
                        </ul>
                        <h3 class="entry-title">
                            <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>"><?php echo esc_attr(get_the_title($post->ID)); ?></a>
                        </h3>
                        <div class="entry-content">
                            <?php echo wp_trim_words( $post->post_content, $num_words = 22, $more = null ); ?>
                        </div>
                        <ul class="entry-meta">
                            <li><?php echo esc_attr(get_the_date('', $post->ID)); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        <?php }
    endif; ?>
</div>