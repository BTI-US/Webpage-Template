<?php
$atts_extra = shortcode_atts(array(
    'content_list'         => '',
    'gap'                  => '30',
    'post_ids'             => '',
    'col_lg'               => 4,
    'col_md'               => 3,
    'col_sm'               => 2,
    'col_xs'               => 1,
    'layout'               => 'masonry',
    'el_class'             => '',
), $atts);
$atts = array_merge($atts_extra, $atts);
extract($atts);
$col_lg = 12 / $col_lg;
$col_md = 12 / $col_md;
$col_sm = 12 / $col_sm;
$col_xs = 12 / $col_xs;
$grid_sizer = "col-xl-{$col_lg} col-lg-{$col_md} col-md-{$col_sm} col-sm-{$col_xs} col-{$col_xs}";
$gap_item = intval($gap / 2);
wp_enqueue_script( 'waypoints' );
wp_enqueue_style( 'animate-css' );
$grid_class = '';
if ($layout == 'masonry') {
    wp_enqueue_script('isotope');
    wp_enqueue_script('imagesloaded');
    wp_enqueue_script('cryptech-isotope', get_template_directory_uri() . '/assets/js/cms-isotope.js', array('jquery'), '1.0.0', true);
    $grid_class = 'cms-grid-inner cms-grid-masonry row';
} else {
    $grid_class = 'cms-grid-inner row';
}
$cms_content_list = array();
$cms_content_list = (array) vc_param_group_parse_atts( $content_list );
?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-grid cms-grid-demos <?php echo esc_attr($el_class); ?>">

    <div class="<?php echo esc_attr($grid_class); ?> animation-time" data-gutter="<?php echo esc_attr($gap_item); ?>">
        <?php if ($layout == 'masonry') : ?>
            <div class="grid-sizer <?php echo esc_attr($grid_sizer); ?>"></div>
        <?php endif; ?>
        <?php foreach ($cms_content_list as $key => $value) {
            $readmore_text = isset($value['readmore_text']) ? $value['readmore_text'] : '';
            $title = isset($value['title']) ? $value['title'] : '';
            $item_link = isset($value['item_link']) ? $value['item_link'] : '';
            $link = vc_build_link($item_link);
            $a_href = '';
            $a_target = '';
            if ( strlen( $link['url'] ) > 0 ) {
                $a_href = $link['url'];
                $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
            }
            $image = isset($value['image']) ? $value['image'] : '';
            $img = wpb_getImageBySize( array(
                'attach_id'  => $image,
                'thumb_size' => 'full',
                'class'      => '',
            ));
            $thumbnail = $img['thumbnail'];
            $item_class = "grid-item col-xl-{$col_lg} col-lg-{$col_md} col-md-{$col_sm} col-sm-{$col_xs} col-{$col_xs}";
            ?>
            <div class="<?php echo esc_attr($item_class); ?>">
                <div class="grid-item-inner wpb_animate_when_almost_visible wpb_fadeIn fadeIn">
                    <?php if(!empty($image)) : ?>
                        <div class="demo-featured">
                            <a class="btn btn-outline-white btn-round" href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>">
                                <?php 
                                    if(!empty($readmore_text)) {
                                        echo esc_attr($readmore_text);
                                    } else {
                                        echo esc_html__('View Demo', 'cryptech'); 
                                    }
                                ?>
                            </a>
                            <span class="bg-gradient"></span>
                            <?php echo wp_kses_post($thumbnail); ?>
                        </div>
                    <?php endif; ?>
                    <div class="demo-holder clearfix">
                        <h3 class="demo-title">
                            <a href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>"><?php echo wp_kses_post($title); ?></a>
                        </h3>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>