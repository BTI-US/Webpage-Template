<?php
extract(shortcode_atts(array(

    'title'         => '',
    'title_color'         => '',
    'grouping'         => '0',
    'separator'         => '',
    'digit'         => '',
    'digit_color'         => '',
    'el_class'         => '',
    'animation'         => '',

), $atts));
wp_enqueue_script( 'waypoints' );
wp_enqueue_script( 'cryptech-counter-lib' );
wp_enqueue_script( 'cryptech-counter' );
$html_id = cmsHtmlID('cms-counter');
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>
<div id="<?php echo esc_attr($html_id);?>" class="cms-counter cms-counter-default <?php echo esc_attr( $animation_classes.' '.$el_class ); ?>">

    <div class="cms-counter-inner">
        <div id="<?php echo esc_attr($html_id);?>-digit" class="cms-counter-digit f-main" data-grouping="<?php echo esc_attr($grouping); ?>" data-separator="<?php echo esc_attr($separator); ?>" data-digit="<?php echo esc_attr($atts['digit']);?>" style="color:<?php echo esc_attr( $digit_color ); ?>;"></div>
        <?php if(!empty($title)) : ?>
            <span class="cms-counter-title" style="color:<?php echo esc_attr( $title_color ); ?>;">
                <?php echo apply_filters('the_title',$atts['title']);?>
            </span>
        <?php endif;?>
    </div>
</div>