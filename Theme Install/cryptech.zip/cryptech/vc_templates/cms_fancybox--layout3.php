<?php
extract(shortcode_atts(array(                     
    'subtitle' => '',              
    'title' => '',              
    'title_color' => '',
    'title_font_size' => '',
    'title_line_height' => '',
    'font_weight' => '600',

    'description' => '',              
    'description_color' => '',

    'button_text' => '',
    'button_link' => '',

    'number' => '',
    'el_class' => '',
    'animation' => '',

), $atts));
$uqid = uniqid();

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );

$icon_image_url = '';
if (!empty($icon_image)) {
    $attachment_image = wp_get_attachment_image_src($icon_image, 'full');
    $icon_image_url = $attachment_image[0];
}

$link = vc_build_link($button_link);
$a_href = '';
$a_target = '';
if (strlen($link['url']) > 0) {
    $a_href = $link['url'];
    $a_target = strlen($link['target']) > 0 ? $link['target'] : '_self';
} ?>

<div id="cms-fancybox-<?php echo esc_attr($uqid);?>" class="cms-fancybox-layout3 <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>">
	<div class="cms-fancybox-inner clearfix">
		<?php if( !empty($number) ) { ?>
            <div class="cms-fancybox-icon">
                <?php echo esc_attr( $number ); ?>
            </div>
        <?php } ?>
        <div class="cms-fancybox-holder">
            <div class="cms-fancybox-content">
                <?php if(!empty($subtitle)) : ?>
                    <span class="cms-fancybox-subtitle"><?php echo esc_attr($subtitle); ?></span>
                <?php endif; ?>
                <?php if(!empty($title)) : ?>
                    <h3 class="cms-fancybox-title" style="color:<?php echo esc_attr( $title_color ); ?>;font-size:<?php echo esc_attr( $title_font_size ); ?>;line-height:<?php echo esc_attr( $title_line_height ); ?>;font-weight:<?php echo esc_attr( $font_weight ); ?>;">
                        <?php echo wp_kses_post( $title ); ?>
                    </h3>
                <?php endif;?>
                <?php if($description) : ?>
                    <div class="cms-fancybox-description" style="color:<?php echo esc_attr( $description_color ); ?>;">
                        <?php echo wp_kses_post( $description ); ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ($button_text) : ?>
                <div class="cms-fancybox-readmore">
                    <a class="btn-text" href="<?php echo esc_url($a_href); ?>" target="<?php echo esc_attr($a_target); ?>">
                        <span class="cms-icon-plus"></span>
                        <?php echo esc_attr($button_text); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
	</div>
</div>