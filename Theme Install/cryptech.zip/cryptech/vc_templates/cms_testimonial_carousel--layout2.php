<?php
extract(shortcode_atts(array(

    'testimonial_item' => '',
    'title_color' => '',
    'position_color' => '',
    'content_color' => '',
    'el_class' => '',
    'animation' => '',

), $atts));

wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-testimonial-carousel');
$atts['html_id'] = $html_id;
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
extract(cryptech_get_param_carousel($atts));
$testimonials = (array) vc_param_group_parse_atts($testimonial_item);

if(!empty($testimonials)) : ?>

    <div id="<?php echo esc_attr($atts['html_id']);?>" class="cms-testimonial-carousel layout2 owl-carousel <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>
        <?php foreach ($testimonials as $key => $value) {
            $title = isset($value['title']) ? $value['title'] : '';
            $content = isset($value['content']) ? $value['content'] : '';
            $position = isset($value['position']) ? $value['position'] : '';
            $image = isset($value['image']) ? $value['image'] : '';
            $image_url = '';
            if (!empty($image)) {
                $attachment_image = wp_get_attachment_image_src($image, 'thumbnail');
                $image_url = $attachment_image[0];
            } 
            ?>
            <div class="cms-testimonial-item">
                <svg version="1.0" xmlns="http://www.w3.org/2000/svg"
                     width="50.000000pt" height="36.000000pt" viewBox="0 0 50.000000 36.000000"
                     preserveAspectRatio="xMidYMid meet">
                    <metadata>
                    Created by potrace 1.10, written by Peter Selinger 2001-2011
                    </metadata>
                    <g transform="translate(0.000000,36.000000) scale(0.100000,-0.100000)"
                    fill="#000000" stroke="none">
                    <path d="M54 341 c-42 -26 -61 -80 -45 -131 11 -38 46 -70 76 -70 19 0 19 -32
                    0 -69 -13 -27 -13 -30 10 -51 24 -23 25 -23 45 -5 11 10 33 45 50 78 25 49 30
                    73 30 128 0 61 -3 72 -27 99 -37 41 -94 50 -139 21z m118 -26 c44 -44 45 -132
                    2 -215 -37 -71 -51 -85 -68 -70 -14 11 -14 15 -1 41 21 40 20 79 -3 79 -49 0
                    -100 77 -83 124 26 67 106 88 153 41z"/>
                    <path d="M344 350 c-36 -14 -64 -59 -64 -102 0 -49 24 -87 67 -104 36 -16 40
                    -31 18 -73 -13 -26 -13 -30 10 -51 l24 -22 27 28 c57 61 88 185 64 258 -20 60
                    -87 90 -146 66z m110 -41 c22 -26 26 -40 26 -92 0 -96 -68 -221 -99 -184 -8
                    11 -8 21 4 43 21 41 20 74 -4 74 -25 0 -70 37 -82 68 -12 32 5 87 34 107 12 8
                    38 15 58 15 29 0 43 -7 63 -31z"/>
                    </g>
                </svg>
                <div class="cms-testimonial-content f-main" style="color: <?php echo esc_attr( $content_color ); ?>"><?php echo '“'.esc_html($content).'”'; ?></div>
                <div class="cms-testimonial-holder">
                    <div class="cms-testimonial-image"><img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" /></div>
                    <div class="cms-testimonial-meta">
                        <h3 class="cms-testimonial-title h-main" style="color: <?php echo esc_attr( $title_color ); ?>"><?php echo esc_html($title); ?></h3>
                        <span class="cms-testimonial-position" style="color: <?php echo esc_attr( $position_color ); ?>"><?php echo esc_html($position); ?></span>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

<?php endif;?>