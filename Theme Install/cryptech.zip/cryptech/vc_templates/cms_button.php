<?php
extract(shortcode_atts(array(
    'button_text' => '',       
    'button_link' => '',       
    'button_style' => 'btn-default',       
    'button_shapes' => '',       
    'button_size' => 'btn-size-md',       
    'button_align' => 'left',   
    'button_align_md' => 'left',   
    'button_align_sm' => 'left',   
    'button_align_xs' => 'left',   
    'padding_top'    => '',
    'padding_right'  => '',
    'padding_bottom' => '',
    'padding_left'   => '',    
    'margin_top'    => '',
    'margin_right'  => '',
    'margin_bottom' => '',
    'margin_left'   => '',  

    'br_top_left'   => '',    
    'br_top_right'   => '',    
    'br_bottom_right'   => '',    
    'br_bottom_left'   => '',

    'icon_type' => 'icon',                                  
    'icon_list' => 'fontawesome',
    'icon_fontawesome' => '',
    'icon_material_design' => '',
    'icon_etline' => '',
    'icon_image' => '',    
    'icon_align' => 'icon-left',    
    'icon_font_size' => '',   

    'animation' => '',       
    'el_class' => '',  
), $atts));

$link = vc_build_link($button_link);
$a_href = '';
$a_target = '';
if ( strlen( $link['url'] ) > 0 ) {
    $a_href = $link['url'];
    $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
}

$icon_image_url = '';
if (!empty($icon_image)) {
    $attachment_image = wp_get_attachment_image_src($icon_image, 'full');
    $icon_image_url = $attachment_image[0];
}
$icon_name = "icon_" . $icon_list;
$icon_class = isset(${$icon_name}) ? $ {$icon_name} : '';

$style_padding = array(
    'padding-top'    => $padding_top,
    'padding-right'  => $padding_right,
    'padding-bottom' => $padding_bottom,
    'padding-left'   => $padding_left,
    'margin-top'    => $margin_top,
    'margin-right'  => $margin_right,
    'margin-bottom' => $margin_bottom,
    'margin-left'   => $margin_left,
    'border-top-left-radius'   => $br_top_left,
    '-webkit-border-top-left-radius'   => $br_top_left,
    '-ms-border-top-left-radius'   => $br_top_left,
    '-o-border-top-left-radius'   => $br_top_left,
    'border-top-right-radius'   => $br_top_right,
    '-webkit-border-top-right-radius'   => $br_top_right,
    '-ms-border-top-right-radius'   => $br_top_right,
    '-o-border-top-right-radius'   => $br_top_right,
    'border-bottom-right-radius'   => $br_bottom_right,
    '-webkit-border-bottom-right-radius'   => $br_bottom_right,
    '-ms-border-bottom-right-radius'   => $br_bottom_right,
    '-o-border-bottom-right-radius'   => $br_bottom_right,
    'border-bottom-left-radius'   => $br_bottom_left,
    '-webkit-border-bottom-left-radius'   => $br_bottom_left,
    '-ms-border-bottom-left-radius'   => $br_bottom_left,
    '-o-border-bottom-left-radius'   => $br_bottom_left,
);
$styles = '';
foreach ($style_padding as $key => $value) {
    if (!empty($value)) {
        $styles .= $key . ':' . $value . ';';
    }
}

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );

?>
<div class="cms-button-wrapper btn-align-<?php echo esc_attr($button_align); ?>  btn-align-<?php echo esc_attr($button_align_md); ?>-md btn-align-<?php echo esc_attr($button_align_sm); ?>-sm btn-align-<?php echo esc_attr($button_align_xs); ?>-xs <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>">

    <a class="btn <?php echo esc_attr($button_style.' '.$button_shapes.' '.$button_size); ?>" <?php echo !empty($styles) ? 'style="' . esc_attr($styles) . '"' : '' ?> href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>">
        <?php if($icon_align == 'icon-right') : ?>
            <span><?php echo esc_attr($button_text); ?></span>
        <?php endif; ?>
        <?php if(!empty($icon_image_url) && $icon_type == 'image' ) { ?>
            <img class="<?php echo esc_attr($icon_align); ?>" src="<?php echo esc_url( $icon_image_url ); ?>" alt="<?php echo esc_attr( $button_text ); ?>"/>
        <?php } else { ?>
            <?php if($icon_class):?>
                <i class="<?php echo esc_attr($icon_class.' '.$icon_align); ?>" style="font-size:<?php echo esc_attr( $icon_font_size ); ?>;"></i>
            <?php endif;?>
        <?php } ?>
        <?php if($icon_align == 'icon-left') : ?>
            <span><?php echo esc_attr($button_text); ?></span>
        <?php endif; ?>
    </a>
    
</div>