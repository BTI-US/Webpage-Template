<?php
extract(shortcode_atts(array(

    'title'  => '',
    'btn_text'  => '',
    'btn_link'  => '',
    'softcap'  => '',
    'hardcap'  => '',
    'total_days'  => '',
    'total_tokens'  => '',
    'total_tokens_color'  => '',
    'date_count_down'  => '',
    'el_class'         => '',
    'animation'        => '',
    'currency'        => '$',

), $atts));
$link = vc_build_link($btn_link);
$a_href = '';
$a_target = '';
if ( strlen( $link['url'] ) > 0 ) {
    $a_href = $link['url'];
    $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
}
$date_count_down = !empty($date_count_down) ? $date_count_down : '2020/01/10';
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
$month = esc_html__('Month', 'cryptech');
$months = esc_html__('Months', 'cryptech');
$day = esc_html__('Day', 'cryptech');
$days = esc_html__('Days', 'cryptech');
$hour = esc_html__('Hour', 'cryptech');
$hours = esc_html__('Hours', 'cryptech');
$minute = esc_html__('Minute', 'cryptech');
$minutes = esc_html__('Minutes', 'cryptech');
$second = esc_html__('Second', 'cryptech');
$seconds = esc_html__('Seconds', 'cryptech'); 

$token_w = ($softcap*100)/$hardcap;
?>
<div class="cms-token-countdown-wrap">
	<div class="cms-token-countdown bg-gradient">
		<div class="cms-token-countdown-body">
			<?php if($title) : ?>
				<div class="cms-token-meta">
					<h3><i class="fa fa-clock-o"></i><?php echo esc_attr($title); ?></h3>
				</div>
			<?php endif; ?>
			<div class="cms-countdown-wraper clearfix <?php echo esc_attr( $animation_classes.' '.$el_class ); ?>" 
				data-month="<?php echo esc_attr($month) ?>"
				data-months="<?php echo esc_attr($months) ?>"
				data-day="<?php echo esc_attr($day) ?>"
				data-days="<?php echo esc_attr($days) ?>"
				data-hour="<?php echo esc_attr($hour) ?>"
				data-hours="<?php echo esc_attr($hours) ?>"
				data-minute="<?php echo esc_attr($minute) ?>"
				data-minutes="<?php echo esc_attr($minutes) ?>"
				data-second="<?php echo esc_attr($second) ?>"
				data-seconds="<?php echo esc_attr($seconds) ?>">
				<div id="getting-started" class="cms-countdown-inner" data-count-down="<?php echo esc_attr($date_count_down);?>"></div>
			</div>
			<div class="cms-token-holder">
				<?php if($btn_text) : ?>
					<a class="btn btn-outline-white" href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>"><?php echo esc_attr($btn_text); ?></a>
				<?php endif; ?>
			</div>
		</div>
		<div class="cms-token-countdown-footer">
			<?php if(!empty($softcap) && !empty($hardcap)) : ?>
				<div class="cms-token-progress-wrap">
					<div class="cms-token-progress-label clearfix">
						<div class="softcap-label">
							<?php echo esc_html__('Softcap in', 'cryptech'); ?>
							<span><?php echo esc_attr($total_days).' '.esc_html__('Days', 'cryptech'); ?><span>
						</div>
						<div class="hardcap-label"><?php echo esc_html__('Hardcap', 'cryptech'); ?></div>
					</div>
					<div class="cms-token-progress">
						<div class="cms-token-progress-inner progress-bar" data-valuetransitiongoal="<?php echo esc_attr($token_w); ?>"></div>
					</div>
					<div class="cms-token-progress-price clearfix">
						<div class="softcap-price"><?php echo esc_attr( $currency.''.$softcap ); ?></div>
						<div class="hardcap-price"><?php echo esc_attr( $currency.''.$hardcap ); ?></div>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php if(!empty($total_tokens)) : ?>
		<div class="cms-token-total" <?php if(!empty($total_tokens_color)) : ?> style="color: <?php echo esc_attr($total_tokens_color); ?>" <?php endif; ?>>
			<?php echo esc_html__('Total Tokens:', 'cryptech').' '.esc_attr( $currency.''.$total_tokens ); ?>
		</div>
	<?php endif; ?>
</div>