<?php
$atts_extra = shortcode_atts(array(
    'source'               => '',
    'orderby'              => 'date',
    'order'                => 'DESC',
    'limit'                => '6',
    'gap'                  => '30',
    'post_ids'             => '',
    'col_lg'               => 4,
    'col_md'               => 3,
    'col_sm'               => 2,
    'col_xs'               => 1,
    'layout'               => 'basic',
    'pagination_type'      => 'loadmore',
    'filter'               => 'true',
    'filter_default_title' => 'All',
    'filter_alignment'     => 'center',
    'el_class'             => '',
), $atts);
$atts = array_merge($atts_extra, $atts);
extract($atts);
$tax = array();
extract(cms_get_posts_of_grid('gallerie', $atts));
$filter_default_title = !empty($filter_default_title) ? $filter_default_title : 'All';

$col_lg = 12 / $col_lg;
$col_md = 12 / $col_md;
$col_sm = 12 / $col_sm;
$col_xs = 12 / $col_xs;
$grid_sizer = "col-lg-{$col_lg} col-md-{$col_md} col-sm-{$col_sm} col-xs-{$col_xs}";

$gap_item = intval($gap / 2);
wp_enqueue_style(
    'inline-style',
    get_template_directory_uri() . '/assets/css/inline-style.css'
);
$custom_css = "
        .cms-grid-inner {
            margin: 0 -{$gap_item}px;
        }
        .cms-grid-inner .grid-item {
            padding: {$gap_item}px;
        }";
wp_add_inline_style('inline-style', $custom_css);

$grid_class = '';
if ($layout == 'masonry') {
    wp_enqueue_script('isotope');
    wp_enqueue_script('imagesloaded');
    wp_enqueue_script('cryptech-isotope', get_template_directory_uri() . '/assets/js/cms-isotope.js', array('jquery'), '1.0.0', true);
    $grid_class = 'cms-grid-inner cms-grid-masonry row';
    if($pagination_type == 'loadmore' || $pagination_type === 'pagination') {
        $html_id = str_replace('-', '_', $html_id);
        wp_enqueue_script('cms-loadmore-grid', get_template_directory_uri() . '/assets/js/cms-loadmore-grid.js', array('jquery'), 'all', true);
        wp_localize_script('cms-loadmore-grid', 'cms_load_more_' . $html_id, array(
            'startPage' => $paged,
            'maxPages'  => $max,
            'total'     => $total,
            'perpage'   => $limit,
            'nextLink'  => $next_link,
            'layout'    => $layout
        ));
    }
} else {
    $grid_class = 'cms-grid-inner row';
}


?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-grid cms-grid-gallery <?php echo esc_attr($el_class); ?>">

    <?php if ($filter == "true" and $layout == 'masonry'): ?>
        <div class="grid-filter-wrap align-<?php echo esc_attr($filter_alignment); ?>">
            <span class="filter-item active" data-filter="*"><?php echo esc_html($filter_default_title); ?></span>
            <?php foreach ($categories as $category): ?>
                <?php $category_arr = explode('|', $category); ?>
                <?php $tax[] = $category_arr[1]; ?>
                <?php $term = get_term_by('slug',$category_arr[0], $category_arr[1]); ?>

                <span class="filter-item" data-filter="<?php echo esc_attr('.' . $term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                </span>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="<?php echo esc_attr($grid_class); ?>" data-gutter="<?php echo esc_attr($gap_item); ?>">
        <?php if ($layout == 'masonry') : ?>
            <div class="grid-sizer <?php echo esc_attr($grid_sizer); ?>"></div>
        <?php endif; ?>
        <?php
        if (is_array($posts)):
            foreach ($posts as $post) {
                $size1 = 'medium';
                $size2 = 'full';
                $grid_col_lg = !empty(get_post_meta($post->ID, 'el_col_lg', true)) ? 12 / get_post_meta($post->ID, 'el_col_lg', true) : $col_lg;
                $grid_col_md = !empty(get_post_meta($post->ID, 'el_col_md', true)) ? 12 / get_post_meta($post->ID, 'el_col_md', true) : $col_md;
                $grid_col_sm = !empty(get_post_meta($post->ID, 'el_col_sm', true)) ? 12 / get_post_meta($post->ID, 'el_col_sm', true) : $col_sm;
                $grid_col_xs = !empty(get_post_meta($post->ID, 'el_col_xs', true)) ? 12 / get_post_meta($post->ID, 'el_col_xs', true) : $col_xs;
                $item_class = "grid-item col-lg-{$grid_col_lg} col-md-{$grid_col_md} col-sm-{$grid_col_sm} col-xs-{$grid_col_xs}";
                $filter_class = cms_get_term_of_post_to_class($post->ID, array_unique($tax)); ?>
                <?php if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)):
                    $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), $size2, false);
                    $thumbnail = get_the_post_thumbnail($post->ID, $size1); ?>

                    <div class="<?php echo esc_attr($item_class . ' ' . $filter_class); ?>">
                        <div class="grid-item-inner">
                            <div class="grid-gallery-media overlay-link images-light-box">
                                <a href="<?php echo esc_url($thumbnail_url[0]); ?>" class="light-box">
                                    <span class="cms-icon-plus icon-lg align-middle"></span>
                                </a>
                                <?php echo wp_kses_post($thumbnail); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php }
        endif; ?>
    </div>
    <?php if ($layout == 'masonry' && $pagination_type == 'pagination') { ?>
        <div class="cms-grid-pagination">
            <?php cryptech_posts_pagination(); ?>
        </div>
    <?php } ?>
    <?php if (!empty($next_link) && $layout == 'masonry' && $pagination_type == 'loadmore') { ?>
        <div class="cms-load-more text-center">
            <span class="btn btn-round">
                <i class="fa fa-plus"></i>
                <?php echo esc_html__('Load more', 'cryptech') ?>
            </span>
        </div>
    <?php } ?>
</div>