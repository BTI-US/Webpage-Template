<?php
extract(shortcode_atts(array(                     
    'space_lg' => '',              
    'space_md' => '',              
    'space_sm' => '',              
    'space_xs' => '',                                  
    'bg_image' => '',                                  
    'bg_position' => 'center',                                  
    'bg_size' => 'initial',                                  
    'bg_repeat' => 'no-repeat',                                  
), $atts));
$uqid = uniqid();
$bg_url = '';
if (!empty($bg_image)) {
    $attachment_image = wp_get_attachment_image_src($bg_image, 'full');
    $bg_url = $attachment_image[0];
}
$style_space = array(
    'background-image'    => 'url('.$bg_url.')',
    'background-position'    => $bg_position,
    'background-size'  => $bg_size,
    'background-repeat' => $bg_repeat,
);
$styles = '';
foreach ($style_space as $key => $value) {
    if (!empty($value)) {
        $styles .= $key . ':' . $value . ';';
    }
}
?>
<div id="cms-space-<?php echo esc_attr($uqid);?>">
	<style type="text/css" scoped>
		@media screen and (min-width: 1200px) {
			#cms-space-<?php echo esc_attr($uqid);?> .cms-space {
				height: <?php echo esc_attr($space_lg); ?>px;
			}
		}
		@media (min-width: 992px) and (max-width: 1200px) {
			#cms-space-<?php echo esc_attr($uqid);?> .cms-space {
				height: <?php echo esc_attr($space_md); ?>px;
			}
		}
		@media (min-width: 768px) and (max-width: 991px) {
			#cms-space-<?php echo esc_attr($uqid);?> .cms-space {
				height: <?php echo esc_attr($space_sm); ?>px;
			}
		}
		@media screen and (max-width: 767px) {
			#cms-space-<?php echo esc_attr($uqid);?> .cms-space {
				height: <?php echo esc_attr($space_xs); ?>px;
			}
		}
	</style>
	<div class="cms-space" <?php echo !empty($styles) ? 'style="' . esc_attr($styles) . '"' : '' ?>></div>
</div>