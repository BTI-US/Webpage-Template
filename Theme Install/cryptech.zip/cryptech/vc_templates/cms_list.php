<?php
extract(shortcode_atts(array(                  
    'cms_list_fontsize' => '',                  
    'cms_list_lineheight' => '',                  
    'cms_list_color' => '',                  
    'cms_list' => '',                  
    'cms_list_item' => '',                  
    'style' => 'check',                  
), $atts));

$cms_lists = array();
$cms_lists = (array) vc_param_group_parse_atts($cms_list);

?>
<div class="cms-lists style-<?php echo esc_attr( $style ); ?>">
    <div class="cms-list-inner">
        <div class="cms-list-content">
            <ul style="font-size: <?php echo esc_attr($cms_list_fontsize); ?>; line-height: <?php echo esc_attr($cms_list_lineheight); ?>; color: <?php echo esc_attr($cms_list_color); ?>">
                <?php foreach ($cms_lists as $key => $value) { ?>
                    <li><i class="zmdi zmdi-check"></i><?php echo esc_html($value['cms_list_item']); ?></li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>