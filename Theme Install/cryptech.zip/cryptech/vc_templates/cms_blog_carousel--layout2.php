<?php 
extract(shortcode_atts(array(   

    'source'               => '',
    'orderby'              => 'date',
    'order'                => 'DESC',
    'limit'                => '6',
    'post_ids'             => '',
    'el_class'             => '',  
    'animation'             => '',  

), $atts));

wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-carousel-post');
$atts['html_id'] = $html_id;

extract(cms_get_posts_of_grid('post', $atts));
extract(cryptech_get_param_carousel($atts));

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>

<div id="<?php echo esc_attr($html_id) ?>" class="cms-blog-carousel-layout2 owl-carousel <?php echo esc_attr( $el_class.' '.$animation_classes ); ?>" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>
    <?php if (is_array($posts)):
        foreach ($posts as $post) { 
            $thumbnail_url = '';
            if (has_post_thumbnail($post->ID) && wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), false)) {
                $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large', false);
            }
            ?>
            <div class="cms-carousel-item overlay-gradient2 bg-image" style="background-image: url(<?php echo esc_url($thumbnail_url[0]); ?>);">
                <div class="single-hentry">
                    <div class="entry-holder">
                        <ul class="entry-meta">
                            <li><?php the_terms( $post->ID, 'category', '', ', ' ); ?></li>
                        </ul>
                        <h3 class="entry-title">
                            <a href="<?php echo esc_url(get_permalink( $post->ID )); ?>"><?php echo esc_attr(get_the_title($post->ID)); ?></a>
                        </h3>
                        <ul class="entry-meta">
                            <li><?php echo esc_attr(get_the_date('', $post->ID)); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        <?php }
    endif; ?>
</div>