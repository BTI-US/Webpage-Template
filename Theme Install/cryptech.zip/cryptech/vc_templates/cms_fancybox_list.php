<?php
extract(shortcode_atts(array(

    'fancybox_list' => '',
    'rows' => '1',
    'el_class' => '',

), $atts));
wp_enqueue_script( 'owl-carousel' );
wp_enqueue_script( 'cryptech-carousel' );
$html_id = cmsHtmlID('cms-testimonial-carousel');
extract(cryptech_get_param_carousel($atts));
$fancybox = (array) vc_param_group_parse_atts($fancybox_list);
$counter = 0;
if(!empty($fancybox)) : ?>

    <div id="<?php echo esc_attr($html_id);?>" class="cms-fancybox-carousel owl-carousel <?php echo esc_attr( $el_class ); ?>" <?php echo !empty($carousel_data) ?  esc_attr($carousel_data) : '' ?>>
        <?php foreach ($fancybox as $key => $value) {
            $title = isset($value['title']) ? $value['title'] : '';
            $content = isset($value['content']) ? $value['content'] : '';
            $icon_etline = isset($value['icon_etline']) ? $value['icon_etline'] : '';
            $counter++;
            if($rows == 1){
                echo '<div class="cms-carousel-item-wrap">';
            }else{
                if($counter % $rows == 1){
                    echo '<div class="cms-carousel-item-wrap">';
                }
            }
            ?>
            <div class="cms-fancybox-default text-center">
                <?php if(!empty($icon_etline)) : ?>
                    <div class="cms-fancybox-icon">
                        <i class="<?php echo esc_attr($icon_etline); ?>"></i>
                    </div>
                <?php endif; ?>
                <div class="cms-fancybox-content">
                    <h3 class="cms-fancybox-title h-main"><?php echo esc_html($title); ?></h3>
                    <div class="cms-fancybox-description">
                        <?php echo esc_html($content); ?>
                    </div>
                </div>
            </div>
            <?php if($rows == 1){
                echo '</div>';
            } else {
                if($counter % $rows == 0){
                    echo '</div>';
                }
            }
        } ?>
    </div>

<?php endif;?>