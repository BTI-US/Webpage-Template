<?php
extract(shortcode_atts(array(
    'id'        => '',
    'animation' => '',       
    'el_class'  => '',         
    'style'  => 'default',         
), $atts));
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
if(class_exists('Crypto_Currency_Price_Widget')) { ?>
    <div class="cms-coin-ticker style-<?php echo esc_attr( $style ); ?>  <?php echo esc_attr( $el_class.' '.$animation_classes )?>">
        <?php echo do_shortcode('[ccpw id="'.esc_attr( $id ).'"]'); ?>
    </div>
<?php } ?>