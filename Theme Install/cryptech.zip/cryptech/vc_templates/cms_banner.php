<?php
extract(shortcode_atts(array(
    'image' => '',
    'animation' => '',
    'el_class' => '',
    'banner_position'   => 'top-right',
    'banner_size'   => 'size-small',
    'banner_bg_color'   => '',
), $atts));
$image_url = '';
if (!empty($image)) {
    $attachment_image = wp_get_attachment_image_src($image, 'full');
    $image_url = $attachment_image[0];
}
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
if(!empty($image_url)) : ?>
	<div class="cms-banner <?php echo esc_attr( $banner_size.' '.$banner_position.' '.$el_class.' '.$animation_classes ); ?>">
		<div class="cms-banner-inner <?php if(!empty($banner_bg_color)) { echo 'cms-banner-color'; } ?>" <?php if(!empty($banner_bg_color)) { ?> style="background-color: <?php echo esc_attr($banner_bg_color); ?>" <?php } ?>>
			<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr($image); ?>" />
		</div>
	</div>
<?php endif; ?>