<?php
extract(shortcode_atts(array(
    'text' => '',    
    'tag' => 'h3',    
    'align_lg' => 'align-left',    
    'align_md' => 'align-left-md',    
    'align_sm' => 'align-left-sm',    
    'align_xs' => 'align-left-xs', 

    'font_size' => '',
    'font_size_md' => '',
    'font_size_sm' => '',
    'font_size_xs' => '',
    'font_weight' => '',
    'h_font_style' => '',

    'line_height' => '',
    'line_height_md' => '',
    'line_height_sm' => '',
    'line_height_xs' => '',

    'letter_spacing' => '',

    'sub_title' => '',
    'sub_title_font_size' => '',
    'sub_title_color' => '',
    'description' => '',
    'description_m_width' => 'h-full-width',
    'description_color' => '',
    'description_font_size' => '',
    'description_line_height' => '',
    'desc_font_weight' => '',

    'margin_top' => '', 
    'margin_right' => '', 
    'margin_bottom' => '', 
    'margin_left' => '', 
    'text_color' => '', 
    'custom_fonts' => 'false',              
    'google_fonts' => '',

    'animation' => '',       
    'el_class' => '',       
    'title_divider' => 'no-divider',       
), $atts));

$inline_style = '';
if($custom_fonts == 'true') {
    // Build the data array
    $googleFontsParam = new Vc_Google_Fonts();      
    $fieldSettings = array();
    $text_font_data = strlen( $google_fonts ) > 0 ? $googleFontsParam->_vc_google_fonts_parse_attributes( $fieldSettings, $google_fonts ) : '';
     
    // Build the inline style
    if(isset($text_font_data['values']['font_family'])) {
        $fontFamily = explode( ':', $text_font_data['values']['font_family'] );
        $styles[] = 'font-family:' . $fontFamily[0];
    }
    if(isset($text_font_data['values']['font_style'])) {
        $fontStyles = explode( ':', $text_font_data['values']['font_style'] );
        $styles[] = 'font-weight:' . $fontStyles[1];
        $styles[] = 'font-style:' . $fontStyles[2];  
    }
    if(isset($text_font_data['values']['font_family']) || isset($text_font_data['values']['font_style'])) {
        foreach( $styles as $attribute ){           
            $inline_style .= $attribute.'; ';       
        } 
    }
             
    // Enqueue the right font   
    $settings = get_option( 'wpb_js_google_fonts_subsets' );
    if ( is_array( $settings ) && ! empty( $settings ) ) {
        $subsets = '&subset=' . implode( ',', $settings );
    } else {
        $subsets = '';
    }
     
    // We also need to enqueue font from googleapis
    if ( isset( $text_font_data['values']['font_family'] ) ) {
        wp_enqueue_style( 
            'vc_google_fonts_' . vc_build_safe_css_class( $text_font_data['values']['font_family'] ), 
            '//fonts.googleapis.com/css?family=' . $text_font_data['values']['font_family'] . $subsets
        );
    }
} else {
    $inline_style = '';
}

$styles_title = array(
    'margin-top'    => $margin_top,
    'margin-right'  => $margin_right,
    'margin-bottom' => $margin_bottom,
    'margin-left'   => $margin_left,
    'color'   => $text_color,
    'font-size'   => $font_size,
    'line-height'   => $line_height,
    'letter-spacing'   => $letter_spacing,
    'font-weight'   => $font_weight,
    'font-style'   => $h_font_style,
);
$title_styles = '';
foreach ($styles_title as $key => $value) {
    if (!empty($value)) {
        $title_styles .= $key . ':' . $value . ';';
    }
}

$styles_desc = array(
    'color'   => $description_color,
    'font-size'   => $description_font_size,
    'line-height'   => $description_line_height,
    'font-weight'   => $desc_font_weight,
);
$desc_styles = '';
foreach ($styles_desc as $key => $value) {
    if (!empty($value)) {
        $desc_styles .= $key . ':' . $value . ';';
    }
}

$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );

?>
<div id="<?php echo esc_attr($atts['html_id']);?>" class="cms-heading <?php echo esc_attr( $align_lg.' '.$align_md.' '.$align_sm.' '.$align_xs.' '.$animation_classes ); ?>">
    <?php if(!empty($font_size_md) || !empty($line_height_md)) : ?>
        <style type="text/css" scoped>
            @media (min-width: 991px) and (max-width: 1200px) {
                #<?php echo esc_attr($atts['html_id']);?> .cms-heading-tag {
                    font-size: <?php echo esc_attr($font_size_md); ?> !important;
                    line-height: <?php echo esc_attr($line_height_md); ?> !important;
                }
            }
        </style>
    <?php endif; ?>

    <?php if(!empty($font_size_sm) || !empty($line_height_sm)) : ?>
        <style type="text/css" scoped>
            @media (min-width: 768px) and (max-width: 991px) {
                #<?php echo esc_attr($atts['html_id']);?> .cms-heading-tag {
                    font-size: <?php echo esc_attr($font_size_sm); ?> !important;
                    line-height: <?php echo esc_attr($line_height_sm); ?> !important;
                }
            }
        </style>
    <?php endif; ?>

    <?php if(!empty($font_size_xs) || !empty($line_height_xs)) : ?>
        <style type="text/css" scoped>
            @media screen and (max-width: 767px) {
                #<?php echo esc_attr($atts['html_id']);?> .cms-heading-tag {
                    font-size: <?php echo esc_attr($font_size_xs); ?> !important;
                    line-height: <?php echo esc_attr($line_height_xs); ?> !important;
                }
            }
        </style>
    <?php endif; ?>
    <?php if(!empty($sub_title)) : ?>
        <div class="cms-heading-sub" style="<?php if(!empty($sub_title_font_size)) { echo 'font-size: '.$sub_title_font_size.';'; } if(!empty($sub_title_color)) { echo 'color: '.$sub_title_color.';'; } ?>">
            <?php echo esc_attr( $sub_title  ); ?>
        </div>
    <?php endif; ?>
    <<?php echo esc_attr( $tag ); ?> class="cms-heading-tag <?php echo esc_attr( $el_class.' '.$title_divider ); ?>" <?php echo !empty($title_styles || $inline_style) ? 'style="' . esc_attr($title_styles) . ' '. $inline_style .'"' : '' ?>>
        <?php echo wp_kses_post( $text ); ?>
    </<?php echo esc_attr( $tag ); ?>>
    <?php if(!empty($description)) : ?>
        <div class="cms-heading-desc <?php echo esc_attr( $description_m_width ); ?>" <?php echo !empty($desc_styles) ? 'style="' . esc_attr($desc_styles) . '"' : '' ?>>
            <?php echo wp_kses_post( $description  ); ?>
        </div>
    <?php endif; ?>
</div>