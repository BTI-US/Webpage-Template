<?php
extract(shortcode_atts(array(
    'chart_styles' => 'chart_dark',  
    'el_class' => '',  
    'animation' => '',    
), $atts));
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
?>
<script>
  (function(b,i,t,C,O,I,N) {
    window.addEventListener('load',function() {
      if(b.getElementById(C))return;
      I=b.createElement(i),N=b.getElementsByTagName(i)[0];
      I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
    },false)
  })(document,'script','https://widgets.bitcoin.com/widget.js','btcwdgt');
</script>
<div class="cms-price-chart <?php echo esc_attr($el_class.' '.$animation_classes); ?>">
    <?php if($chart_styles == 'chart_dark') { ?>
        <div class="btcwdgt-chart"></div>
    <?php } else { ?>
        <div class="btcwdgt-chart" bw-theme="light"></div>
    <?php } ?>
</div>