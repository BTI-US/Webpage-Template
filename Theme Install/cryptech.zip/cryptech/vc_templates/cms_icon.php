<?php
extract(shortcode_atts(array(
   'icon_list' => 'fontawesome',
    'icon_fontawesome' => '',
    'icon_material_design' => '',
    'icon_etline' => '',
    'icon_link' => '',
    'icon_color' => '',
    'icon_bg_color' => '',
    'icon_font_size' => '',
    'icon_line_height' => '',
    'icon_border_width' => '',
    'icon_border_style' => '',
    'icon_border_color' => '',
    'icon_width' => '',
    'icon_height' => '',
    'icon_color_hover' => '',
    'icon_bg_color_hover' => '',
    'icon_border_color_hover' => '',
    
    'padding_top'    => '',
    'padding_right'  => '',
    'padding_bottom' => '',
    'padding_left'   => '',  

    'margin_top'    => '',
    'margin_right'  => '',
    'margin_bottom' => '',
    'margin_left'   => '',  

    'br_top_left'   => '',    
    'br_top_right'   => '',    
    'br_bottom_right'   => '',    
    'br_bottom_left'   => '',    
    'el_class'   => '',
), $atts));

$link = vc_build_link($icon_link);
$a_href = '';
$a_target = '';
if ( strlen( $link['url'] ) > 0 ) {
    $a_href = $link['url'];
    $a_target = strlen( $link['target'] ) > 0 ? $link['target'] : '_self';
}
$icon_name = "icon_" . $icon_list;
$icon_class = isset(${$icon_name}) ? $ {$icon_name} : '';
$style_padding = array(
    'padding-top'    => $padding_top,
    'padding-right'  => $padding_right,
    'padding-bottom' => $padding_bottom,
    'padding-left'   => $padding_left,
    'margin-top'    => $margin_top,
    'margin-right'  => $margin_right,
    'margin-bottom' => $margin_bottom,
    'margin-left'   => $margin_left,
    'color'   => $icon_color,
    'background-color'   => $icon_bg_color,
    'font-size'   => $icon_font_size,
    'line-height'   => $icon_line_height,
    'border-width'   => $icon_border_width,
    'border-style'   => $icon_border_style,
    'border-color'   => $icon_border_color,
    'width'   => $icon_width,
    'height'   => $icon_height,
    'border-top-left-radius'   => $br_top_left,
    '-webkit-border-top-left-radius'   => $br_top_left,
    '-ms-border-top-left-radius'   => $br_top_left,
    '-o-border-top-left-radius'   => $br_top_left,
    'border-top-right-radius'   => $br_top_right,
    '-webkit-border-top-right-radius'   => $br_top_right,
    '-ms-border-top-right-radius'   => $br_top_right,
    '-o-border-top-right-radius'   => $br_top_right,
    'border-bottom-right-radius'   => $br_bottom_right,
    '-webkit-border-bottom-right-radius'   => $br_bottom_right,
    '-ms-border-bottom-right-radius'   => $br_bottom_right,
    '-o-border-bottom-right-radius'   => $br_bottom_right,
    'border-bottom-left-radius'   => $br_bottom_left,
    '-webkit-border-bottom-left-radius'   => $br_bottom_left,
    '-ms-border-bottom-left-radius'   => $br_bottom_left,
    '-o-border-bottom-left-radius'   => $br_bottom_left,
);
$styles = '';
foreach ($style_padding as $key => $value) {
    if (!empty($value)) {
        $styles .= $key . ':' . $value . ';';
    }
} 
$html_id = cmsHtmlID('cms-icon');
if($icon_class):?>
    <div id="<?php echo esc_attr($html_id) ?>" class="cms-icon">
        <style type="text/css" scoped>
            #<?php echo esc_attr( $html_id ); ?> a:hover {
                color: <?php echo esc_attr($icon_color_hover); ?> !important;
                border-color: <?php echo esc_attr($icon_border_color_hover); ?> !important;
                background-color: <?php echo esc_attr($icon_bg_color_hover); ?> !important;
            }
        </style>
        <a href="<?php echo esc_url($a_href);?>" target="<?php  echo esc_attr($a_target); ?>" <?php echo !empty($styles) ? 'style="' . esc_attr($styles) . '"' : '' ?>>
            <i class="<?php echo esc_attr($icon_class); ?>"></i>
        </a>
    </div>
<?php endif;?>