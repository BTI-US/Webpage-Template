<?php
extract(shortcode_atts(array(
    'id'        => '',
    'el_title'        => '',
    'animation' => '',       
    'el_class'  => '',         
    'style_l2'  => 'style-primary',         
), $atts));
$animation_tmp = isset($animation) ? $animation : '';
$animation_classes = $this->getCSSAnimation( $animation_tmp );
if(class_exists('WPCF7')) { ?>
    <div class="cms-contact-form cms-contact-form-style2 <?php echo esc_attr( $style_l2.' '.$el_class.' '.$animation_classes )?>">
    	<?php if(!empty($el_title)) : ?>
        <div class="cms-contact-form-header scroll-to-content">
            <h3 class="el-title"><?php echo esc_attr( $el_title ); ?></h3>
            <a href="#vc-main"></a>
        </div>
        <?php endif; ?>
        <div class="cms-contact-form-body">
            <?php echo do_shortcode('[contact-form-7 id="'.esc_attr( $id ).'"]'); ?>
        </div>
    </div>
<?php } ?>