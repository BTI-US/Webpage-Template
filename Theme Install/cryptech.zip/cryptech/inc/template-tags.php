<?php
/**
 * Custom template tags for this theme.
 *
 * @package Cryptech
 */

/**
 * Header layout
 **/
function cryptech_page_loading()
{
    $page_loading = cryptech_get_opt( 'show_page_loading', false );

    if($page_loading) { ?>
        <div id="cms-loadding" class="cms-loader">
            <div class="loading-spin">
                <div class="spinner">
                    <div class="right-side"><div class="bar"></div></div>
                    <div class="left-side"><div class="bar"></div></div>
                </div>
                <div class="spinner color-2" style="">
                    <div class="right-side"><div class="bar"></div></div>
                    <div class="left-side"><div class="bar"></div></div>
                </div>
            </div>
        </div>
    <?php }
}

/**
 * Header layout
 **/
function cryptech_header_layout()
{
    $header_layout = cryptech_get_opt( 'header_layout', '1' );
    $custom_header = cryptech_get_page_opt( 'custom_header', '0' );

    if ( is_page() && $custom_header == '1' )
    {
        $page_header_layout = cryptech_get_page_opt('header_layout');
        $header_layout = $page_header_layout;
    }
    get_template_part( 'template-parts/header-layout', $header_layout );
}

/**
 * Page title layout
 **/
function cryptech_page_title_layout()
{
    $ptitle_layout = cryptech_get_opt( 'ptitle_layout', '1' );
    $custom_pagetitle = cryptech_get_page_opt( 'custom_pagetitle', '0' );

    if ( is_page() && $custom_pagetitle == '1' )
    {
        $page_ptitle_layout = cryptech_get_page_opt('ptitle_layout');
        $ptitle_layout = $page_ptitle_layout;
        if($ptitle_layout == '0') {
            return;
        }
    }
    get_template_part( 'template-parts/page-title', $ptitle_layout );
}

/**
 * Page title layout
 **/
function cryptech_footer()
{
    $footer_layout = cryptech_get_opt( 'footer_layout', '1' );
    $custom_footer = cryptech_get_page_opt( 'custom_footer', '0' );

    if ( is_page() && $custom_footer == '1' )
    {
        $page_footer_layout = cryptech_get_page_opt('footer_layout');
        $footer_layout = $page_footer_layout;
        if($footer_layout == '0') {
            return;
        }
    }
    get_template_part( 'template-parts/footer-layout', $footer_layout );
}

/**
 * Set primary content class based on sidebar position
 * 
 * @param  string $sidebar_pos
 * @param  string $extra_class
 */
function cryptech_primary_class( $sidebar_pos, $extra_class = '' )
{
    if ( (class_exists( 'WooCommerce' ) && is_shop()) || (class_exists( 'WooCommerce' ) && is_product_category()) || (class_exists( 'WooCommerce' ) && is_singular('product')) ) :
        $sidebar_load = 'sidebar-shop';
    elseif (is_page()) :
        $sidebar_load = 'sidebar-page';
    elseif (is_singular('case')) :
        $sidebar_load = 'sidebar-case';
    elseif (is_singular('service')) :
        $sidebar_load = 'sidebar-services';
    else :
        $sidebar_load = 'sidebar-blog';
    endif;

    if ( is_active_sidebar( $sidebar_load ) ) {
        $class = array( trim( $extra_class ) );
        switch ( $sidebar_pos )
        {
            case 'left':
                $class[] = 'content-has-sidebar float-right col-xl-9 col-lg-9 col-md-12';
                break;

            case 'right':
                $class[] = 'content-has-sidebar float-left col-xl-9 col-lg-9 col-md-12';
                break;

            default:
                $class[] = 'content-full-width col-12';
                break;
        }

        $class = implode( ' ', array_filter( $class ) );

        if ( $class )
        {
            echo ' class="' . esc_html($class) . '"';
        }
    } else {
        echo ' class="content-area col-12"';
    }
}

/**
 * Set secondary content class based on sidebar position
 * 
 * @param  string $sidebar_pos
 * @param  string $extra_class
 */
function cryptech_secondary_class( $sidebar_pos, $extra_class = '' )
{
    if ( (class_exists( 'WooCommerce' ) && is_shop()) || (class_exists( 'WooCommerce' ) && is_product_category()) || (class_exists( 'WooCommerce' ) && is_singular('product')) ) :
        $sidebar_load = 'sidebar-shop';
    elseif (is_page()) :
        $sidebar_load = 'sidebar-page';
    elseif (is_singular('case')) :
        $sidebar_load = 'sidebar-case';
    elseif (is_singular('service')) :
        $sidebar_load = 'sidebar-services';
    else :
        $sidebar_load = 'sidebar-blog';
    endif;

    if ( is_active_sidebar( $sidebar_load ) ) {
        $class = array(trim($extra_class));
        switch ($sidebar_pos) {
            case 'left':
                $class[] = 'widget-has-sidebar sidebar-fixed col-xl-3 col-lg-3 col-md-12';
                break;

            case 'right':
                $class[] = 'widget-has-sidebar sidebar-fixed col-xl-3 col-lg-3 col-md-12';
                break;

            default:
                break;
        }

        $class = implode(' ', array_filter($class));

        if ($class) {
            echo ' class="' . esc_html($class) . '"';
        }
    }
}


/**
 * Prints HTML for breadcrumbs.
 */
function cryptech_breadcrumb()
{
    if ( ! class_exists( 'CMS_Breadcrumb' ) )
    {
        return;
    }

    $breadcrumb = new CMS_Breadcrumb();
    $entries = $breadcrumb->get_entries();

    if ( empty( $entries ) )
    {
        return;
    }

    ob_start();

    foreach ( $entries as $entry )
    {
        $entry = wp_parse_args( $entry, array(
            'label' => '',
            'url'   => ''
        ) );

        if ( empty( $entry['label'] ) )
        {
            continue;
        }

        echo '<li>';

        if ( ! empty( $entry['url'] ) )
        {
            printf(
                '<a class="breadcrumb-entry" href="%1$s">%2$s</a>',
                esc_url( $entry['url'] ),
                esc_attr( $entry['label'] )
            );
        }
        else
        {
            printf( '<span class="breadcrumb-entry" >%s</span>', esc_html( $entry['label'] ) );
        }

        echo '</li>';
    }

    $output = ob_get_clean();

    if ( $output )
    {
        printf( '<ul class="cms-breadcrumb">%s</ul>', wp_kses_post($output));
    }
}


function cryptech_entry_link_pages()
{
    wp_link_pages( array(
        'before' => sprintf( '<div class="page-links">', esc_attr__( 'Pages:', 'cryptech' ) ),
        'after'  => '</div>',
    ) );
}


if ( ! function_exists( 'cryptech_entry_excerpt' ) ) :
    /**
     * Print post excerpt based on length.
     * 
     * @param  integer $length
     */
    function cryptech_entry_excerpt( $length = 55 )
    {  
        $cms_the_excerpt = get_the_excerpt();
        if(!empty($cms_the_excerpt)) {
            echo esc_html($cms_the_excerpt);
        } else {
            echo wp_kses_post(cryptech_get_the_excerpt( $length ));
        }
    }
endif;

/**
 * Prints post edit link when applicable
 */
function cryptech_entry_edit_link()
{
    edit_post_link(
        sprintf(
            wp_kses(
                /* translators: %s: Name of current post. Only visible to screen readers */
                __( 'Edit', 'cryptech' ),
                array(
                    'span' => array(
                        'class' => array(),
                    ),
                )
            ),
            get_the_title()
        ),
        '<div class="entry-edit-link"><i class="fa fa-edit"></i>',
        '</div>'
    );
}


/**
 * Prints posts pagination based on query
 *
 * @param  WP_Query $query     Custom query, if left blank, this will use global query ( current query )
 * @return void
 */
function cryptech_posts_pagination() {

    if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
        return;
    }

    $paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
    $pagenum_link = html_entity_decode( get_pagenum_link() );
    $query_args   = array();
    $url_parts    = explode( '?', $pagenum_link );

    if ( isset( $url_parts[1] ) ) {
        wp_parse_str( $url_parts[1], $query_args );
    }

    $pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
    $pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

    $links = paginate_links( array(
            'base'     => $pagenum_link,
            'total'    => $GLOBALS['wp_query']->max_num_pages,
            'current'  => $paged,
            'mid_size' => 1,
            'add_args' => array_map( 'urlencode', $query_args ),
            'prev_text' => '<i class="fa fa-long-arrow-left"></i>',
            'next_text' => '<i class="fa fa-long-arrow-right"></i>',
    ) );

    if ( $links ) :

    ?>
    <nav class="navigation posts-pagination clearfix">
        <div class="pagination loop-pagination">
            <?php echo wp_kses_post($links); ?>
        </div>
    </nav>
    <?php endif;
}

/**
 * Prints archive meta on blog
 */
if ( ! function_exists( 'cryptech_archive_meta' ) ) :
    function cryptech_archive_meta() {
        $archive_author_on = cryptech_get_opt( 'archive_author_on', true );
        $archive_categories_on = cryptech_get_opt( 'archive_categories_on', true );
        $archive_comments_on = cryptech_get_opt( 'archive_comments_on', true ); 
        $archive_date_on = cryptech_get_opt( 'archive_date_on', true );
        ?>
        <ul class="entry-meta">
            <?php if($archive_author_on) : ?>
                <li class="item-author">
                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 'medium' ); ?>
                    <span><?php echo esc_html__('by', 'cryptech'); ?></span>
                    <?php the_author_posts_link(); ?>
                </li>
            <?php endif; ?>
            <?php if($archive_comments_on) : ?>
                <li><a href="<?php the_permalink(); ?>"><?php echo comments_number(esc_html__('0 Comments', 'cryptech'),esc_html__('Comment 1', 'cryptech'),esc_html__('% Comments', 'cryptech')); ?></a></li>
            <?php endif; ?>
            <?php if($archive_categories_on) : ?>
                <li class="item-category"><?php the_terms( get_the_ID(), 'category', '', ', ' ); ?></li>
            <?php endif; ?>
            <?php if($archive_date_on) : ?>
                <li><?php echo get_the_date(); ?></li>
            <?php endif; ?>
            <?php if(is_sticky()) { ?>
                <li><?php echo esc_html__('Sticky', 'cryptech'); ?></li>
            <?php } ?>
        </ul>
    <?php }
endif;

if ( ! function_exists( 'cryptech_post_meta' ) ) :
    function cryptech_post_meta() {

        $post_author_on = cryptech_get_opt( 'post_author_on', false );
        $post_categories_on = cryptech_get_opt( 'post_categories_on', true );
        $post_comments_on = cryptech_get_opt( 'post_comments_on', false );
        $post_date_on = cryptech_get_opt( 'post_date_on', false );
        ?>
        <ul class="entry-meta">
            <?php if($post_author_on) : ?>
                <li class="item-author">
                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 'medium' ); ?>
                    <span><?php echo esc_html__('by', 'cryptech'); ?></span>
                    <?php the_author_posts_link(); ?>
                </li>
            <?php endif; ?>
            <?php if($post_comments_on) : ?>
                <li><a href="<?php the_permalink(); ?>"><?php echo comments_number(esc_html__('0 Comments', 'cryptech'),esc_html__('Comment 1', 'cryptech'),esc_html__('% Comments', 'cryptech')); ?></a></li>
            <?php endif; ?>
            <?php if($post_categories_on) : ?>
                <li class="item-category"><?php the_terms( get_the_ID(), 'category', '', ', ' ); ?></li>
            <?php endif; ?>
            <?php if($post_date_on) : ?>
                <li><?php echo get_the_date(); ?></li>
            <?php endif; ?>
            <?php if(is_sticky()) { ?>
                <li><?php echo esc_html__('Sticky', 'cryptech'); ?></li>
            <?php } ?>
        </ul>
    <?php }
endif;

/**
 * Prints tag list
 */
if ( ! function_exists( 'cryptech_entry_tagged_in' ) ) :
    /**
     * Prints HTML with meta information for the current post-date/time.
     */
    function cryptech_entry_tagged_in()
    {
        $tags_list = get_the_tag_list( '<label class="label">'.esc_attr__('Tags:', 'cryptech').'</label>', ' ' );

        if ( $tags_list )
        {
            echo '<div class="entry-tags">';
            printf('%2$s', '', $tags_list);
            echo '</div>';
        }
    }
endif;

/**
 * List socials share for post.
 */
function cryptech_socials_share()
{
    $top_bar_email = cryptech_get_opt( 'top_bar_email' ); ?>
    <ul class="clearfix">
        <li><a class="fb-social" title="Facebook" data-placement="top" data-rel="tooltip" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa fa-facebook"></i></a></li>
        <li><a class="tw-social" title="Twitter" data-placement="top" data-rel="tooltip" target="_blank" href="https://twitter.com/home?status=<?php esc_html_e('Check out this article', 'cryptech'); ?>:%20<?php the_title(); ?>%20-%20<?php the_permalink(); ?>"><i class="fa fa-twitter"></i></a></li>
        <li><a class="g-social" title="Google Plus" data-placement="top" data-rel="tooltip" target="_blank"href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class="fa fa-google-plus"></i></a></li>
        <li><a title="Email" data-placement="top" data-rel="tooltip" target="_blank" href="mailto:<?php if (!empty($top_bar_email)) { echo wp_kses_post($top_bar_email); } ?>?subject=<?php echo get_the_title(); ?>&amp;body=Check out this site <?php echo esc_url(get_permalink()); ?>"><i class="fa fa-envelope"></i></i></a></li>
        <li class="print"><a href="#" onclick="window.print()"><i class="fa fa-print"></i></a></li>
    </ul>
    <?php
}

/**
 * Header Search Popup
 */
function cryptech_search_popup()
{
    $h_seach_icon = cryptech_get_opt( 'h_seach_icon', false );
    if($h_seach_icon) : ?>
    <div class="cms-modal cms-search-popup">
        <div class="cms-close"></div>
        <div class="cms-modal-content">
            <form role="search" method="get" class="cms-search-form placeholder-white" action="<?php echo esc_url(home_url( '/' )); ?>">
                <i class="fa fa-search"></i>
                <input type="text" placeholder="<?php esc_html_e('Search...', 'cryptech'); ?>" name="s" class="search-field" />
            </form>
        </div>
    </div>
<?php endif; }

/**
 * Footer Top
 */
function cryptech_footer_top() {
    $footer_top_column = cryptech_get_opt( 'footer_top_column' );

    if(empty($footer_top_column))
        return;

    $_class = "";

    switch ($footer_top_column){
        case '2':
            $_class = 'col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12';
            break;
        case '3':
            $_class = 'col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12';
            break;
        case '4':
            $_class = 'col-xl-3 col-lg-3 col-md-6 col-sm-12 col-xs-12';
            break;
        case '5':
            $_class = 'cms-col-5';
            break;
    }

    for($i = 1 ; $i <= $footer_top_column ; $i++){
        if ( is_active_sidebar( 'sidebar-footer-' . $i ) ){
            echo '<div class="cms-footer-item ' . esc_html($_class) . '">';
                dynamic_sidebar( 'sidebar-footer-' . $i );
            echo "</div>";
        }
    }
}

/* Author Social */
function cryptech_get_user_social() {

    $user_facebook = get_user_meta(get_the_author_meta( 'ID' ), 'user_facebook', true);
    $user_twitter = get_user_meta(get_the_author_meta( 'ID' ), 'user_twitter', true);
    $user_linkedin = get_user_meta(get_the_author_meta( 'ID' ), 'user_linkedin', true);
    $user_skype = get_user_meta(get_the_author_meta( 'ID' ), 'user_skype', true);
    $user_google = get_user_meta(get_the_author_meta( 'ID' ), 'user_google', true);
    $user_youtube = get_user_meta(get_the_author_meta( 'ID' ), 'user_youtube', true);
    $user_vimeo = get_user_meta(get_the_author_meta( 'ID' ), 'user_vimeo', true);
    $user_tumblr = get_user_meta(get_the_author_meta( 'ID' ), 'user_tumblr', true);
    $user_rss = get_user_meta(get_the_author_meta( 'ID' ), 'user_rss', true);
    $user_pinterest = get_user_meta(get_the_author_meta( 'ID' ), 'user_pinterest', true);
    $user_instagram = get_user_meta(get_the_author_meta( 'ID' ), 'user_instagram', true);
    $user_yelp = get_user_meta(get_the_author_meta( 'ID' ), 'user_yelp', true);

    ?>
    <ul class="user-social">
        <?php if(!empty($user_facebook)) { ?>
            <li><a href="<?php echo esc_url($user_facebook); ?>"><i class="fa fa-facebook"></i></a></li>
       <?php } ?>
        <?php if(!empty($user_twitter)) { ?>
            <li><a href="<?php echo esc_url($user_twitter); ?>"><i class="fa fa-twitter"></i></a></li>
        <?php } ?>
        <?php if(!empty($user_linkedin)) { ?>
            <li><a href="<?php echo esc_url($user_linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
        <?php } ?>
        <?php if(!empty($user_rss)) { ?>
            <li><a href="<?php echo esc_url($user_rss); ?>"><i class="fa fa-rss"></i></a></li>
        <?php } ?>
        <?php if(!empty($user_instagram)) { ?>
            <li><a href="<?php echo esc_url($user_instagram); ?>"><i class="fa fa-instagram"></i></a></li> 
        <?php } ?>
        <?php if(!empty($user_google)) { ?>
            <li><a href="<?php echo esc_url($user_google); ?>"><i class="fa fa-google-plus"></i></a></li>  
        <?php } ?>
        <?php if(!empty($user_skype)) { ?> 
            <li><a href="<?php echo esc_url($user_skype); ?>"><i class="fa fa-skype"></i></a></li>   
        <?php } ?>
        <?php if(!empty($user_pinterest)) { ?>
            <li><a href="<?php echo esc_url($user_pinterest); ?>"><i class="fa fa-pinterest"></i></a></li>  
        <?php } ?>
        <?php if(!empty($user_vimeo)) { ?> 
            <li><a href="<?php echo esc_url($user_vimeo); ?>"><i class="fa fa-vimeo"></i></a></li>  
        <?php } ?>
        <?php if(!empty($user_youtube)) { ?>
            <li><a href="<?php echo esc_url($user_youtube); ?>"><i class="fa fa-youtube"></i></a></li> 
        <?php } ?> 
        <?php if(!empty($user_yelp)) { ?> 
            <li><a href="<?php echo esc_url($user_yelp); ?>"><i class="fa fa-yelp"></i></a></li>
        <?php } ?>
        <?php if(!empty($user_tumblr)) { ?>
            <li><a href="<?php echo esc_url($user_tumblr); ?>"><i class="fa fa-tumblr"></i></a></li>  
        <?php } ?>

    </ul> <?php  
}

/**
* Display navigation to next/previous post when applicable.
*/
function cryptech_post_nav() {
    global $post;
    // Don't print empty markup if there's nowhere to navigate.
    $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
    $next     = get_adjacent_post( false, '', false );

    if ( ! $next && ! $previous )
        return;
    ?>
    <?php
    $next_post = get_next_post();
    $previous_post = get_previous_post();
    if( !empty($next_post) || !empty($previous_post) ) { ?>
    <div class="post-previous-next">
        <div class="nav-links row clearfix">
            <div class="nav-link-prev col-md-6 col-sm-6 col-xs-12 text-left">
                <?php if ( is_a( $previous_post , 'WP_Post' ) && get_the_title( $previous_post->ID ) != '') { ?>
                    <a href="<?php echo esc_url(get_permalink( $previous_post->ID )); ?>">
                        <?php 
                            $url_prev = wp_get_attachment_image_src(get_post_thumbnail_id($previous_post->ID), 'thumbnail', false);
                        ?>
                        <span class="nav-image" style="background-image: url(<?php echo esc_url($url_prev[0]); ?>);"></span>
                        <div class="nav-inner">
                            <span><?php echo esc_html_e('Previous', 'cryptech') ?></span>
                            <h3><?php echo get_the_title( $previous_post->ID ); ?></h3>
                        </div>
                    </a>
                <?php } ?>
            </div>
            <div class="nav-link-next col-md-6 col-sm-6 col-xs-12 text-right">
                <?php if ( is_a( $next_post , 'WP_Post' ) && get_the_title( $next_post->ID ) != '') { ?>
                    <a href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>">
                        <?php
                            $url_next = wp_get_attachment_image_src(get_post_thumbnail_id($next_post->ID), 'thumbnail', false);
                        ?>
                        <span class="overlay-gradient nav-image" style="background-image: url(<?php echo esc_url($url_next[0]); ?>);"></span>
                        <div class="nav-inner">
                            <span><?php echo esc_html_e('Next', 'cryptech') ?></span>
                            <h3><?php echo get_the_title( $next_post->ID ); ?></h3>
                        </div>
                    </a>
                <?php } ?>
            </div>
        </div><!-- .nav-links -->
    </div>
    <?php }
}
/**
 * Login + Register
 * 
 * @author Zack
 */
function cryptech_login_register() {
    $h_btn_group = cryptech_get_opt( 'h_btn_group', 'hidden' );

    if(function_exists('up_get_template_part') && $h_btn_group == 'signup' && !is_user_logged_in() || function_exists('up_get_template_part') && $h_btn_group == 'signin-signup' && !is_user_logged_in()) { ?>
        <div class="cms-modal cms-login-popup">
            <div class="cms-modal-content">
                <div class="cms-close"></div>
                <div class="cms-modal-holder">
                    <div class="cms-modal-header">
                        <h3 class="widget-title"><?php esc_html_e('Sign In', 'cryptech'); ?></h3>
                    </div>
                    <div class="cms-modal-body modal-body">
                        <?php  echo do_shortcode('[user-press layout="" form_type="login" is_logged="profile"]'); ?>
                    </div>
                </div>
                <div class="cms-modal-footer">
                    <a href="javascript:void(0)" class="btn-sign-up"> <?php esc_html_e('Sign Up Here', 'cryptech');?></a>
                </div>
            </div>
        </div>
        <div class="cms-modal cms-register-popup">
            <div class="cms-modal-content">
                <div class="cms-close"></div>
                <div class="cms-modal-holder">
                    <div class="cms-modal-header">
                        <h3 class="widget-title"><?php esc_html_e('Sign Up', 'cryptech'); ?></h3>
                    </div>
                    <div class="cms-modal-body modal-body">
                        <?php up_get_template_part('default/form', 'register'); ?>
                    </div>
                </div>
                <div class="cms-modal-footer">
                    <a href="javascript:void(0)" class="btn-sign-in"> <?php esc_html_e('Sign In Here', 'cryptech');?></a>
                </div>
            </div>
        </div>
    <?php }
}

/**
 * Header Social
 * 
 * @author Zack
 */
function cryptech_header_social(){
    $h_social = cryptech_get_opt( 'h_social' );
    $social = $h_social['enabled'];

    if ($social) : foreach ($social as $key=>$value) { ?>
        <?php switch($key) {
     
            case 'facebook': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_facebook_url' )).'"><i class="zmdi zmdi-facebook"></i></a></li>';
            break;
     
            case 'twitter': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_twitter_url' )).'"><i class="zmdi zmdi-twitter"></i></a></li>';
            break;
     
            case 'linkedin': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_inkedin_url' )).'"><i class="zmdi zmdi-linkedin"></i></a></li>';
            break;
            
            case 'instagram': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_instagram_url' )).'"><i class="zmdi zmdi-instagram"></i></a></li>';    
            break;

            case 'google': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_google_url' )).'"><i class="zmdi zmdi-google-plus"></i></a></li>';    
            break;

            case 'skype': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_skype_url' )).'"><i class="zmdi zmdi-skype"></i></a></li>';    
            break;

            case 'pinterest': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_pinterest_url' )).'"><i class="zmdi zmdi-pinterest"></i></a></li>';    
            break;

            case 'vimeo': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_vimeo_url' )).'"><i class="zmdi zmdi-vimeo"></i></a></li>';    
            break;

            case 'youtube': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_youtube_url' )).'"><i class="zmdi zmdi-youtube"></i></a></li>';    
            break;

            case 'yelp': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_yelp_url' )).'"><i class="fa fa-yelp"></i></a></li>';    
            break;

            case 'tumblr': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_tumblr_url' )).'"><i class="fa fa-tumblr"></i></a></li>';    
            break;

            case 'tripadvisor': echo '<a class="h-social" href="'.esc_url(cryptech_get_opt( 'social_tripadvisor_url' )).'"><i class="fa fa-tripadvisor"></i></a></li>';    
            break;

        }
    }
    endif;
}