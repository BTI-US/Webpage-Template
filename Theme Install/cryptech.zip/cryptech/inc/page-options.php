<?php
/**
 * Register metabox for posts based on Redux Framework. Supported methods:
 *     isset_args( $post_type )
 *     set_args( $post_type, $redux_args, $metabox_args )
 *     add_section( $post_type, $sections )
 * Each post type can contains only one metabox. Pease note that each field id
 * leads by an underscore sign ( _ ) in order to not show that into Custom Field
 * Metabox from WordPress core feature.
 *
 * @param  cryptech_Post_Metabox $metabox
 */
/**
 * get list menu.
 * @return array
 */
function cryptech_get_nav_menu(){

    $menus = array(
        '' => esc_html__('Default', 'cryptech')
    );

    $obj_menus = wp_get_nav_menus();

    foreach ($obj_menus as $obj_menu){
        $menus[$obj_menu->term_id] = $obj_menu->name;
    }

    return $menus;
}

function cryptech_page_options_register($metabox)
{

    if (!$metabox->isset_args('page')) {
        $metabox->set_args('page', array(
            'opt_name'     => cryptech_get_page_opt_name(),
            'display_name' => esc_html__('Page Settings', 'cryptech'),
            'show_options_object' => false,
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('cms_pf_audio')) {
        $metabox->set_args('cms_pf_audio', array(
            'opt_name'     => 'post_format_audio',
            'display_name' => esc_html__('Audio', 'cryptech'),
            'class' => 'fully-expanded',
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('cms_pf_link')) {
        $metabox->set_args('cms_pf_link', array(
            'opt_name'     => 'post_format_link',
            'display_name' => esc_html__('Link', 'cryptech')
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('cms_pf_quote')) {
        $metabox->set_args('cms_pf_quote', array(
            'opt_name'     => 'post_format_quote',
            'display_name' => esc_html__('Quote', 'cryptech')
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('cms_pf_video')) {
        $metabox->set_args('cms_pf_video', array(
            'opt_name'     => 'post_format_video',
            'display_name' => esc_html__('Video', 'cryptech'),
            'class' => 'fully-expanded',
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('cms_pf_gallery')) {
        $metabox->set_args('cms_pf_gallery', array(
            'opt_name'     => 'post_format_gallery',
            'display_name' => esc_html__('Gallery', 'cryptech'),
            'class' => 'fully-expanded',
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('post')) {
        $metabox->set_args('post', array(
            'opt_name'     => 'post_option',
            'display_name' => esc_html__('Post Settings', 'cryptech'),
            'show_options_object' => false,
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('gallerie')) {
        $metabox->set_args('gallerie', array(
            'opt_name'     => 'gallrie_option',
            'display_name' => esc_html__('Gallery Settings', 'cryptech'),
            'show_options_object' => false,
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('case')) {
        $metabox->set_args('case', array(
            'opt_name'     => 'case_option',
            'display_name' => esc_html__('Case Settings', 'cryptech'),
            'show_options_object' => false,
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    if (!$metabox->isset_args('service')) {
        $metabox->set_args('service', array(
            'opt_name'     => 'service_option',
            'display_name' => esc_html__('Services Settings', 'cryptech'),
            'show_options_object' => false,
        ), array(
            'context'  => 'advanced',
            'priority' => 'default'
        ));
    }

    /**
     * Config post meta options
     *
     */

    $metabox->add_section('post', array(
        'title'  => esc_html__('Sidebar Position', 'cryptech'),
        'icon'   => 'el el-refresh',
        'fields' => array(
            array(
                'id'       => 'custom_sidebar_post',
                'type'     => 'switch',
                'title'    => esc_html__('Custom Sidebar Position', 'cryptech'),
                'default'  => false,
                'indent' => true
            ),
            array(
                'id'       => 'sidebar_post_pos',
                'type'     => 'button_set',
                'title'    => esc_html__('Sidebar Position', 'cryptech'),
                'options'  => array(
                    'left'  => esc_html__('Left', 'cryptech'),
                    'right' => esc_html__('Right', 'cryptech'),
                    'none'  => esc_html__('Disabled', 'cryptech')
                ),
                'default'  => 'right',
                'required' => array( 0 => 'custom_sidebar_post', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
        )
    ));

    /**
     * Config page meta options
     *
     */
    $metabox->add_section('page', array(
        'title'  => esc_html__('Header', 'cryptech'),
        'desc'   => esc_html__('Header settings for the page.', 'cryptech'),
        'icon'   => 'el-icon-website',
        'fields' => array(
            array(
                'id'       => 'custom_header',
                'type'     => 'switch',
                'title'    => esc_html__('Custom Header', 'cryptech'),
                'default'  => false,
                'indent' => true
            ),
            array(
                'id'       => 'header_layout',
                'type'     => 'image_select',
                'title'    => esc_html__('Layout', 'cryptech'),
                'subtitle' => esc_html__('Select a layout for header.', 'cryptech'),
                'options'  => array(
                    '1' => get_template_directory_uri() . '/assets/images/header-layout/h1.jpg',
                    '2' => get_template_directory_uri() . '/assets/images/header-layout/h2.jpg',
                    '3' => get_template_directory_uri() . '/assets/images/header-layout/h3.jpg',
                    '4' => get_template_directory_uri() . '/assets/images/header-layout/h4.jpg',
                    '5' => get_template_directory_uri() . '/assets/images/header-layout/h5.jpg',
                ),
                'default'  => cryptech_get_option_of_theme_options('header_layout'),
                'required' => array( 0 => 'custom_header', 1 => 'equals', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_h_header',
                'type'     => 'button_set',
                'title'    => esc_html__('Height Header', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'h_medium'  => esc_html__('Medium', 'cryptech'),
                    'h_small'  => esc_html__('Small', 'cryptech'),
                ),
                'default'  => 'themeoption',
                'required' => array(
                    array('header_layout','!=','5'), 
                ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_h_divider',
                'type'     => 'button_set',
                'title'    => esc_html__('Divider', 'cryptech'),
                'options'  => array(
                    'show'  => esc_html__('Show', 'cryptech'),
                    'hidden'  => esc_html__('Hidden', 'cryptech'),
                ),
                'default'  => 'show',
                'required' => array( 0 => 'header_layout', 1 => 'equals', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_h_seach_icon',
                'type'     => 'button_set',
                'title'    => esc_html__('Search Icon', 'cryptech'),
                'options'  => array(
                    'default'  => esc_html__('Theme Option', 'cryptech'),
                    'hidden'  => esc_html__('Hidden', 'cryptech'),
                ),
                'default'  => 'default',
                'required' => array(
                    array('custom_header','equals','1'),
                ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_h_btn_group',
                'type'     => 'button_set',
                'title'    => esc_html__('Button Group', 'cryptech'),
                'options'  => array(
                    'default'  => esc_html__('Theme Option', 'cryptech'),
                    'hidden'  => esc_html__('Hidden', 'cryptech'),
                    'signup'  => esc_html__('Sign Up', 'cryptech'),
                    'signin-signup'  => esc_html__('Sign In/Sign Up', 'cryptech'),
                    'social'  => esc_html__('Social', 'cryptech'),
                    'cart'  => esc_html__('Cart', 'cryptech'),
                ),
                'default'  => 'default',
                'required' => array(
                    array('custom_header','equals','1'),
                    array('header_layout','!=','5'), 
                ),
                'force_output' => true
            ),
            array(
                'id'       => 'h_btn_group_hover_type_page',
                'type'     => 'button_set',
                'title'    => esc_html__('Button Hover Type', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'h-btn-hover-primary'  => esc_html__('Primary', 'cryptech'),
                    'h-btn-hover-inherit'  => esc_html__('Dark', 'cryptech'),
                ),
                'default'  => 'themeoption',
                'required' => array(
                    array('custom_header','equals','1'),
                    array('header_layout','!=','5'), 
                ),
                'force_output' => true
            ),
            array(
                'id'       => 'magic_line_position_page',
                'type'     => 'button_set',
                'title'    => esc_html__('Magic Line Position', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'magic-line-bottom'  => esc_html__('Bottom', 'cryptech'),
                    'magic-line-middle' => esc_html__('Middle', 'cryptech'),
                ),
                'default'  => 'themeoption',
                'required' => array(
                    array('custom_header','equals','1'),
                    array('header_layout','!=','5'), 
                ),
                'force_output' => true
            ),
            array(
                'id'       => 'magic_line_color_page',
                'type'     => 'button_set',
                'title'    => esc_html__('Magic Line Color', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'magic-line-primary'  => esc_html__('Primary', 'cryptech'),
                    'magic-line-dark'  => esc_html__('Dark', 'cryptech'),
                    'magic-line-white' => esc_html__('White', 'cryptech'),
                ),
                'default'  => 'themeoption',
                'required' => array(
                    array('custom_header','equals','1'),
                    array('header_layout','!=','5'), 
                ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_h_custom_menu',
                'type'     => 'select',
                'title'    => esc_html__( 'Select Menu', 'cryptech' ),
                'subtitle' => esc_html__( 'Custom menu for current page.', 'cryptech' ),
                'options'  => cryptech_get_nav_menu(),
                'default' => '',
                'required' => array( 0 => 'custom_header', 1 => 'equals', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'cry_currency_price_page',
                'type'     => 'button_set',
                'title'    => esc_html__('Crypto Currency Price', 'cryptech'),
                'subtitle' => esc_html__('Show/Hide Crypto Currency Price widget on header layout 2, 4', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'show'  => esc_html__('Show', 'cryptech'),
                    'hide' => esc_html__('Hide', 'cryptech'),
                ),
                'default'  => 'themeoption',
                'required' => array( 0 => 'custom_header', 1 => 'equals', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'cry_currency_price_position_page',
                'type'     => 'button_set',
                'title'    => esc_html__('Crypto Currency Price Position', 'cryptech'),
                'subtitle' => esc_html__('Displayed above or below the header.', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'top'  => esc_html__('Top', 'cryptech'),
                    'bottom' => esc_html__('Bottom', 'cryptech'),
                ),
                'default'  => 'themeoption',
                'required' => array( 0 => 'header_layout', 1 => 'equals', 2 => '2' ),
                'force_output' => true
            ),
            array(
                'title' => esc_html__('Button Navigation', 'cryptech'),
                'type'  => 'section',
                'id' => 'button_navigation',
                'indent' => true,
                'required' => array( 0 => 'custom_header', 1 => 'equals', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'h_btn_on_page',
                'type'     => 'button_set',
                'title'    => esc_html__('Show/Hide Button', 'cryptech'),
                'options'  => array(
                    'themeoption'  => esc_html__('Theme Option', 'cryptech'),
                    'show'  => esc_html__('Show', 'cryptech'),
                    'hide'  => esc_html__('Hide', 'cryptech')
                ),
                'default'  => 'themeoption',
            ),
            array(
                'id' => 'page_h_btn_text',
                'type' => 'text',
                'title' => esc_html__('Button Text', 'cryptech'),
                'default' => '',
                'required' => array( 0 => 'custom_header', 1 => 'equals', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_btn_link_type',
                'type'     => 'button_set',
                'title'    => esc_html__('Butotn Link Type', 'cryptech'),
                'options'  => array(
                    'page'  => esc_html__('Page', 'cryptech'),
                    'custom'  => esc_html__('Custom', 'cryptech')
                ),
                'default'  => 'page',
            ),
            array(
                'id'    => 'page_h_btn_link',
                'type'  => 'select',
                'title' => esc_html__( 'Page Link', 'cryptech' ), 
                'data'  => 'page',
                'args'  => array(
                    'post_type'      => 'page',
                    'posts_per_page' => -1,
                    'orderby'        => 'title',
                    'order'          => 'ASC',
                ),
                'required' => array( 0 => 'page_btn_link_type', 1 => 'equals', 2 => 'page' ),
                'force_output' => true
            ),
            array(
                'id' => 'page_btn_link_custom',
                'type' => 'text',
                'title' => esc_html__('Custom Link', 'cryptech'),
                'default' => '',
                'required' => array( 0 => 'page_btn_link_type', 1 => 'equals', 2 => 'custom' ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_h_btn_style',
                'type'     => 'button_set',
                'title'    => esc_html__('Button Style', 'cryptech'),
                'options'  => array(
                    'default'  => esc_html__('Default', 'cryptech'),
                    'primary'  => esc_html__('Primary Outline', 'cryptech'),
                    'primary-alt'  => esc_html__('Primary Alt', 'cryptech'),
                    'white'  => esc_html__('White', 'cryptech'),
                ),
                'default'  => 'default',
                'required' => array(
                    array('custom_header','equals','1'),
                    array('header_layout','!=','5'), 
                ),
                'force_output' => true
            ),
        )
    ));

    $metabox->add_section('page', array(
        'title'  => esc_html__('Page Title', 'cryptech'),
        'desc'   => esc_html__('Settings for page title.', 'cryptech'),
        'icon'   => 'el-icon-map-marker',
        'fields' => array(
            array(
                'id'       => 'custom_pagetitle',
                'type'     => 'switch',
                'title'    => esc_html__('Custom Page Title', 'cryptech'),
                'default'  => false,
                'indent' => true
            ),
            array(
                'id'       => 'ptitle_layout',
                'type'     => 'image_select',
                'title'    => esc_html__('Layout', 'cryptech'),
                'subtitle' => esc_html__('Select a layout for page title.', 'cryptech'),
                'options'  => array(
                    '0' => get_template_directory_uri() . '/assets/images/page-title-layout/p0.jpg',
                    '1' => get_template_directory_uri() . '/assets/images/page-title-layout/p1.jpg',
                ),
                'default'  => cryptech_get_option_of_theme_options('ptitle_layout'),
                'required' => array( 0 => 'custom_pagetitle', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'custom_title',
                'type'     => 'text',
                'title'    => esc_html__('Custom Title', 'cryptech'),
                'subtitle' => esc_html__('Use custom title for this page. The default title will be used on document title.', 'cryptech'),
                'required' => array( 0 => 'custom_pagetitle', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'ptitle_bg',
                'type'     => 'background',
                'title'    => esc_html__('Background', 'cryptech'),
                'subtitle' => esc_html__('Page title background.', 'cryptech'),
                'output'   => array('#pagetitle'),
                'background-color'   => false,
                'background-repeat'   => false,
                'background-position'   => false,
                'background-attachment'   => false,
                'background-size'   => false,
                'required' => array( 0 => 'custom_pagetitle', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
        )
    ));

    $metabox->add_section('page', array(
        'title'  => esc_html__('Content', 'cryptech'),
        'desc'   => esc_html__('Settings for content area.', 'cryptech'),
        'icon'   => 'el-icon-pencil',
        'fields' => array(
            array(
                'id'       => 'content_bg_color',
                'type'     => 'color_rgba',
                'title'    => esc_html__('Background Color', 'cryptech'),
                'subtitle' => esc_html__('Content background color.', 'cryptech'),
                'output' => array('background-color' => '#content')
            ),
            array(
                'id'             => 'content_padding',
                'type'           => 'spacing',
                'output'         => array('#content'),
                'right'   => false,
                'left'    => false,
                'mode'           => 'padding',
                'units'          => array('px'),
                'units_extended' => 'false',
                'title'          => esc_html__('Content Padding', 'cryptech'),
                'desc'           => esc_html__('Default: Top-90px, Bottom-90px', 'cryptech'),
                'default'            => array(
                    'padding-top'   => '',  
                    'padding-bottom'   => '',  
                    'units'          => 'px', 
                )
            ),
            array(
                'id'       => 'show_sidebar_page',
                'type'     => 'switch',
                'title'    => esc_html__('Show Sidebar', 'cryptech'),
                'default'  => false,
                'indent' => true
            ),
            array(
                'id'       => 'sidebar_page_pos',
                'type'     => 'button_set',
                'title'    => esc_html__('Sidebar Position', 'cryptech'),
                'options'  => array(
                    'left'  => esc_html__('Left', 'cryptech'),
                    'right' => esc_html__('Right', 'cryptech'),
                ),
                'default'  => 'right',
                'required' => array( 0 => 'show_sidebar_page', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
        )
    ));

    $metabox->add_section('page', array(
        'title'  => esc_html__('Footer', 'cryptech'),
        'desc'   => esc_html__('Settings for page footer.', 'cryptech'),
        'icon'   => 'el el-website',
        'fields' => array(
            array(
                'id'       => 'custom_footer',
                'type'     => 'switch',
                'title'    => esc_html__('Custom Footer', 'cryptech'),
                'default'  => false,
                'indent' => true
            ),
            array(
                'id'       => 'footer_layout',
                'type'     => 'image_select',
                'title'    => esc_html__('Layout', 'cryptech'),
                'subtitle' => esc_html__('Select a layout for upper footer area.', 'cryptech'),
                'options'  => array(
                    '0' => get_template_directory_uri() . '/assets/images/footer-layout/f0.jpg',
                    '1' => get_template_directory_uri() . '/assets/images/footer-layout/f1.jpg'
                ),
                'default'  => cryptech_get_option_of_theme_options('footer_layout'),
                'required' => array( 0 => 'custom_footer', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
            array(
                'id'       => 'page_app_footer',
                'type'     => 'button_set',
                'title'    => esc_html__('Apps', 'cryptech'),
                'options'  => array(
                    'default'  => esc_html__('Theme Option', 'cryptech'),
                    'show'  => esc_html__('Show', 'cryptech'),
                    'hidden'  => esc_html__('Hidden', 'cryptech'),
                ),
                'default'  => 'default',
                'required' => array( 0 => 'custom_footer', 1 => '=', 2 => '1' ),
                'force_output' => true
            ),
        ),
    ));

    /**
     * Config post format meta options
     *
     */

    $metabox->add_section('cms_pf_video', array(
        'title'  => esc_html__('Video', 'cryptech'),
        'fields' => array(
            array(
                'id'        => 'post-video-url',
                'type'      => 'text',
                'title'     => esc_html__( 'Video URL', 'cryptech' ),
                'desc'  => esc_html__( 'YouTube or Vimeo video URL', 'cryptech' )
            ),

            array(
                'id'        => 'post-video-file',
                'type'      => 'editor',
                'title'     => esc_html__( 'Video Upload', 'cryptech' ),
                'desc'  => esc_html__( 'Upload video file', 'cryptech' )
            ),

            array(
                'id'        => 'post-video-html',
                'type'      => 'textarea',
                'title'     => esc_html__( 'Embadded video', 'cryptech' ),
                'desc'  => esc_html__( 'Use this option when the video does not come from YouTube or Vimeo', 'cryptech' )
            ),
        )
    ));

    $metabox->add_section('cms_pf_gallery', array(
        'title'  => esc_html__('Gallery', 'cryptech'),
        'fields' => array(
            array(
                'id'       => 'post-gallery-lightbox',
                'type'     => 'switch',
                'title'    => esc_html__('Lightbox?', 'cryptech'),
                'subtitle' => esc_html__('Enable lightbox for gallery images.', 'cryptech'),
                'default'  => true
            ),
            array(
                'id'          => 'post-gallery-images',
                'type'        => 'gallery',
                'title'       => esc_html__('Gallery Images ', 'cryptech'),
                'subtitle'    => esc_html__('Upload images or add from media library.', 'cryptech')
            )
        )
    ));

    $metabox->add_section('cms_pf_audio', array(
        'title'  => esc_html__('Audio', 'cryptech'),
        'fields' => array(
            array(
                'id'       => 'post-audio-url',
                'type'     => 'text',
                'title'    => esc_html__('Audio URL', 'cryptech'),
                'description' => esc_html__('Audio file URL in format: mp3, ogg, wav.', 'cryptech'),
                'validate' => 'url',
                'msg'      => 'Url error!'
            )
        )
    ));

    $metabox->add_section('cms_pf_link', array(
        'title'  => esc_html__('Link', 'cryptech'),
        'fields' => array(
            array(
                'id'       => 'post-link-url',
                'type'     => 'text',
                'title'    => esc_html__('URL', 'cryptech'),
                'validate' => 'url',
                'msg'      => 'Url error!'
            )
        )
    ));

    $metabox->add_section('cms_pf_quote', array(
        'title'  => esc_html__('Quote', 'cryptech'),
        'fields' => array(
            array(
                'id'       => 'post-quote-cite',
                'type'     => 'text',
                'title'    => esc_html__('Cite', 'cryptech')
            )
        )
    ));


    /**
     * Config gallery meta options
     *
     */
    $metabox->add_section('gallerie', array(
        'title'  => esc_html__('Grid Column', 'cryptech'),
        'icon'   => 'el-icon-website',
        'fields' => array(
            array(
                'id'       => 'el_col_xs',
                'type'     => 'select',
                'title'    => esc_html__('Column XS', 'cryptech'),
                'subtitle'    => esc_html__('575px < Devices < 767px', 'cryptech'),  
                'options'  => array(
                    '' => 'Default',
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
                'default'  => '',
            ),
            array(
                'id'       => 'el_col_sm',
                'type'     => 'select',
                'title'    => esc_html__('Column SM', 'cryptech'), 
                'subtitle'    => esc_html__('575px < Devices < 767px', 'cryptech'), 
                'options'  => array(
                    '' => 'Default',
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
                'default'  => '',
            ),
            array(
                'id'       => 'el_col_md',
                'type'     => 'select',
                'title'    => esc_html__('Column MD', 'cryptech'), 
                'subtitle'    => esc_html__('768px < Devices < 991px', 'cryptech'), 
                'options'  => array(
                    '' => 'Default',
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
                'default'  => '',
            ),
            array(
                'id'       => 'el_col_lg',
                'type'     => 'select',
                'title'    => esc_html__('Column LG', 'cryptech'), 
                'subtitle'    => esc_html__('Devices > 1200px', 'cryptech'), 
                'options'  => array(
                    '' => 'Default',
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ),
                'default'  => '',
            ),
        )
    ));

    /**
     * Config case meta options
     *
     */
    $metabox->add_section('case', array(
        'title'  => esc_html__('Page Title', 'cryptech'),
        'desc'   => esc_html__('Settings for page title.', 'cryptech'),
        'icon'   => 'el-icon-map-marker',
        'fields' => array(
            array(
                'id'       => 'case_ptitle_bg',
                'type'     => 'background',
                'title'    => esc_html__('Background', 'cryptech'),
                'subtitle' => esc_html__('Page title background.', 'cryptech'),
                'output'   => array('.single-case #pagetitle'),
                'background-color'   => false,
                'background-repeat'   => false,
                'background-position'   => false,
                'background-attachment'   => false,
                'background-size'   => false,
            ),
        )
    ));

    /**
     * Config service meta options
     *
     */
    $metabox->add_section('service', array(
        'title'  => esc_html__('Page Title', 'cryptech'),
        'desc'   => esc_html__('Settings for page title.', 'cryptech'),
        'icon'   => 'el-icon-map-marker',
        'fields' => array(
            array(
                'id'       => 'service_ptitle_bg',
                'type'     => 'background',
                'title'    => esc_html__('Background', 'cryptech'),
                'subtitle' => esc_html__('Page title background.', 'cryptech'),
                'output'   => array('.single-service #pagetitle'),
                'background-color'   => false,
                'background-repeat'   => false,
                'background-position'   => false,
                'background-attachment'   => false,
                'background-size'   => false,
            ),
        )
    ));
    $metabox->add_section('service', array(
        'title'  => esc_html__('Content', 'cryptech'),
        'desc'   => esc_html__('Settings for content area.', 'cryptech'),
        'icon'   => 'el-icon-pencil',
        'fields' => array(
            
            array(
                'id'=>'service_except',
                'type' => 'textarea',
                'title' => esc_html__('Except', 'cryptech'),
                'validate' => 'html_custom',
                'default' => '',
                'allowed_html' => array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'br' => array(),
                    'em' => array(),
                    'strong' => array(),
                    'div' => array(),
                )
            )
        )
    ));
}


add_action('cms_post_metabox_register', 'cryptech_page_options_register');

function cryptech_get_option_of_theme_options($key, $default = '')
{
    if (empty($key)) return '';
    $options = get_option(cryptech_get_opt_name(), array());
    $value = isset($options[$key]) ? $options[$key] : $default;
    return $value;
}