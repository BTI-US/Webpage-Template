<?php
if ( ! class_exists( 'ReduxFrameworkInstances' ) )
{
    return;
}

class CSS_Generator
{
    /**
     * scssc class instance
     *
     * @access protected
     * @var scssc
     */
    protected $scssc = null;

    /**
     * ReduxFramework class instance
     *
     * @access protected
     * @var ReduxFramework
     */
    protected $redux = null;

    /**
     * Debug mode is turn on or not
     *
     * @access protected
     * @var boolean
     */
    protected $dev_mode = true;

    /**
     * opt_name of ReduxFramework
     *
     * @access protected
     * @var string
     */
    protected $opt_name = '';


    /**
     * Constructor
     */
    function __construct()
    {
        $this->opt_name = cryptech_get_opt_name();

        if ( empty( $this->opt_name ) )
        {
            return;
        }
        add_filter( 'cms_scssc_on', '__return_true' );
        add_action( 'init', array( $this, 'init' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 20 );
    }

    /**
     * init hook - 10
     */
    function init()
    {
        if ( ! class_exists( 'scssc' ) )
        {
            return;
        }

        $this->redux = ReduxFrameworkInstances::get_instance( $this->opt_name );

        if ( empty( $this->redux ) || ! $this->redux instanceof ReduxFramework )
        {
            return;
        }

        $this->dev_mode = true;
        if ( $this->dev_mode === true )
        {
            $this->generate_file();
        }
        else
        {
            add_action( "redux/options/{$this->opt_name}/saved", array( $this, 'generate_file' ) );
        }
    }

    /**
     * Generate options and css files
     */
    function generate_file()
    {
        $scss_dir = get_template_directory() . '/assets/scss/';
        $css_dir  = get_template_directory() . '/assets/css/';

        $this->scssc = new scssc();
        $this->scssc->setImportPaths( $scss_dir );

        $_options = $scss_dir . 'variables.scss';

        $this->redux->filesystem->execute( 'put_contents', $_options, array(
            'content' => $this->options_output()
        ) );
        $css_file = $css_dir . 'theme.css';
        if ( ! $this->dev_mode )
        {
            $this->scssc->setFormatter( 'scss_formatter_compressed' );
            $css_file = $css_dir . 'theme.min.css';
        }else{
            $this->scssc->setFormatter( 'scss_formatter' );
        }
        $this->redux->filesystem->execute( 'put_contents', $css_file, array(
            'content' => $this->scssc->compile( '@import "theme.scss"' )
        ) );
    }

    /**
     * Output options to _variables.scss
     *
     * @access protected
     * @return string
     */
    protected function options_output()
    {
        ob_start();

        $primary_color = cryptech_get_opt( 'primary_color', '#ffb400' );
        if ( ! cryptech_is_valid_color( $primary_color ) )
        {
            $primary_color = '#ffb400';
        }
        printf( '$primary_color: %s;', esc_attr( $primary_color ) );

        $secondary_color = cryptech_get_opt( 'secondary_color', '#f9a33a' );
        if ( ! cryptech_is_valid_color( $secondary_color ) )
        {
            $secondary_color = '#f9a33a';
        }
        printf( '$secondary_color: %s;', esc_attr( $secondary_color ) );

        $link_color = cryptech_get_opt( 'link_color', '#ffb400' );
        if ( !empty($link_color['regular']) && isset($link_color['regular']) )
        {
            printf( '$link_color: %s;', esc_attr( $link_color['regular'] ) );
        } else {
            echo '$link_color: #ffb400;';
        }

        $link_color_hover = cryptech_get_opt( 'link_color', '#f9a33a' );
        if ( !empty($link_color['hover']) && isset($link_color['hover']) )
        {
            printf( '$link_color_hover: %s;', esc_attr( $link_color['hover'] ) );
        } else {
            echo '$link_color_hover: #f9a33a;';
        }

        $link_color_active = cryptech_get_opt( 'link_color', '#f9a33a' );
        if ( !empty($link_color['active']) && isset($link_color['active']) )
        {
            printf( '$link_color_active: %s;', esc_attr( $link_color['active'] ) );
        } else {
            echo '$link_color_active: #f9a33a;';
        }

        return ob_get_clean();
    }

    /**
     * Hooked wp_enqueue_scripts - 20
     * Make sure that the handle is enqueued from earlier wp_enqueue_scripts hook.
     */
    function enqueue()
    {
        $css = $this->inline_css();
        if ( !empty($css) )
        {
            wp_add_inline_style( 'cryptech-theme', $this->dev_mode ? $css : cryptech_css_minifier( $css ) );
        }
    }

    /**
     * Generate inline css based on theme options
     */
    protected function inline_css()
    {
        ob_start();

        /* Logo */
        $logo_maxh = cryptech_get_opt( 'logo_maxh' );

        if (isset($logo_maxh['height']) && $logo_maxh['height'] != 'px')
        {
            printf( '#site-header-wrap .site-branding a img { max-height: %s; }', esc_attr($logo_maxh['height']) );
        }

        /* Page Title */
        $ptitle_color = cryptech_get_opt( 'ptitle_color' );
        if ( ! empty( $ptitle_color ) )
        {
            printf( '#pagetitle h1.page-title { border-color: %s; }', esc_attr($ptitle_color) );
        }

        $ptitle_bg_color = cryptech_get_opt( 'ptitle_bg_color' );
        if ( ! empty( $ptitle_bg_color['rgba'] ) )
        {
            printf( '#pagetitle h1.page-title span { background-color: %s; }', esc_attr($ptitle_bg_color['rgba']) );
        }

        if ( class_exists( 'ReduxFrameworkInstances' ) )
        {
            echo'.entry-featured .post-image img {
                width: 100%;
            }';
            echo'.entry-featured .post-image a, .entry-featured .post-image span {
                display: block;
            }';
            echo'.entry-featured .overlay-gradient:before  {
                display: block;
            }';
        }

        return ob_get_clean();
    }
}

new CSS_Generator();