<?php
if (!class_exists('ReduxFramework')) {
    return;
}
if (class_exists('ReduxFrameworkPlugin')) {
    remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
}

$opt_name = cryptech_get_opt_name();
$theme = wp_get_theme();

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name'             => $opt_name,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name'         => $theme->get('Name'),
    // Name that appears at the top of your panel
    'display_version'      => $theme->get('Version'),
    // Version that appears at the top of your panel
    'menu_type'            => class_exists('CmssuperheroesCore') ? 'submenu' : '',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu'       => true,
    // Show the sections below the admin menu item or not
    'menu_title'           => esc_html__('Theme Options', 'cryptech'),
    'page_title'           => esc_html__('Theme Options', 'cryptech'),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key'       => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography'     => false,
    // Use a asynchronous font on the front end or font string
    //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
    'admin_bar'            => true,
    // Show the panel pages on the admin bar
    'admin_bar_icon'       => 'dashicons-admin-generic',
    // Choose an icon for the admin bar menu
    'admin_bar_priority'   => 50,
    // Choose an priority for the admin bar menu
    'global_variable'      => '',
    // Set a different name for your global variable other than the opt_name
    'dev_mode'             => false,
    // Show the time the page took to load, etc
    'update_notice'        => true,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer'           => true,
    // Enable basic customizer support
    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field
    'show_options_object' => false,
    // OPTIONAL -> Give you extra features
    'page_priority'        => null,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent'          => class_exists('CmssuperheroesCore') ? $theme->get('TextDomain') : '',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions'     => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon'            => '',
    // Specify a custom URL to an icon
    'last_tab'             => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon'            => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug'            => 'theme-options',
    // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
    'save_defaults'        => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show'         => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark'         => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export'   => true,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time'       => 60 * MINUTE_IN_SECONDS,
    'output'               => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag'           => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database'             => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
    'use_cdn'              => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    // HINTS
    'hints'                => array(
        'icon'          => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color'    => 'lightgray',
        'icon_size'     => 'normal',
        'tip_style'     => array(
            'color'   => 'red',
            'shadow'  => true,
            'rounded' => false,
            'style'   => '',
        ),
        'tip_position'  => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect'    => array(
            'show' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'mouseover',
            ),
            'hide' => array(
                'effect'   => 'slide',
                'duration' => '500',
                'event'    => 'click mouseleave',
            ),
        ),
    ),
    'templates_path'       => class_exists('CmssuperheroesCore') ? cmssuperheroes()->path('APP_DIR') . '/templates/redux/' : '',
);

Redux::SetArgs($opt_name, $args);

/*--------------------------------------------------------------
# General
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title'  => esc_html__('General', 'cryptech'),
    'icon'   => 'el-icon-home',
    'fields' => array(
        array(
            'id'       => 'show_page_loading',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Page Loading', 'cryptech'),
            'subtitle' => esc_html__('Enable Page Loading Effect When You Load Site', 'cryptech'),
            'default'  => false
        ),
    )
));

/*--------------------------------------------------------------
# Header
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title'  => esc_html__('Header', 'cryptech'),
    'icon'   => 'el-icon-website',
    'fields' => array(
        array(
            'id'       => 'header_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Layout', 'cryptech'),
            'subtitle' => esc_html__('Select a layout for header.', 'cryptech'),
            'options'  => array(
                '1' => get_template_directory_uri() . '/assets/images/header-layout/h1.jpg',
                '2' => get_template_directory_uri() . '/assets/images/header-layout/h2.jpg',
                '3' => get_template_directory_uri() . '/assets/images/header-layout/h3.jpg',
                '4' => get_template_directory_uri() . '/assets/images/header-layout/h4.jpg',
                '5' => get_template_directory_uri() . '/assets/images/header-layout/h5.jpg',
            ),
            'default'  => '1'
        ),
        array(
            'id'       => 'h_seach_icon',
            'type'     => 'switch',
            'title'    => esc_html__('Search Icon', 'cryptech'),
            'default'  => false
        ),
        array(
            'id'       => 'h_btn_group',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Group', 'cryptech'),
            'options'  => array(
                'hidden'  => esc_html__('Hidden', 'cryptech'),
                'signup'  => esc_html__('Sign Up', 'cryptech'),
                'signin-signup'  => esc_html__('Sign In/Sign Up', 'cryptech'),
                'social'  => esc_html__('Social', 'cryptech'),
                'cart'  => esc_html__('Cart', 'cryptech'),
            ),
            'default'  => 'hidden',
            'required' => array(
                array('header_layout','!=','5'), 
            ),
            'force_output' => true
        ),
        array(
            'id'       => 'h_btn_group_hover_type',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Hover Type', 'cryptech'),
            'options'  => array(
                'h-btn-hover-primary'  => esc_html__('Primary', 'cryptech'),
                'h-btn-hover-inherit'  => esc_html__('Dark', 'cryptech'),
            ),
            'default'  => 'h-btn-hover-primary',
            'required' => array(
                array('header_layout','!=','5'), 
            ),
            'force_output' => true
        ),
        array(
            'id'      => 'h_social',
            'type'    => 'sorter',
            'title'   => 'Social',
            'desc'    => 'Choose which social networks are displayed and edit where they link to.',
            'options' => array(
                'enabled'  => array(
                    'facebook'  => 'Facebook', 
                    'twitter'   => 'Twitter', 
                    'instagram' => 'Instagram',
                ),
                'disabled' => array(
                    'tripadvisor'     => 'Tripadvisor',
                    'google'    => 'Google',
                    'youtube'   => 'Youtube', 
                    'vimeo'     => 'Vimeo', 
                    'tumblr'    => 'Tumblr',
                    'pinterest' => 'Pinterest',
                    'yelp'      => 'Yelp',
                    'skype'     => 'Skype',
                    'linkedin'  => 'Linkedin',
                )
            ),
        ),
        array(
            'id'       => 'sticky_on',
            'type'     => 'switch',
            'title'    => esc_html__('Sticky Header', 'cryptech'),
            'subtitle' => esc_html__('Header will be sticked when applicable.', 'cryptech'),
            'default'  => false
        ),
        array(
            'id'       => 'h_header',
            'type'     => 'button_set',
            'title'    => esc_html__('Height Header', 'cryptech'),
            'options'  => array(
                'h_medium'  => esc_html__('Medium', 'cryptech'),
                'h_small'  => esc_html__('Small', 'cryptech'),
            ),
            'default'  => 'h_medium',
            'required' => array(
                array('header_layout','!=','5'), 
            ),
            'force_output' => true
        ),
    )
));

if(class_exists('Crypto_Currency_Price_Widget')) {
    $coins = get_posts( 'post_type="ccpw"&numberposts=-1' );
    $cry_shortcodes = array();
    if ( $coins ) {
        foreach ( $coins as $coin_ticker ) {
            $cry_shortcodes[ $coin_ticker->ID ] =  $coin_ticker->post_title;
        }
    } else {
        $cry_shortcodes[ esc_html__( 'No shortcode found', 'cryptech' ) ] = 0;
    }
} else {
    $cry_shortcodes = 'Please install Crypto Currency Price Widget plugin';
}
Redux::setSection($opt_name, array(
    'title'      => esc_html__('Top Bar', 'cryptech'),
    'icon'       => 'el-icon-circle-arrow-right',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'cry_currency_price',
            'type'     => 'button_set',
            'title'    => esc_html__('Crypto Currency Price', 'cryptech'),
            'subtitle' => esc_html__('Show/Hide Crypto Currency Price widget on header layout 2, 4', 'cryptech'),
            'options'  => array(
                'show'  => esc_html__('Show', 'cryptech'),
                'hide' => esc_html__('Hide', 'cryptech'),
            ),
            'default'  => 'hide'
        ),
        array(
            'id'       => 'cry_currency_price_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Crypto Currency Price Position', 'cryptech'),
            'subtitle' => esc_html__('Displayed above or below the header.', 'cryptech'),
            'options'  => array(
                'top'  => esc_html__('Top', 'cryptech'),
                'bottom' => esc_html__('Bottom', 'cryptech'),
            ),
            'default'  => 'top',
            'required' => array( 0 => 'cry_currency_price', 1 => 'equals', 2 => 'show' ),
            'force_output' => true
        ),
        array(
            'id'       => 'cry_currency_price_shortcode',
            'type'     => 'select',
            'title'    => __('Select Shortcode', 'cryptech'), 
            'options'  => $cry_shortcodes,
            'default'  => '',
            'required' => array( 0 => 'cry_currency_price', 1 => 'equals', 2 => 'show' ),
            'force_output' => true,
            'desc'           => 'You need to install <a href="https://wordpress.org/plugins/cryptocurrency-price-ticker-widget/" target="_blank">Cryptocurrency Price Ticker Widget</a> plugin.',
        ),
        array(
            'title' => esc_html__('Contact', 'cryptech'),
            'type'  => 'section',
            'id' => 'top_bar_contact',
            'indent' => true
        ),
        array(
            'id' => 'top_bar_phone_label',
            'type' => 'text',
            'title' => esc_html__('Phone Label', 'cryptech'),
            'default' => 'Call Us:',
        ),
        array(
            'id' => 'top_bar_phone',
            'type' => 'text',
            'title' => esc_html__('Phone', 'cryptech'),
            'default' => '002 01060070701',
        ),
        array(
            'id' => 'top_bar_address_label',
            'type' => 'text',
            'title' => esc_html__('Address Label', 'cryptech'),
            'default' => 'Visit Us:',
        ),
        array(
            'id' => 'top_bar_address',
            'type' => 'text',
            'title' => esc_html__('Adress', 'cryptech'),
            'default' => '22 Albahr St, Tanta, Egypt',
        ),
        array(
            'id' => 'top_bar_email_label',
            'type' => 'text',
            'title' => esc_html__('Email Label', 'cryptech'),
            'default' => 'Email Us:',
        ),
        array(
            'id' => 'top_bar_email',
            'type' => 'text',
            'title' => esc_html__('Email', 'cryptech'),
            'default' => 'Cryptech@7oroof.com',
        ),
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Logo', 'cryptech'),
    'icon'       => 'el el-picture',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'logo_light',
            'type'     => 'media',
            'title'    => esc_html__('Logo Light', 'cryptech'),
             'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-light.png'
            )
        ),
        array(
            'id'       => 'logo',
            'type'     => 'media',
            'title'    => esc_html__('Logo Dark', 'cryptech'),
             'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-dark.png'
            )
        ),
        array(
            'id'       => 'logo_mobile',
            'type'     => 'media',
            'title'    => esc_html__('Logo Mobile & Tablet', 'cryptech'),
             'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/logo-dark.png'
            )
        ),
        array(
            'id'       => 'logo_maxh',
            'type'     => 'dimensions',
            'title'    => esc_html__('Logo Max height', 'cryptech'),
            'subtitle' => esc_html__('Set maximum height for your logo, just in case the logo is too large.', 'cryptech'),
            'width'    => false,
            'unit'     => 'px'
        ),
        array(
            'title' => esc_html__('Favicon', 'cryptech'),
            'id' => 'favicon',
            'type' => 'media',
            'url' => false,
            'default' => array(
                'url'=>get_template_directory_uri().'/assets/images/favicon.png'
            )
        ),
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Navigation', 'cryptech'),
    'icon'       => 'el el-lines',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'          => 'font_menu',
            'type'        => 'typography',
            'title'       => esc_html__('Menu Font', 'cryptech'),
            'subtitle'    => esc_html__('Menu typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'font-style'  => false,
            'font-weight'  => false,
            'text-align'  => false,
            'font-size'  => false,
            'line-height'  => false,
            'font-color'  => false,
            'output'      => array('.main-navigation li a'),
            'units'       => 'px'
        ),
        array(
            'id'       => 'magic_line_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Magic Line Position', 'cryptech'),
            'options'  => array(
                'magic-line-bottom'  => esc_html__('Bottom', 'cryptech'),
                'magic-line-middle' => esc_html__('Middle', 'cryptech'),
            ),
            'default'  => 'magic-line-bottom',
            'required' => array(
                array('header_layout','!=','5'), 
            ),
            'force_output' => true
        ),
        array(
            'id'       => 'magic_line_color',
            'type'     => 'button_set',
            'title'    => esc_html__('Magic Line Color', 'cryptech'),
            'options'  => array(
                'magic-line-primary'  => esc_html__('Primary', 'cryptech'),
                'magic-line-dark'  => esc_html__('Dark', 'cryptech'),
                'magic-line-white' => esc_html__('White', 'cryptech'),
            ),
            'default'  => 'magic-line-primary',
            'required' => array(
                array('header_layout','!=','5'), 
            ),
            'force_output' => true
        ),
        array(
            'title' => esc_html__('Button Navigation', 'cryptech'),
            'type'  => 'section',
            'id' => 'button_navigation',
            'indent' => true
        ),
        array(
            'id'       => 'h_btn_on',
            'type'     => 'button_set',
            'title'    => esc_html__('Show/Hide Button', 'cryptech'),
            'options'  => array(
                'show'  => esc_html__('Show', 'cryptech'),
                'hide'  => esc_html__('Hide', 'cryptech')
            ),
            'default'  => 'show',
        ),
        array(
            'id' => 'h_btn_text',
            'type' => 'text',
            'title' => esc_html__('Button Text', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'h_btn_on', 1 => 'equals', 2 => 'show' ),
            'force_output' => true
        ),
        array(
            'id'       => 'h_btn_link_type',
            'type'     => 'button_set',
            'title'    => esc_html__('Butotn Link Type', 'cryptech'),
            'options'  => array(
                'page'  => esc_html__('Page', 'cryptech'),
                'custom'  => esc_html__('Custom', 'cryptech')
            ),
            'default'  => 'page',
        ),
        array(
            'id'    => 'h_btn_link',
            'type'  => 'select',
            'title' => esc_html__( 'Page Link', 'cryptech' ), 
            'data'  => 'page',
            'args'  => array(
                'post_type'      => 'page',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            ),
            'required' => array( 0 => 'h_btn_link_type', 1 => 'equals', 2 => 'page' ),
            'force_output' => true
        ),
        array(
            'id' => 'h_btn_link_custom',
            'type' => 'text',
            'title' => esc_html__('Custom Link', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'h_btn_link_type', 1 => 'equals', 2 => 'custom' ),
            'force_output' => true
        ),
        array(
            'id'       => 'h_btn_target',
            'type'     => 'button_set',
            'title'    => esc_html__('Button Target', 'cryptech'),
            'options'  => array(
                '_self'  => esc_html__('Self', 'cryptech'),
                '_blank'  => esc_html__('Blank', 'cryptech')
            ),
            'default'  => '_self',
            'required' => array( 0 => 'h_btn_on', 1 => 'equals', 2 => 'show' ),
            'force_output' => true
        ),
    )
));

/*--------------------------------------------------------------
# Page Title area
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title'  => esc_html__('Page Title', 'cryptech'),
    'icon'   => 'el-icon-map-marker',
    'fields' => array(
        array(
            'id'       => 'ptitle_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Layout', 'cryptech'),
            'subtitle' => esc_html__('Select a layout for page title.', 'cryptech'),
            'options'  => array(
                '1' => get_template_directory_uri() . '/assets/images/page-title-layout/p1.jpg',
            ),
            'default'  => '1'
        ),
        array(
            'id'       => 'ptitle_color',
            'type'     => 'color',
            'title'    => esc_html__('Title Color', 'cryptech'),
            'subtitle' => esc_html__('Page title color.', 'cryptech'),
            'output'   => array('#pagetitle h1.page-title'),
            'default'  => ''
        ),
        array(
            'id'       => 'ptitle_bg_color',
            'type'     => 'color_rgba',
            'title'    => esc_html__('Background Overlay', 'cryptech'),
            'subtitle' => esc_html__('Page title background color overlay', 'cryptech'),
            'output' => array('background-color' => '#pagetitle')
        ),
        array(
            'id'       => 'ptitle_bg',
            'type'     => 'background',
            'title'    => esc_html__('Background', 'cryptech'),
            'subtitle' => esc_html__('Page title background.', 'cryptech'),
            'output'   => array('#pagetitle'),
            'background-color'   => false,
        ),
        array(
            'id'       => 'ptitle_paddings',
            'type'     => 'spacing',
            'title'    => esc_html__('Paddings', 'cryptech'),
            'subtitle' => esc_html__('Page title paddings.', 'cryptech'),
            'mode'     => 'padding',
            'units'    => array('em', 'px', '%'),
            'top'      => true,
            'right'    => false,
            'bottom'   => true,
            'left'     => false,
            'output'   => array('#pagetitle'),
            'default'  => array(
                'top'    => '',
                'right'  => '',
                'bottom' => '',
                'left'   => '',
                'units'  => 'px',
            )
        ),
        array(
            'id'          => 'font_page_title',
            'type'        => 'typography',
            'title'       => esc_html__('Page Title Font', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'font-style'  => false,
            'font-weight'  => false,
            'text-align'  => false,
            'font-size'  => false,
            'line-height'  => false,
            'font-color'  => false,
            'color'  => false,
            'output'      => array('#pagetitle h1.page-title'),
            'units'       => 'px'
        ),
        array(
            'id'      => 'breadcrumb_on',
            'type'    => 'switch',
            'title'   => esc_html__('Breadcrumb', 'cryptech'),
            'default' => true
        ),
    )
));

/*--------------------------------------------------------------
# WordPress default content
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title' => esc_html__('Content', 'cryptech'),
    'icon'  => 'el-icon-pencil',
    'fields'     => array(
        array(
            'id'       => 'content_bg_color',
            'type'     => 'color_rgba',
            'title'    => esc_html__('Background Color', 'cryptech'),
            'subtitle' => esc_html__('Content background color.', 'cryptech'),
            'output' => array('background-color' => '#content')
        ),
        array(
            'id'             => 'content_padding',
            'type'           => 'spacing',
            'output'         => array('#content'),
            'right'   => false,
            'left'    => false,
            'mode'           => 'padding',
            'units'          => array('px'),
            'units_extended' => 'false',
            'title'          => esc_html__('Content Padding', 'cryptech'),
            'desc'           => esc_html__('Default: Top-90px, Bottom-90px', 'cryptech'),
            'default'            => array(
                'padding-top'   => '',  
                'padding-bottom'   => '',  
                'units'          => 'px', 
            )
        ),
    )
));


Redux::setSection($opt_name, array(
    'title'      => esc_html__('Archive', 'cryptech'),
    'icon'       => 'el-icon-list',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'archive_sidebar_pos',
            'type'     => 'button_set',
            'title'    => esc_html__('Sidebar Position', 'cryptech'),
            'subtitle' => esc_html__('Select a sidebar position for blog home, archive, search...', 'cryptech'),
            'options'  => array(
                'left'  => esc_html__('Left', 'cryptech'),
                'right' => esc_html__('Right', 'cryptech'),
                'none'  => esc_html__('Disabled', 'cryptech')
            ),
            'default'  => 'right'
        ),
        array(
            'id'       => 'archive_author_on',
            'title'    => esc_html__('Author', 'cryptech'),
            'subtitle' => esc_html__('Show author name on each post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true,
        ),
        array(
            'id'       => 'archive_date_on',
            'title'    => esc_html__('Date', 'cryptech'),
            'subtitle' => esc_html__('Show date posted on each post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true,
        ),
        array(
            'id'       => 'archive_categories_on',
            'title'    => esc_html__('Categories', 'cryptech'),
            'subtitle' => esc_html__('Show category names on each post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true,
        ),
        array(
            'id'       => 'archive_comments_on',
            'title'    => esc_html__('Comments', 'cryptech'),
            'subtitle' => esc_html__('Show comments count on each post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false,
        )
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Single Blog', 'cryptech'),
    'icon'       => 'el-icon-file-edit',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'post_sidebar_pos',
            'type'     => 'button_set',
            'title'    => esc_html__('Sidebar Position', 'cryptech'),
            'subtitle' => esc_html__('Select a sidebar position', 'cryptech'),
            'options'  => array(
                'left'  => esc_html__('Left', 'cryptech'),
                'right' => esc_html__('Right', 'cryptech'),
                'none'  => esc_html__('Disabled', 'cryptech')
            ),
            'default'  => 'right'
        ),
        array(
            'id'       => 'post_author_on',
            'title'    => esc_html__('Author', 'cryptech'),
            'subtitle' => esc_html__('Show author name on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true
        ),
        array(
            'id'       => 'post_date_on',
            'title'    => esc_html__('Date', 'cryptech'),
            'subtitle' => esc_html__('Show date on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true
        ),
        array(
            'id'       => 'post_categories_on',
            'title'    => esc_html__('Categories', 'cryptech'),
            'subtitle' => esc_html__('Show category names on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true
        ),
        array(
            'id'       => 'post_tags_on',
            'title'    => esc_html__('Tags', 'cryptech'),
            'subtitle' => esc_html__('Show tag names on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true
        ),
        array(
            'id'       => 'post_comments_on',
            'title'    => esc_html__('Comments', 'cryptech'),
            'subtitle' => esc_html__('Show comments count on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false
        ),
        array(
            'id'       => 'post_author_info_on',
            'title'    => esc_html__('Author Info', 'cryptech'),
            'subtitle' => esc_html__('Show author info on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false
        ),
        array(
            'id'       => 'post_navigation_link_on',
            'title'    => esc_html__('Navigation Links', 'cryptech'),
            'subtitle' => esc_html__('Show navigation link info on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false
        ),
        array(
            'id'       => 'post_comments_form_on',
            'title'    => esc_html__('Comments Form', 'cryptech'),
            'subtitle' => esc_html__('Show comments form on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => true
        ),
        array(
            'id'       => 'post_social_share_on',
            'title'    => esc_html__('Social Share', 'cryptech'),
            'subtitle' => esc_html__('Show social share on single post.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false
        )
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Single Case', 'cryptech'),
    'icon'       => 'el el-folder-open',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'case_sidebar_pos',
            'type'     => 'button_set',
            'title'    => esc_html__('Sidebar Position', 'cryptech'),
            'subtitle' => esc_html__('Select a sidebar position', 'cryptech'),
            'options'  => array(
                'left'  => esc_html__('Left', 'cryptech'),
                'right' => esc_html__('Right', 'cryptech'),
                'none'  => esc_html__('Disabled', 'cryptech')
            ),
            'default'  => 'left'
        ),
        array(
            'id'       => 'case_feature_image',
            'type'     => 'button_set',
            'title'    => esc_html__('Feature Image', 'cryptech'),
            'subtitle' => esc_html__('Show/Hide feature image on single case.', 'cryptech'),
            'options'  => array(
                'show'  => esc_html__('Show', 'cryptech'),
                'hide' => esc_html__('Hide', 'cryptech'),
            ),
            'default'  => 'hide'
        ),
        array(
            'id'       => 'case_cta',
            'title'    => esc_html__('Call To Action', 'cryptech'),
            'subtitle' => esc_html__('Show call to action on single case.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false
        ),
        array(
            'id'      => 'case_cta_desc',
            'type'    => 'text',
            'title'   => esc_html__('Content', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'service_cta', 1 => 'equals', 2 => '1' ),
            'force_output' => true
        ),
        array(
            'id'      => 'case_cta_btn_text',
            'type'    => 'text',
            'title'   => esc_html__('Button Text', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'case_cta', 1 => 'equals', 2 => '1' ),
            'force_output' => true
        ),
        array(
            'id'    => 'case_cta_btn_link',
            'type'  => 'select',
            'title' => esc_html__( 'Button Link', 'cryptech' ), 
            'data'  => 'page',
            'args'  => array(
                'post_type'      => 'page',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            ),
            'required' => array( 0 => 'case_cta', 1 => 'equals', 2 => '1' ),
            'force_output' => true
        ),
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Single Service', 'cryptech'),
    'icon'       => 'el el-wrench',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'service_sidebar_pos',
            'type'     => 'button_set',
            'title'    => esc_html__('Sidebar Position', 'cryptech'),
            'subtitle' => esc_html__('Select a sidebar position', 'cryptech'),
            'options'  => array(
                'left'  => esc_html__('Left', 'cryptech'),
                'right' => esc_html__('Right', 'cryptech'),
                'none'  => esc_html__('Disabled', 'cryptech')
            ),
            'default'  => 'left'
        ),
        array(
            'id'       => 'service_feature_image',
            'type'     => 'button_set',
            'title'    => esc_html__('Feature Image', 'cryptech'),
            'subtitle' => esc_html__('Show/Hide feature image on single service.', 'cryptech'),
            'options'  => array(
                'show'  => esc_html__('Show', 'cryptech'),
                'hide' => esc_html__('Hide', 'cryptech'),
            ),
            'default'  => 'hide'
        ),
        array(
            'id'       => 'service_cta',
            'title'    => esc_html__('Call To Action', 'cryptech'),
            'subtitle' => esc_html__('Show call to action on single service.', 'cryptech'),
            'type'     => 'switch',
            'default'  => false
        ),
        array(
            'id'      => 'service_cta_desc',
            'type'    => 'text',
            'title'   => esc_html__('Content', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'service_cta', 1 => 'equals', 2 => '1' ),
            'force_output' => true
        ),
        array(
            'id'      => 'service_cta_btn_text',
            'type'    => 'text',
            'title'   => esc_html__('Button Text', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'service_cta', 1 => 'equals', 2 => '1' ),
            'force_output' => true
        ),
        array(
            'id'    => 'service_cta_btn_link',
            'type'  => 'select',
            'title' => esc_html__( 'Button Link', 'cryptech' ), 
            'data'  => 'page',
            'args'  => array(
                'post_type'      => 'page',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC',
            ),
            'required' => array( 0 => 'service_cta', 1 => 'equals', 2 => '1' ),
            'force_output' => true
        ),
    )
));


/*--------------------------------------------------------------
# Shop
--------------------------------------------------------------*/
if(class_exists('Woocommerce')) {
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('Shop', 'cryptech'),
        'icon'   => 'el el-shopping-cart',
        'fields' => array(
            array(
                'id'       => 'sidebar_shop',
                'type'     => 'button_set',
                'title'    => esc_html__('Sidebar Position', 'cryptech'),
                'subtitle' => esc_html__('Select a sidebar position for shop', 'cryptech'),
                'options'  => array(
                    'left'  => esc_html__('Left', 'cryptech'),
                    'right' => esc_html__('Right', 'cryptech'),
                    'none'  => esc_html__('Disabled', 'cryptech')
                ),
                'default'  => 'right'
            ),
            array(
                'title' => esc_html__('Products displayed per page', 'cryptech'),
                'id' => 'product_per_page',
                'type' => 'slider',
                'subtitle' => esc_html__('Number product to show', 'cryptech'),
                'default' => 6,
                'min'  => 6,
                'step' => 1,
                'max' => 50,
                'display_value' => 'text'
            ),
            array(
                'title' => esc_html__('Page Title', 'cryptech'),
                'type'  => 'section',
                'id' => 'shop_page_title',
                'indent' => true
            ),
            array(
                'id'       => 'shop_page_title_bg',
                'type'     => 'background',
                'title'    => esc_html__('Background', 'cryptech'),
                'subtitle' => esc_html__('Page title background.', 'cryptech'),
                'output'   => array('.woocommerce #pagetitle, .woocommerce-page #pagetitle'),
                'background-color'   => false,
            ),
        )
    ));
}


/*--------------------------------------------------------------
# Colors
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title'  => esc_html__('Colors', 'cryptech'),
    'icon'   => 'el-icon-file-edit',
    'fields' => array(
        array(
            'id'          => 'primary_color',
            'type'        => 'color',
            'title'       => esc_html__('Primary Color', 'cryptech'),
            'transparent' => false,
            'default'     => '#fdb350'
        ),
        array(
            'id'          => 'secondary_color',
            'type'        => 'color',
            'title'       => esc_html__('Secondary Color', 'cryptech'),
            'transparent' => false,
            'default'     => '#f9a33a'
        ),
        array(
            'id'      => 'link_color',
            'type'    => 'link_color',
            'title'   => __('Link Colors', 'cryptech'),
            'default' => array(
                'regular' => '#ffb400',
                'hover'   => '#fbad48',
                'active'  => '#fbad48'
            ),
            'output'  => array('a')
        )
    )
));

/*--------------------------------------------------------------
# Typography
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title'  => esc_html__('Typography', 'cryptech'),
    'icon'   => 'el-icon-text-width',
    'fields' => array(
        array(
            'id'          => 'font_main',
            'type'        => 'typography',
            'title'       => esc_html__('Main Font', 'cryptech'),
            'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('body'),
            'units'       => 'px'
        ),
        array(
            'id'          => 'font_h1',
            'type'        => 'typography',
            'title'       => esc_html__('H1', 'cryptech'),
            'subtitle'    => esc_html__('Heading 1 typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('h1', '.h1'),
            'units'       => 'px'
        ),
        array(
            'id'          => 'font_h2',
            'type'        => 'typography',
            'title'       => esc_html__('H2', 'cryptech'),
            'subtitle'    => esc_html__('Heading 2 typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('h2', '.h2'),
            'units'       => 'px'
        ),
        array(
            'id'          => 'font_h3',
            'type'        => 'typography',
            'title'       => esc_html__('H3', 'cryptech'),
            'subtitle'    => esc_html__('Heading 3 typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('h3', '.h3'),
            'units'       => 'px'
        ),
        array(
            'id'          => 'font_h4',
            'type'        => 'typography',
            'title'       => esc_html__('H4', 'cryptech'),
            'subtitle'    => esc_html__('Heading 4 typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('h4', '.h4'),
            'units'       => 'px'
        ),
        array(
            'id'          => 'font_h5',
            'type'        => 'typography',
            'title'       => esc_html__('H5', 'cryptech'),
            'subtitle'    => esc_html__('Heading 5 typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('h5', '.h5'),
            'units'       => 'px'
        ),
        array(
            'id'          => 'font_h6',
            'type'        => 'typography',
            'title'       => esc_html__('H6', 'cryptech'),
            'subtitle'    => esc_html__('Heading 6 typography.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => array('h6', '.h6'),
            'units'       => 'px'
        )
    )
));

$custom_font_selectors_1 = Redux::getOption($opt_name, 'custom_font_selectors_1');
$custom_font_selectors_1 = !empty($custom_font_selectors_1) ? explode(',', $custom_font_selectors_1) : array();

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Extra Fonts', 'cryptech'),
    'icon'       => 'el el-fontsize',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'          => 'custom_font_1',
            'type'        => 'typography',
            'title'       => esc_html__('Custom Font', 'cryptech'),
            'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'cryptech'),
            'google'      => true,
            'font-backup' => true,
            'all_styles'  => true,
            'output'      => $custom_font_selectors_1,
            'units'       => 'px',

        ),
        array(
            'id'       => 'custom_font_selectors_1',
            'type'     => 'textarea',
            'title'    => esc_html__('CSS Selectors', 'cryptech'),
            'subtitle' => esc_html__('Add css selectors to apply above font.', 'cryptech'),
            'validate' => 'no_html'
        )
    )
));


/*--------------------------------------------------------------
# Footer
--------------------------------------------------------------*/

Redux::setSection($opt_name, array(
    'title'  => esc_html__('Footer', 'cryptech'),
    'icon'   => 'el el-website',
    'fields' => array(
        array(
            'id'       => 'footer_layout',
            'type'     => 'image_select',
            'title'    => esc_html__('Layout', 'cryptech'),
            'subtitle' => esc_html__('Select a layout for upper footer area.', 'cryptech'),
            'options'  => array(
                '1' => get_template_directory_uri() . '/assets/images/footer-layout/f1.jpg',
            ),
            'default'  => '1'
        ),
        array(
            'id'       => 'footer_bg_color',
            'type'     => 'color_rgba',
            'title'    => esc_html__('Background Color Overlay', 'cryptech'),
            'subtitle' => esc_html__('Footer background color overlay', 'cryptech'),
            'output' => array('background-color' => '.site-footer:before')
        ),
        array(
            'id'       => 'footer_bg',
            'type'     => 'background',
            'title'    => esc_html__('Background', 'cryptech'),
            'subtitle' => esc_html__('Footer background.', 'cryptech'),
            'default'  => '',
            'output'   => array('.site-footer'),
        ),
        array(
            'id'       => 'back_totop_on',
            'type'     => 'switch',
            'title'    => esc_html__('Back to Top Button', 'cryptech'),
            'subtitle' => esc_html__('Show back to top button when scrolled down.', 'cryptech'),
            'default'  => true
        ),
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Footer Top', 'cryptech'),
    'icon'       => 'el el-circle-arrow-right',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'footer_top_column',
            'type'     => 'button_set',
            'title'    => esc_html__('Columns', 'cryptech'),
            'options'  => array(
                '2'  => esc_html__('2 Column', 'cryptech'),
                '3'  => esc_html__('3 Column', 'cryptech'),
                '4'  => esc_html__('4 Column', 'cryptech'),
                '5'  => esc_html__('5 Column', 'cryptech'),
            ),
            'default'  => '5',
        ),
        array(
            'id'       => 'footer_top_paddings',
            'type'     => 'spacing',
            'title'    => esc_html__('Paddings', 'cryptech'),
            'subtitle' => esc_html__('Footer top paddings.', 'cryptech'),
            'mode'     => 'padding',
            'units'    => array('px'),
            'right'    => false,
            'left'     => false,
            'default'  => array(
                'padding-top'    => '',
                'padding-bottom' => ''
            ),
            'output'   => array('.top-footer')
        ),
        array(
            'id'    => 'footer_top_heading_color',
            'type'  => 'color',
            'title' => esc_html__('Widget Title Color', 'cryptech'),
            'output'   => array('.top-footer .footer-widget-title')
        ),
        array(
            'id'    => 'footer_top_color',
            'type'  => 'color',
            'title' => esc_html__('Text Color', 'cryptech'),
            'output'   => array('.top-footer')
        ),
        array(
            'id'      => 'footer_top_link_color',
            'type'    => 'link_color',
            'title'   => esc_html__('Links Color', 'cryptech'),
            'regular' => true,
            'hover'   => true,
            'active'  => true,
            'visited' => true,
            'output'  => array('.top-footer a'),
        ),
        array(
            'title' => esc_html__('Apps', 'cryptech'),
            'type'  => 'section',
            'id' => 'apps',
            'indent' => true
        ),
        array(
            'id'       => 'app_footer',
            'type'     => 'switch',
            'title'    => esc_html__('Apps', 'cryptech'),
            'default'  => false
        ),
        array(
            'id'      => 'app_title',
            'type'    => 'text',
            'title'   => esc_html__('Title', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'app_footer', 1 => 'equals', 2 => '1' ),
        ),
        array(
            'id'      => 'app_description',
            'type'    => 'text',
            'title'   => esc_html__('Description', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'app_footer', 1 => 'equals', 2 => '1' ),
        ),
        array(
            'id'       => 'app_store',
            'type'     => 'switch',
            'title'    => esc_html__('App Store', 'cryptech'),
            'default'  => true,
            'required' => array( 0 => 'app_footer', 1 => 'equals', 2 => '1' ),
        ),
        array(
            'id'      => 'app_store_link',
            'type'    => 'text',
            'title'   => esc_html__('App Store Link', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'app_store', 1 => 'equals', 2 => '1' ),
        ),
        array(
            'id'       => 'google_play',
            'type'     => 'switch',
            'title'    => esc_html__('Google Play', 'cryptech'),
            'default'  => true,
            'required' => array( 0 => 'app_footer', 1 => 'equals', 2 => '1' ),
        ),
        array(
            'id'      => 'google_play_link',
            'type'    => 'text',
            'title'   => esc_html__('Google Play Link', 'cryptech'),
            'default' => '',
            'required' => array( 0 => 'google_play', 1 => 'equals', 2 => '1' ),
        ),
    )
));

Redux::setSection($opt_name, array(
    'title'      => esc_html__('Footer Bottom', 'cryptech'),
    'icon'       => 'el el-circle-arrow-right',
    'subsection' => true,
    'fields'     => array(
        array(
            'title' => esc_html__('Logo Payment', 'cryptech'),
            'type'  => 'slides',
            'id' => 'logo_payment',
        ),
    )
));

/* Social Media */
Redux::setSection($opt_name, array(
    'title'      => esc_html__('Social Media', 'cryptech'),
    'icon'       => 'el el-twitter',
    'subsection' => false,
    'fields'     => array(
        array(
            'id'      => 'social_facebook_url',
            'type'    => 'text',
            'title'   => esc_html__('Facebook URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_twitter_url',
            'type'    => 'text',
            'title'   => esc_html__('Twitter URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_inkedin_url',
            'type'    => 'text',
            'title'   => esc_html__('Inkedin URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_rss_url',
            'type'    => 'text',
            'title'   => esc_html__('Rss URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_instagram_url',
            'type'    => 'text',
            'title'   => esc_html__('Instagram URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_google_url',
            'type'    => 'text',
            'title'   => esc_html__('Google URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_skype_url',
            'type'    => 'text',
            'title'   => esc_html__('Skype URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_pinterest_url',
            'type'    => 'text',
            'title'   => esc_html__('Pinterest URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_vimeo_url',
            'type'    => 'text',
            'title'   => esc_html__('Vimeo URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_youtube_url',
            'type'    => 'text',
            'title'   => esc_html__('Youtube URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_yelp_url',
            'type'    => 'text',
            'title'   => esc_html__('Yelp URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_tumblr_url',
            'type'    => 'text',
            'title'   => esc_html__('Tumblr URL', 'cryptech'),
            'default' => '',
        ),
        array(
            'id'      => 'social_tripadvisor_url',
            'type'    => 'text',
            'title'   => esc_html__('Tripadvisor URL', 'cryptech'),
            'default' => '',
        ),
    )
));

/* Custom Code /--------------------------------------------------------- */
Redux::setSection($opt_name, array(
    'title'  => esc_html__('Custom Code', 'cryptech'),
    'icon'   => 'el-icon-edit',
    'fields' => array(

        array(
            'id'       => 'site_header_code',
            'type'     => 'textarea',
            'theme'    => 'chrome',
            'title'    => esc_html__('Header Custom Codes', 'cryptech'),
            'subtitle' => esc_html__('It will insert the code to wp_head hook.', 'cryptech'),
        ),
        array(
            'id'       => 'site_footer_code',
            'type'     => 'textarea',
            'theme'    => 'chrome',
            'title'    => esc_html__('Footer Custom Codes', 'cryptech'),
            'subtitle' => esc_html__('It will insert the code to wp_footer hook.', 'cryptech'),
        ),

    ),
));

/* Custom CSS /--------------------------------------------------------- */
Redux::setSection($opt_name, array(
    'title'  => esc_html__('Custom CSS', 'cryptech'),
    'icon'   => 'el-icon-adjust-alt',
    'fields' => array(

        array(
            'id'   => 'customcss',
            'type' => 'info',
            'desc' => esc_html__('Custom CSS', 'cryptech')
        ),

        array(
            'id'       => 'site_css',
            'type'     => 'ace_editor',
            'title'    => esc_html__('CSS Code', 'cryptech'),
            'subtitle' => esc_html__('Advanced CSS Options. You can paste your custom CSS Code here.', 'cryptech'),
            'mode'     => 'css',
            'validate' => 'css',
            'theme'    => 'chrome',
            'default'  => ""
        ),

    ),
));