<?php

/* Remove result count & product ordering & item product category..... */
add_action( 'init', 'cryptech_woocommerce_remove_function' );
function cryptech_woocommerce_remove_function() {
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10, 0 );

	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5, 0 );
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10, 0 );
	remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10, 0 );
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10, 0 );

    remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20, 0 );
    remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30, 0 );

    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10, 0 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10, 0 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40, 0 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20, 0 );

    remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10, 0 );
}

/* Ajax update cart total number */
add_filter( 'woocommerce_add_to_cart_fragments', 'cryptech_woocommerce_header_add_to_cart_fragment' );
function cryptech_woocommerce_header_add_to_cart_fragment( $fragments ) {
	ob_start();
	?>
	<span class="couter_items"><?php echo sprintf (_n( '%d', '%d', WC()->cart->cart_contents_count, 'cryptech' ), WC()->cart->cart_contents_count ); ?></span>
	<?php
	
	$fragments['span.couter_items'] = ob_get_clean();
	
	return $fragments;
}

/* Ajax update cart item */
add_filter('woocommerce_add_to_cart_fragments', 'cryptech_woo_mini_cart_item_fragment');
function cryptech_woo_mini_cart_item_fragment( $fragments ) {
	global $woocommerce;
    ob_start();
    ?>
    <div class="widget_shopping_cart">
        <div class="widget_shopping_cart_content">
            <?php
            	$cart_is_empty = sizeof( $woocommerce->cart->get_cart() ) <= 0;
            ?>
            <ul class="cart_list product_list_widget">

			<?php if ( ! WC()->cart->is_empty() ) : ?>

				<?php
					foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
						$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
						$product_id   = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

						if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {

							$product_name  = apply_filters( 'woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key );
							$thumbnail     = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
							$product_price = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
							?>
							<li>
								<div class="cart-product-image">
									<a href="<?php echo esc_url( $_product->get_permalink( $cart_item ) ); ?>">
										<?php echo str_replace( array( 'http:', 'https:' ), '', $thumbnail ); ?>
									</a>
								</div>
								<div class="cart-product-meta">
									<h3><a href="<?php echo esc_url( $_product->get_permalink( $cart_item ) ); ?>"><?php echo esc_html($product_name); ?></a></h3>
									<?php echo apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="quantity">' . sprintf( '%s &times; %s', $cart_item['quantity'], $product_price ) . '</span>', $cart_item, $cart_item_key ); ?>
								</div>	
							</li>
							<?php
						}
					}
				?>

				<?php else : ?>

					<li class="empty"><?php esc_html_e( 'No products in the cart.', 'cryptech' ); ?></li>

				<?php endif; ?>

			</ul><!-- end product list -->
			<?php if ( ! WC()->cart->is_empty() ) : ?>

				<p class="total"><strong><?php esc_html_e( 'Subtotal', 'cryptech' ); ?>:</strong> <?php echo WC()->cart->get_cart_subtotal(); ?></p>

				<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>

				<p class="buttons clearfix">
					<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="button wc-forward"><?php esc_html_e( 'View Cart', 'cryptech' ); ?></a>
					<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="button checkout wc-forward"><?php esc_html_e( 'Checkout', 'cryptech' ); ?></a>
				</p>

			<?php endif; ?>
        </div>
    </div>
    <?php
    $fragments['div.widget_shopping_cart'] = ob_get_clean();
    return $fragments;
}

add_action( 'woocommerce_archive_description', 'cryptech_woocommerce_category_image', 2 );
function cryptech_woocommerce_category_image() {
	global $post, $product;
	
    if ( is_product_category() ){
	    global $wp_query;
	    $cat = $wp_query->get_queried_object();
	    $thumbnail_id = get_woocommerce_term_meta( $cat->term_id, 'thumbnail_id', true );
	    $image = wp_get_attachment_url( $thumbnail_id );
	    if ( $image ) { ?>
		    <div class="woocommerce-image-categries">
		    	<img src="<?php echo esc_url($image); ?>" />
		    	<?php 
		    		$description = wc_format_content( term_description() );
					if ( $description ) { ?>
					<div class="woocommerce-term-description">
						<?php echo wp_kses_post($description); ?>
					</div>
				<?php } ?>
		    </div>
		<?php }
	}
}

/* Show product per page */
function cryptech_loop_shop_per_page(){
	$product_per_page = cryptech_get_opt( 'product_per_page', '12' );

	if(isset($_REQUEST['loop_shop_per_page']) && !empty($_REQUEST['loop_shop_per_page'])) {
		return $_REQUEST['loop_shop_per_page'];
	} else {
		return $product_per_page;
	}
}
add_filter( 'loop_shop_per_page', 'cryptech_loop_shop_per_page' );

/* Add result count & product ordering */
add_action( 'woocommerce_before_shop_loop', 'cryptech_woocommerce_result_ordering', 2 );
function cryptech_woocommerce_result_ordering() { 
	global $post, $product; ?>
	<div class="woocommerce-meta clearfix">
		<div class="woocommerce-meta-ordering float-left cms-select"><label><?php echo esc_html__('Sort by:', 'cryptech')?></label><?php woocommerce_catalog_ordering(); ?></div>
		<div class="woocommerce-meta-result float-right"><?php woocommerce_result_count(); ?></div>
	</div>
<?php }

add_filter( 'woocommerce_product_add_to_cart_text', 'cryptech_custom_cart_button_text' );
function cryptech_custom_cart_button_text() {
    return esc_html__( 'Add to Cart', 'cryptech' );
 
}

add_filter( 'woocommerce_product_single_add_to_cart_text', 'cryptech_custom_cart_button_text_single' );
function cryptech_custom_cart_button_text_single() {
    return esc_html__( 'Add to Cart', 'cryptech' );
 
}

/* Change Breadcrumb Delimiter */
add_filter( 'woocommerce_breadcrumb_defaults', 'cryptech_change_breadcrumb_delimiter' );
function cryptech_change_breadcrumb_delimiter( $defaults ) {
	$defaults['delimiter'] = ' <i class="zmdi zmdi-chevron-right"></i> ';
	return $defaults;
}

/* Related Products */
function cryptech_related_text( $translated_text, $text, $domain ) {
    switch ( $translated_text ) {
        case 'Related products' :
            $translated_text = esc_html__( 'Your Recently Viewed', 'cryptech' );
            break;
    }
    return $translated_text;
}
add_filter( 'gettext', 'cryptech_related_text', 20, 3 );

/* Product Category */
add_filter( 'woocommerce_after_shop_loop_item', 'cryptech_woocommerce_product' );
function cryptech_woocommerce_product() { ?>
	<div class="woocommerce-product-inner">
		<div class="woocommerce-product-header">
			<a href="<?php the_permalink(); ?>" ><?php woocommerce_template_loop_product_thumbnail(); ?></a>
			<div class="woocommerce-add-to-cart">
		    	<?php woocommerce_template_loop_add_to_cart(); ?>
			</div>
		</div>
		<div class="woocommerce-product-holder">
			<?php woocommerce_template_loop_price(); ?>
			<h3 class="woocommerce-product-title title-link h-main">
				<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
			</h3>
		</div>
	</div>
<?php }

/* Product Single: */
add_filter( 'woocommerce_single_product_summary', 'cryptech_woocommerce_single_summer', 15 );
function cryptech_woocommerce_single_summer() { 
	global $product, $woocommerce; ?>
	<div class="woocommerce-summer-inner">
		<div class="woocommerce-summer-meta clearfix">
			<?php woocommerce_template_single_price(); ?>
			<?php woocommerce_template_single_rating(); ?>
		</div>
		<div class="woocommerce-short-description">
			<?php woocommerce_template_single_excerpt(); ?>
		</div>
	</div>
	
<?php }


/**
 * Add: Pagination for Single product
 */
add_filter( 'woocommerce_after_single_product_summary', 'cryptech_pagination_single_product', 12 );
function cryptech_pagination_single_product( $args ) { ?>
	<div class="woocommerce-pagination">
	    <ul class="page-numbers">
	        <?php previous_post_link( '<li class="nav-previous">%link</li>', '<span class="page-numbers"><i class="fa  fa-long-arrow-left"></i></span>' ); ?>
	        <?php next_post_link(     '<li class="nav-next">%link</li>',     '<span class="page-numbers"><i class="fa  fa-long-arrow-right"></i></span>' ); ?>
	    </ul>
	</div>
<?php }

/**
 * Related: Custom post per page
 */
add_filter( 'woocommerce_output_related_products_args', 'cryptech_related_products_args' );
  function cryptech_related_products_args( $args ) {
	$args['posts_per_page'] = 3;
	$args['columns'] = 3;
	return $args;
}

/**
 * WooCommerce Product image Sizes
 */
function cryptech_add_size_woocommerce_support() {
    add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 870,
        'thumbnail_image_height' => 870,
        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 4,
            'min_columns'     => 2,
            'max_columns'     => 5,
        ),
    ) );
}
add_action( 'after_setup_theme', 'cryptech_add_size_woocommerce_support' );

add_filter('woocommerce_get_image_size_single', function ($size) {
    $size['width'] = 870;
    $size['height'] = 549;
    $size['crop'] = 1;
    return $size;
});

/**
 * WooCommerce Product Single - Social Share
 */
add_filter( 'woocommerce_after_single_product_summary', 'cryptech_social_share_single_product', 5 );
function cryptech_social_share_single_product( $args ) { ?>
	<div class="woocommerce-product-share">
		<h3 class="widget-title"><?php echo esc_html__('Share Product:', 'cryptech');?></h3>
		<div class="share-social-list">
	        <a class="fb-social" title="Facebook" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="zmdi zmdi-facebook"></i></a>
	        <a class="tw-social" title="Twitter" target="_blank" href="https://twitter.com/home?status=<?php the_permalink(); ?>"><i class="zmdi zmdi-twitter"></i></a>
	        <a class="g-social" title="Google Plus" target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class="zmdi zmdi-google-plus"></i></a>
	        <a class="in-social" title="LinkedIn" target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>&summary=&source="><i class="zmdi zmdi-linkedin"></i></a>
	        <a class="pin-social" title="Pinterest" target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php echo esc_url(the_post_thumbnail_url( 'full' )); ?>&media=&description=<?php the_title(); ?>"><i class="zmdi zmdi-pinterest"></i></a>
	    </div>
	</div>
<?php }