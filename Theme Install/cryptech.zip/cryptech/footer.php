<?php
/**
 * The template for displaying the footer.
 * Contains the closing of the #content div and all content after.
 *
 * @package Cryptech
 */
?>

</div><!-- #content -->

<?php cryptech_footer(); ?>

<?php cryptech_search_popup(); ?>

<?php cryptech_login_register(); ?>

<?php if (cryptech_get_opt('back_totop_on', true)) : ?>
    <a href="#" class="scroll-top"><i class="zmdi zmdi-long-arrow-up"></i></a>
<?php endif; ?>
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>
