<?php
class CMS_TextBox_Widget extends WP_Widget {

    function __construct() {
        parent::__construct(
            'cms_textbox_widget',
            esc_html__('CMS Text Box', 'cryptech'),
            array('description' => esc_html__('Text Box Widget', 'cryptech'),)
        );
    }

    function widget($args, $instance) {
        global $woocommerce;

        extract($args);

        $title = isset($instance['title']) ? (!empty($instance['title']) ? $instance['title']: '') : '';
        $content = isset($instance['content']) ? (!empty($instance['content']) ? $instance['content']: '') : '';
        $button_text = isset($instance['button_text']) ? (!empty($instance['button_text']) ? $instance['button_text']: '') : '';
        $button_link = isset($instance['button_link']) ? (!empty($instance['button_link']) ? $instance['button_link']: '') : '';
        ?>

        <?php if(!empty($title)) : ?>
            <div class="cms-textbox widget">
                <div class="cms-textbox-inner clearfix">
                    <div class="cms-textbox-content">
                        <h3 class="cms-textbox-title title-medium"><?php echo esc_attr( $title ); ?></h3>
                        <div class="cms-textbox-description"><?php echo esc_attr( $content ); ?></div>
                        <div class="cms-textbox-readmore">
                            <a class="btn btn-round" href="<?php echo esc_url($button_link); ?>"><?php echo esc_attr( $button_text ); ?></a>
                        </div>
                    </div>
                </div>
            </div>
    <?php endif; }

    function update( $new_instance, $old_instance ) {
         $instance = $old_instance;
         $instance['title'] = strip_tags($new_instance['title']);
         $instance['content'] = strip_tags($new_instance['content']);
         $instance['button_text'] = strip_tags($new_instance['button_text']);
         $instance['button_link'] = strip_tags($new_instance['button_link']);

         return $instance;
    }

    function form( $instance ) {

         wp_enqueue_style('wp-color-picker');
         wp_enqueue_script('wp-color-picker');
         $title = isset($instance['title']) ? esc_attr($instance['title']) : '';
         $content = isset($instance['content']) ? esc_attr($instance['content']) : '';
         $button_text = isset($instance['button_text']) ? esc_attr($instance['button_text']) : '';
         $button_link = isset($instance['button_link']) ? esc_attr($instance['button_link']) : '';

         ?>
         <p><label for="<?php echo esc_url($this->get_field_id('title')); ?>"><?php esc_html_e( 'Title', 'cryptech' ); ?></label>
         <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></p>

         <p><label for="<?php echo esc_url($this->get_field_id('content')); ?>"><?php esc_html_e( 'Content', 'cryptech' ); ?></label>
         <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('content') ); ?>" name="<?php echo esc_attr( $this->get_field_name('content') ); ?>" type="text" value="<?php echo esc_attr( $content ); ?>" /></p>

         <p><label for="<?php echo esc_url($this->get_field_id('Button Text')); ?>"><?php esc_html_e( 'Button Text', 'cryptech' ); ?></label>
         <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('button_text') ); ?>" name="<?php echo esc_attr( $this->get_field_name('button_text') ); ?>" type="text" value="<?php echo esc_attr( $button_text ); ?>" /></p>

         <p><label for="<?php echo esc_url($this->get_field_id('Button Link')); ?>"><?php esc_html_e( 'Button Link', 'cryptech' ); ?></label>
         <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('button_link') ); ?>" name="<?php echo esc_attr( $this->get_field_name('button_link') ); ?>" type="text" value="<?php echo esc_attr( $button_link ); ?>" /></p>

         </p>
    <?php
    }

}

function register_textbox_widget() {
    register_widget('CMS_TextBox_Widget');
}
add_action('widgets_init', 'register_textbox_widget'); ?>