<?php
/**
 * Custom Woocommerce shop page.
 */
get_header();
if( (class_exists( 'WooCommerce' ) && is_shop()) || (class_exists( 'WooCommerce' ) && is_product_category()) || (class_exists( 'WooCommerce' ) && is_singular('product')) ) {
    $sidebar_pos = cryptech_get_opt( 'sidebar_shop', 'right' );
} else {
    $sidebar_pos = 'none';
}
?>
    <div class="container content-container">
        <div class="row content-row">
            <div id="primary" <?php cryptech_primary_class( $sidebar_pos, 'content-area content-woo' ); ?>>
                <main id="main" class="site-main" role="main">
                        <?php woocommerce_content(); ?>
                </main><!-- #main -->
            </div><!-- #primary -->

            <?php if ( 'left' == $sidebar_pos || 'right' == $sidebar_pos ) : ?>
                <aside id="secondary"<?php cryptech_secondary_class( $sidebar_pos, 'widget-area' ); ?>>
                    <?php dynamic_sidebar( 'sidebar-shop' ); ?>
                </aside>
            <?php endif; ?>
        </div>
    </div>
<?php
get_footer();