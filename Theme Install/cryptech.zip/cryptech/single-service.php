<?php
/**
 * The template for displaying all single service
 *
 * @package Cryptech
 */

get_header();
$sidebar_pos = '';
$sidebar_pos = cryptech_get_opt( 'service_sidebar_pos', 'left' );
$service_cta = cryptech_get_opt( 'service_cta', false );
$service_cta_desc = cryptech_get_opt( 'service_cta_desc' );
$service_cta_btn_text = cryptech_get_opt( 'service_cta_btn_text' );
$service_cta_btn_link = cryptech_get_opt( 'service_cta_btn_link' );
$service_feature_image = cryptech_get_opt( 'service_feature_image' );
?>
<div class="container content-container">
    <div class="row content-row">
        <div id="primary" <?php cryptech_primary_class( $sidebar_pos, 'content-area' ); ?>>
            <main id="main" class="site-main">
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php if (has_post_thumbnail() && $service_feature_image == 'show') : ?>
                        <div class="single-service-media">
                            <?php the_post_thumbnail('full'); ?>
                        </div>
                    <?php endif; ?>
                    <div class="single-service-content">
                        <?php the_content(); ?>
                    </div>
                <?php endwhile; ?>
            </main><!-- #main -->
        </div><!-- #primary -->

        <?php if ( 'left' == $sidebar_pos || 'right' == $sidebar_pos ) : ?>
        <aside id="secondary" <?php cryptech_secondary_class( $sidebar_pos, 'widget-area' ); ?>>
            <?php dynamic_sidebar( 'sidebar-services' ); ?>
        </aside>
        <?php endif; ?>
    </div>
</div>
<?php if($service_cta && !empty($service_cta_desc)) : ?>
    <div class="single-service-cta">
        <div class="single-cta-inner bg-gradient">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                        <h3 class="cms-heading-tag align-left align-left-md align-center-sm align-center-xs "><?php echo esc_attr( $service_cta_desc ); ?></h3>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="cms-button-wrapper btn-align-right  btn-align-right-md btn-align-center-sm btn-align-center-xs ">
                            <a class="btn btn-outline-white btn-round">
                                <span><?php echo esc_attr( $service_cta_btn_text ); ?></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php
get_footer();
