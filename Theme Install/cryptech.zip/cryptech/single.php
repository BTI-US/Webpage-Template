<?php
/**
 * The template for displaying all single posts
 *
 * @package Cryptech
 */

get_header();
$custom_sidebar_post = cryptech_get_page_opt( 'custom_sidebar_post', false );
$post_sidebar_pos = cryptech_get_page_opt( 'sidebar_post_pos', 'right' );
if(isset($custom_sidebar_post) && $custom_sidebar_post) {
    $sidebar_pos = $post_sidebar_pos;
} else {
    $sidebar_pos = cryptech_get_opt( 'post_sidebar_pos', 'right' );
}

?>
<div class="container content-container">
    <div class="row content-row">
        <div id="primary" <?php cryptech_primary_class( $sidebar_pos, 'content-area' ); ?>>
            <main id="main" class="site-main">
                <?php

                    while ( have_posts() )
                    {
                        the_post();
                        get_template_part( 'template-parts/content-single' );

                        if ( comments_open() || get_comments_number() )
                        {
                            comments_template();
                        }
                    }

                ?>
            </main><!-- #main -->
        </div><!-- #primary -->

        <?php if ( 'left' == $sidebar_pos || 'right' == $sidebar_pos ) : ?>
        <aside id="secondary" <?php cryptech_secondary_class( $sidebar_pos, 'widget-area' ); ?>>
            <?php get_sidebar(); ?>
        </aside>
        <?php endif; ?>
    </div>
</div>
<?php
get_footer();
