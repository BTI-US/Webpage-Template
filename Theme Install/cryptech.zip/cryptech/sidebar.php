<?php
/**
 * The sidebar containing the main widget area
 *
 * @package Cryptech
 */
dynamic_sidebar( 'sidebar-blog' );