<?php

$titles = cryptech_get_page_titles();

ob_start();

if ( $titles['title'] )
{
    printf( '<h1 class="page-title">%s</h1>', esc_attr($titles['title']) );
}

if ( ( is_page() && get_post_meta( get_the_ID(), 'breadcrumb_on', true ) ) || cryptech_get_opt( 'breadcrumb_on', false ) )
{
    cryptech_breadcrumb();
}

$titles_html = ob_get_clean();

if ( ! $titles_html )
{
    return;
} ?>
<div id="pagetitle" class="page-title page-title-layout1 bg-overlay">
    <div class="container page-title-container">
        <?php printf( '<div class="page-title-content clearfix">%s</div>', wp_kses_post($titles_html)); ?>
    </div>
</div>