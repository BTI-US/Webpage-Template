<?php
/**
 * Template part for displaying default footer layout
 */
$logo_payment = cryptech_get_opt( 'logo_payment' );
$app_footer = cryptech_get_opt( 'app_footer', false );
$app_title = cryptech_get_opt( 'app_title' );
$app_description = cryptech_get_opt( 'app_description' );
$app_store = cryptech_get_opt( 'app_store' );
$app_store_link = cryptech_get_opt( 'app_store_link' );
$google_play = cryptech_get_opt( 'google_play' );
$google_play_link = cryptech_get_opt( 'google_play_link' );
$custom_footer = cryptech_get_page_opt( 'custom_footer', false );
$page_app_footer = cryptech_get_page_opt( 'page_app_footer', 'default' );
if($custom_footer && $page_app_footer == 'hidden') {
    $app_title = '';
}
?>
<footer id="colophon" class="site-footer footer-layout1 bg-overlay">
    <?php if( $app_footer && !empty($app_title) ) : ?>
        <div class="app-footer">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="cms-app-footer">
                            <div class="row">
                                <div class="cms-app-holder col-lg-6 col-md-12 text-center-md">
                                    <h3><?php echo esc_attr( $app_title ); ?></h3>
                                    <span><?php echo esc_attr( $app_description ); ?></span>
                                </div>
                                <div class="cms-app-meta col-lg-6 col-md-12 text-right text-center-md">
                                    <?php if($app_store) : ?>
                                        <div class="app-item">
                                            <a href="<?php echo esc_url( $app_store_link ); ?>">
                                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/app-store.png" />
                                                <span><?php echo esc_html__('App Store', 'cryptech') ?></span>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($google_play) : ?>
                                        <div class="app-item">
                                            <a href="<?php echo esc_url( $google_play_link ); ?>">
                                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/google-play.png" />
                                                <span><?php echo esc_html__('Google Play', 'cryptech') ?></span>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ( is_active_sidebar( 'sidebar-footer-1' ) || is_active_sidebar( 'sidebar-footer-2' ) || is_active_sidebar( 'sidebar-footer-3' ) || is_active_sidebar( 'sidebar-footer-4' ) || is_active_sidebar( 'sidebar-footer-5' ) ) : ?>
        <div class="top-footer">
            <div class="container">
                <div class="row">
                    <?php cryptech_footer_top(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($logo_payment) && !empty($logo_payment[0]['url'])) { ?>
        <div class="bottom-footer">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="cms-footer-payment">
                            <?php 
                                $result = count($logo_payment);
                                for($i=0;$i<$result;$i++){ ?>
                                    <a href="<?php echo esc_url( $logo_payment[$i]['url'] ); ?>" title="<?php echo esc_attr( $logo_payment[$i]['title'] ); ?>">
                                        <img src="<?php echo esc_url( $logo_payment[$i]['image'] ); ?>" alt="<?php echo esc_attr( $logo_payment[$i]['title'] ); ?>" />
                                    </a>
                                <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } else { ?>
        <div class="copyright-footer">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <?php echo wp_kses_post('&copy; '.esc_attr(date("Y")).' With Love by <a target="_blank" href="https://themeforest.net/user/7oroof/portfolio">7oroof.com</a>'); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
    <?php if (cryptech_get_opt('back_totop_on', true)) : ?>
        <a href="#" class="scroll-top fixed-bottom"><i class="zmdi zmdi-chevron-up"></i></a>
    <?php endif; ?>
</footer><!-- #colophon -->