<?php
/**
 * Template part for displaying default header layout
 */

$rf_class = '';
if (class_exists('ReduxFramework')) {
    $rf_class = 'rf-active';
} else {
    $rf_class = 'rf-no-active';
}
$sticky_on = cryptech_get_opt( 'sticky_on', false );
$h_seach_icon = cryptech_get_opt( 'h_seach_icon', false );

$h_btn_on = cryptech_get_opt( 'h_btn_on', 'show' );
$h_btn_link_type = cryptech_get_opt( 'h_btn_link_type', 'page' );
$h_btn_text = cryptech_get_opt( 'h_btn_text' );
$h_btn_link = cryptech_get_opt( 'h_btn_link' );
$h_btn_link_custom = cryptech_get_opt( 'h_btn_link_custom' );
$h_btn_target = cryptech_get_opt( 'h_btn_target', '_self' );

$custom_header = cryptech_get_page_opt( 'custom_header', false );
$page_h_seach_icon = cryptech_get_page_opt( 'page_h_seach_icon', 'default' );

$h_btn_on_page = cryptech_get_page_opt( 'h_btn_on_page', 'themeoption' );
$page_h_btn_text = cryptech_get_page_opt( 'page_h_btn_text' );
$page_btn_link_type = cryptech_get_page_opt( 'page_btn_link_type', 'page' );
$page_h_btn_link = cryptech_get_page_opt( 'page_h_btn_link' );
$page_btn_link_custom = cryptech_get_page_opt( 'page_btn_link_custom' );

if($custom_header && $h_btn_on_page != 'themeoption') {
    $h_btn_on = $h_btn_on_page;
}
if($custom_header && !empty($page_h_btn_text)) {
    $h_btn_text = $page_h_btn_text;
}
if($custom_header && !empty($page_h_btn_link)) {
    $h_btn_link = $page_h_btn_link;
}
if($custom_header && $page_h_seach_icon == 'hidden') {
    $h_seach_icon = '';
}
if($custom_header && isset($h_btn_on_page)) {
    $h_btn_link_type = $page_btn_link_type;
}
if($custom_header && !empty($page_btn_link_custom)) {
    $h_btn_link_custom = $page_btn_link_custom;
}
if($h_btn_link_type == 'page') {
    $h_btn_url = get_permalink($h_btn_link);
} else {
    $h_btn_url = $h_btn_link_custom;
}

$top_bar_phone_label = cryptech_get_opt( 'top_bar_phone_label' );
$top_bar_phone = cryptech_get_opt( 'top_bar_phone' );
$top_bar_address_label = cryptech_get_opt( 'top_bar_address_label' );
$top_bar_address = cryptech_get_opt( 'top_bar_address' );
$top_bar_email_label = cryptech_get_opt( 'top_bar_email_label' );
$top_bar_email = cryptech_get_opt( 'top_bar_email' );

?>
<header id="masthead" class="site-header">
    <div id="site-header-wrap" class="header-layout5 header-white fixed-height <?php echo esc_attr( $rf_class ); ?> <?php if($sticky_on == 1) { echo 'is-sticky'; } else { echo 'no-sticky'; } ?>">
        <div id="site-header-top" class="header-top2">
            <div class="container">
                <div class="row">
                    <div class="site-branding">
                       <?php get_template_part( 'template-parts/header-branding' ); ?>
                    </div>
                    <div class="site-contact-wrap">
                        <div class="site-contact-item">
                            <i class="et-map-pin"></i>
                            <div class="site-contact-meta">
                                <label><?php echo esc_attr( $top_bar_address_label ); ?></label>
                                <span><?php echo esc_attr($top_bar_address); ?></span>
                            </div>
                        </div>
                        <div class="site-contact-item">
                            <i class="et-document"></i>
                            <div class="site-contact-meta">
                                <label><?php echo esc_attr( $top_bar_email_label ); ?></label>
                                <a href="mailto:<?php echo esc_attr($top_bar_email); ?>"><?php echo esc_attr($top_bar_email); ?></a>
                            </div>
                        </div>
                        <div class="site-contact-item">
                            <i class="et-phone"></i>
                            <div class="site-contact-meta">
                                <label><?php echo esc_attr( $top_bar_phone_label ); ?></label>
                                <a href="tel:<?php echo esc_attr($top_bar_phone); ?>"><?php echo esc_attr($top_bar_phone); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="site-contact-social">
                        <?php cryptech_header_social(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div id="headroom" class="site-header-main">
            <div class="container">
                <div class="row">
                    <div class="site-branding col-md-12">
                        <?php get_template_part( 'template-parts/header-branding' ); ?>
                    </div>
                    <div class="col-12">
                        <nav id="site-navigation" class="main-navigation">
                            <?php get_template_part( 'template-parts/header-menu' ); ?>
                        </nav>
                        <div class="site-menu-right">
                            <?php if($h_seach_icon) : ?>
                                <span class="menu-right-item h-btn-search"><i class="fa fa-search"></i></span>
                            <?php endif; ?>
                            <?php if($h_btn_on == 'show' && !empty($h_btn_text)) : ?>
                                <a href="<?php echo esc_url( $h_btn_url ); ?>" target="<?php echo esc_attr($h_btn_target); ?>" class="menu-right-item btn"><?php echo esc_attr( $h_btn_text ); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="main-menu-mobile">
            <span class="btn-nav-mobile open-menu">
                <span></span>
            </span>
        </div>
        <?php if($h_seach_icon) : ?>
            <div id="search-mobile">
                <span class="h-btn-search"><i class="fa fa-search"></i></span>
            </div>
        <?php endif; ?>
    </div>
</header>