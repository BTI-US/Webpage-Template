<?php
/**
 * Template part for displaying the primary menu of the site
 */
$custom_header = cryptech_get_page_opt('custom_header', false);
$page_h_custom_menu = cryptech_get_page_opt('page_h_custom_menu');
if ( has_nav_menu( 'primary' ) )
{
    $attr_menu = array(
        'theme_location' => 'primary',
        'container'  => '',
        'menu_id'    => 'mastmenu',
        'menu_class' => 'primary-menu',
        'walker'         => class_exists( 'EFramework_Mega_Menu_Walker' ) ? new EFramework_Mega_Menu_Walker : '',
    );
    if($custom_header == true && !empty($page_h_custom_menu)) {
        $attr_menu['menu'] = $page_h_custom_menu;
    }
    wp_nav_menu( $attr_menu );
}
else
{
    printf(
        '<ul class="primary-menu-not-set"><li><a href="%1$s">%2$s</a></li></ul>',
        esc_url( admin_url( 'nav-menus.php' ) ),
        esc_html__( 'Create New Menu', 'cryptech' )
    );
}