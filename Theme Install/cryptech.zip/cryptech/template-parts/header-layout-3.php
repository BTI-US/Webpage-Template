<?php
/**
 * Template part for displaying default header layout
 */

$rf_class = '';
if (class_exists('ReduxFramework')) {
    $rf_class = 'rf-active';
} else {
    $rf_class = 'rf-no-active';
}
$sticky_on = cryptech_get_opt( 'sticky_on', false );
$h_seach_icon = cryptech_get_opt( 'h_seach_icon', false );
$h_btn_group = cryptech_get_opt( 'h_btn_group', 'hidden' );

$h_btn_on = cryptech_get_opt( 'h_btn_on', 'show' );
$h_btn_link_type = cryptech_get_opt( 'h_btn_link_type', 'page' );
$h_btn_text = cryptech_get_opt( 'h_btn_text' );
$h_btn_link = cryptech_get_opt( 'h_btn_link' );
$h_btn_link_custom = cryptech_get_opt( 'h_btn_link_custom' );
$h_btn_target = cryptech_get_opt( 'h_btn_target', '_self' );

$top_bar_phone = cryptech_get_opt( 'top_bar_phone' );
$top_bar_address = cryptech_get_opt( 'top_bar_address' );
$top_bar_email = cryptech_get_opt( 'top_bar_email' );

$custom_header = cryptech_get_page_opt( 'custom_header', false );
$page_h_seach_icon = cryptech_get_page_opt( 'page_h_seach_icon', 'default' );
$page_h_btn_group = cryptech_get_page_opt( 'page_h_btn_group', 'default' );

$h_btn_on_page = cryptech_get_page_opt( 'h_btn_on_page', 'themeoption' );
$page_h_btn_text = cryptech_get_page_opt( 'page_h_btn_text' );
$page_btn_link_type = cryptech_get_page_opt( 'page_btn_link_type', 'page' );
$page_h_btn_link = cryptech_get_page_opt( 'page_h_btn_link' );
$page_btn_link_custom = cryptech_get_page_opt( 'page_btn_link_custom' );
$page_h_btn_style = cryptech_get_page_opt( 'page_h_btn_style', 'default' );

if($custom_header && $h_btn_on_page != 'themeoption') {
    $h_btn_on = $h_btn_on_page;
}
if($custom_header && !empty($page_h_btn_text)) {
    $h_btn_text = $page_h_btn_text;
}
if($custom_header && !empty($page_h_btn_link)) {
    $h_btn_link = $page_h_btn_link;
}
if($custom_header && $page_h_seach_icon == 'hidden') {
    $h_seach_icon = '';
}
if($custom_header && $page_h_btn_group != 'default') {
    $h_btn_group = $page_h_btn_group;
}
if($custom_header && isset($h_btn_on_page)) {
    $h_btn_link_type = $page_btn_link_type;
}
if($custom_header && !empty($page_btn_link_custom)) {
    $h_btn_link_custom = $page_btn_link_custom;
}
if($h_btn_link_type == 'page') {
    $h_btn_url = get_permalink($h_btn_link);
} else {
    $h_btn_url = $h_btn_link_custom;
}

$magic_line_position = cryptech_get_opt( 'magic_line_position', 'magic-line-bottom' );
$magic_line_position_page = cryptech_get_page_opt( 'magic_line_position_page', 'themeoption' );
if($custom_header && $magic_line_position_page != 'themeoption' ) {
    $magic_line_position = $magic_line_position_page;
}
$magic_line_color = cryptech_get_opt( 'magic_line_color', 'magic-line-primary' );
$magic_line_color_page = cryptech_get_page_opt( 'magic_line_color_page', 'themeoption' );
if($custom_header && $magic_line_color_page != 'themeoption' ) {
    $magic_line_color = $magic_line_color_page;
}
$h_btn_group_hover_type = cryptech_get_opt( 'h_btn_group_hover_type', 'h-btn-hover-primary' );
$h_btn_group_hover_type_page = cryptech_get_page_opt( 'h_btn_group_hover_type_page', 'themeoption' );
if($custom_header && $h_btn_group_hover_type_page != 'themeoption' ) {
    $h_btn_group_hover_type = $h_btn_group_hover_type_page;
}
$h_header = cryptech_get_opt( 'h_header', 'h_medium' );
$page_h_header = cryptech_get_page_opt( 'page_h_header', 'themeoption' );
if($custom_header && $page_h_header != 'themeoption' ) {
    $h_header = $page_h_header;
}
?>
<header id="masthead" class="site-header">
    <div id="site-header-wrap" class="header-layout3 header-white fixed-height <?php echo esc_attr( $rf_class.' '.$h_header ); ?> <?php if($sticky_on == 1) { echo 'is-sticky'; } else { echo 'no-sticky'; } ?>">
        <div id="site-header-top" class="header-top1">
            <div class="container">
                <div class="row">
                    <div class="site-contact-wrap">
                        <div class="site-contact-item">
                            <i class="et-map-pin"></i>
                            <span><?php echo esc_attr($top_bar_address); ?></span>
                        </div>
                        <div class="site-contact-item">
                            <i class="et-phone"></i>
                            <a href="tel:<?php echo esc_attr($top_bar_phone); ?>"><?php echo esc_attr($top_bar_phone); ?></a>
                        </div>
                        <div class="site-contact-item">
                            <i class="et-document"></i>
                            <a href="mailto:<?php echo esc_attr($top_bar_email); ?>"><?php echo esc_attr($top_bar_email); ?></a>
                        </div>
                    </div>
                    <div class="site-contact-social">
                        <span><?php echo esc_html__('Follow Us:', 'cryptech'); ?></span>
                        <?php cryptech_header_social(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div id="headroom" class="site-header-main">
            <div class="container">
                <div class="row">
                    <div class="site-branding header-col-left">
                        <?php get_template_part( 'template-parts/header-branding' ); ?>
                    </div>
                    <div class="header-col-right">
                        <nav id="site-navigation" class="main-navigation <?php echo esc_attr( $magic_line_position.' '.$magic_line_color ); ?>">
                            <?php get_template_part( 'template-parts/header-menu' ); ?>
                        </nav>
                        <div class="site-menu-right d-none d-lg-block <?php echo esc_attr($h_btn_group_hover_type); ?>">
                            <?php if($h_btn_on == 'show' && !empty($h_btn_text)) : ?>
                                <a href="<?php echo esc_url( $h_btn_url ); ?>" target="<?php echo esc_attr($h_btn_target); ?>" class="menu-right-item h-btn h-btn-<?php echo esc_attr($page_h_btn_style); ?>"><?php echo esc_attr( $h_btn_text ); ?></a>
                            <?php endif; ?>
                            <?php if($h_btn_group == 'signin-signup') : ?>
                                <?php if ( is_user_logged_in() ) { ?>
                                    <a href="<?php echo wp_logout_url(); ?>" class="menu-right-item h-btn-text btn-sign-out"><?php echo esc_html('Sign Out', 'cryptech') ?></a>
                                <?php } else { ?>
                                    <span class="menu-right-item h-btn btn-sign-in"><?php echo esc_html('Sign In', 'cryptech') ?></span>
                                    <span class="menu-right-item h-btn-text btn-sign-up"><?php echo esc_html('Sign Up', 'cryptech') ?></span>
                                <?php } ?>
                            <?php endif; ?>
                            <?php if($h_btn_group == 'signup') : ?>
                                <?php if ( is_user_logged_in() ) { ?>
                                    <a href="<?php echo wp_logout_url(); ?>" class="menu-right-item h-btn-text btn-sign-out"><?php echo esc_html('Sign Out', 'cryptech') ?></a>
                                <?php } else { ?>
                                    <span class="menu-right-item h-btn-text btn-sign-up"><?php echo esc_html('Sign Up', 'cryptech') ?></span>
                                <?php } ?>
                            <?php endif; ?>
                            <?php if($h_seach_icon) : ?>
                                <span class="menu-right-item h-btn-search"><i class="fa fa-search"></i></span>
                            <?php endif; ?>
                            <?php if($h_btn_group == 'cart') : ?>
                                <span class="menu-right-item h-btn-cart">
                                    <i class="fa fa-shopping-cart"></i>
                                    <?php if(class_exists('Woocommerce')){ ?>
                                        <span class="couter_items"><?php echo sprintf (_n( '%d', '%d', WC()->cart->cart_contents_count, 'cryptech' ), WC()->cart->cart_contents_count ); ?></span>
                                    <?php } ?>
                                </span>
                            <?php endif; ?>
                            <?php if ( class_exists('Woocommerce') && class_exists( 'WC_Widget_Cart' ) ): ?>
                                <div class="widget_shopping_cart">
                                    <div class="widget_shopping_cart_content">
                                        <?php woocommerce_mini_cart(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="main-menu-mobile">
            <span class="btn-nav-mobile open-menu">
                <span></span>
            </span>
        </div>
        <?php if($h_seach_icon) : ?>
            <div id="search-mobile">
                <span class="h-btn-search"><i class="fa fa-search"></i></span>
            </div>
        <?php endif; ?>
    </div>
</header>