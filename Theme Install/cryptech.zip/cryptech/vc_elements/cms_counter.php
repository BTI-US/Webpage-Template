<?php
vc_map(array(
    "name" => 'Counter',
    "base" => "cms_counter",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(

        /* Template */
        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            "shortcode" => "cms_counter",
            "heading" => esc_html__("Shortcode Template", 'cryptech'),
            "admin_label" => true,
            "group" => esc_html__("Template", 'cryptech'),
        ),

        /* Title */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Title", 'cryptech'),
            "param_name" => "title",
            "description" => "Enter title.",
            "group" => esc_html__("Title", 'cryptech'),
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", 'cryptech'),
            "param_name" => "title_color",
            "value" => "",
            "group" => esc_html__("Title", 'cryptech'),
        ),

        /* Digit */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Digit", 'cryptech'),
            "param_name" => "digit",
            "description" => "Enter digit.",
            "group" => esc_html__("Digit", 'cryptech'),
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", 'cryptech'),
            "param_name" => "digit_color",
            "value" => "",
            "group" => esc_html__("Digit", 'cryptech'),
        ),

        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Use Grouping", 'cryptech'),
            'param_name' => 'grouping',
            'value' => array(
                'No' => '0',
                'Yes' => '1',
            ),
            "group" => esc_html__("Digit", 'cryptech'),
        ),  
        array(
            "type" => "textfield",
            "heading" => esc_html__("Separator", 'cryptech'),
            "param_name" => "separator",
            "group" => esc_html__("Digit", 'cryptech'),
            "dependency" => array(
                "element"=>"grouping",
                "value"=>array(
                    "1",
                )
            ),
        ),

        /* Extra */
        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
            "group"            => esc_html__("Extra", "cryptech")
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            "group" => esc_html__("Extra", 'cryptech'),
        )
    )
));

class WPBakeryShortCode_cms_counter extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>