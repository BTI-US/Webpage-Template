<?php
$args = array(
    "name" => 'Client Carousel',
    "base" => "cms_client_carousel",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(

        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            "shortcode" => "cms_client_carousel",
            "heading" => esc_html__("Shortcode Template", "cryptech"),
            "admin_label" => true,
            "group" => esc_html__("Template", "cryptech"),
        ),
        /* Extra */
        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
            "group"            => esc_html__("Template", "cryptech")
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            "group" => esc_html__("Template", 'cryptech'),
        ),
        
        array(
            'type' => 'param_group',
            'heading' => esc_html__( 'Clients', 'cryptech' ),
            'param_name' => 'client_items',
            'value' => '',
            "group"      => esc_html__("Source Settings", "cryptech"),
            'params' => array(
                array(
                    "type" => "textfield",
                    "heading" => __ ( 'Title', 'cryptech' ),
                    "param_name" => "client_title",
                    "value" => '',
                    "admin_label" => true,
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Image', 'cryptech' ),
                    'param_name' => 'client_image',
                    'value' => '',
                    'description' => esc_html__( 'Select image from media library.', 'cryptech' ),
                ),
                array(
                    "type" => "vc_link",
                    "class" => "",
                    "heading" => esc_html__("Link", 'cryptech'),
                    "param_name" => "client_link",
                    "value" => '',
                ),
            ),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Items Row", 'cryptech'),
            'param_name' => 'row',
            'value' => array(
                '1 Row' => '1',       
                '2 Row' => '2',      
            ),
            "group" => esc_html__("Source Settings", 'cryptech'),
        ),

    ));

$args = cryptech_add_vc_extra_param($args);
vc_map($args);

class WPBakeryShortCode_cms_client_carousel extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>