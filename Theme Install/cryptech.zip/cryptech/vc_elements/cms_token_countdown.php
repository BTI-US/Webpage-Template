<?php
	if(class_exists('CmsShortCode')){
		vc_map(
			array(
				'name' => esc_html__('Coin Token Countdown', 'cryptech'),
			    'base' => 'cms_token_countdown',
			    'class' => 'cms-vc-icon',
			    'category' => esc_html__('CSH Crypto Shortcodes', 'cryptech'),
			    'params' => array(
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Title', 'cryptech'),
			            'param_name' => 'title',
			            'value' => '',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Date Count Down', 'cryptech'),
			            'param_name' => 'date_count_down',
			            'value' => '',
			            'description' => esc_html__('Set date count down (Example: 2020/01/10)', 'cryptech'),
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Button Text', 'cryptech'),
			            'param_name' => 'btn_text',
			            'value' => '',
			        ),
			        array(
			            'type' => 'vc_link',
			            'heading' => esc_html__('Button Link', 'cryptech'),
			            'param_name' => 'btn_link',
			            'value' => '',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Softcap', 'cryptech'),
			            'param_name' => 'softcap',
			            'value' => '',
			            'description' => 'Enter number.',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Hardcap', 'cryptech'),
			            'param_name' => 'hardcap',
			            'value' => '',
			            'description' => 'Enter number.',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Currency', 'cryptech'),
			            'param_name' => 'currency',
			            'value' => '',
			            'description' => 'Default: $',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Total Days', 'cryptech'),
			            'param_name' => 'total_days',
			            'value' => '',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Total Tokens', 'cryptech'),
			            'param_name' => 'total_tokens',
			            'value' => '',
			        ),
			        array(
			            'type' => 'colorpicker',
			            'heading' => esc_html__('Total Color', 'cryptech'),
			            'param_name' => 'total_tokens_color',
			            'value' => '',
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__( 'Extra class name', 'cryptech' ),
			            'param_name' => 'el_class',
			            'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
			        	'group'  => 'Extras'
			        ),
			        array(
			            'type' => 'animation_style',
			            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
			            'param_name' => 'animation',
			            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
			            'admin_label' => false,
			            'weight' => 0,
			            'group'  => 'Extras'
			        )
			    )
			)
		);
		class WPBakeryShortCode_cms_token_countdown extends CmsShortCode{
			protected function content($atts, $content = null){
				wp_enqueue_script('cryptech-countdown-config', get_template_directory_uri() . '/assets/js/cms-countdown.js', array( 'jquery' ), 'all', true);
				wp_enqueue_script('progressbar', get_template_directory_uri() . '/assets/js/progressbar.min.js', array( 'jquery' ), '0.7.1', true);
	    		wp_enqueue_script('cms-progressbar', get_template_directory_uri() . '/assets/js/cms-progressbar.js', array( 'jquery' ), 'all', true);
	    		wp_enqueue_script('waypoints');
				return parent::content($atts, $content);
			}
		}
	}
?>