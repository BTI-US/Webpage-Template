<?php
vc_map(array(
    'name' => 'Fancy Box',
    'base' => 'cms_fancybox',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(

        /* Template */
        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            'shortcode' => 'cms_fancybox',
            'heading' => esc_html__('Shortcode Template', 'cryptech'),
            'admin_label' => true,
            'group' => esc_html__('Template', 'cryptech'),
        ),
        
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Content Align', 'cryptech'),
            'param_name' => 'content_align',
            'value' => array(
                'Center' => 'center',       
                'Left' => 'left',       
                'Right' => 'right',       
            ),
            'group' => esc_html__('Template', 'cryptech'),
            'dependency' => array(
                'element' => 'cms_template',
                'value' => 'cms_fancybox.php',
            ),
        ),

        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra class name', 'cryptech' ),
            'param_name' => 'el_class',
            'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
            'group'            => esc_html__('Template', 'cryptech')
        ),

        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            'group' => esc_html__('Template', 'cryptech'),
        ),
        /* Title */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Sub Title', 'cryptech'),
            'param_name' => 'subtitle',
            'group' => esc_html__('Title', 'cryptech'),
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_fancybox--layout3.php',
                )
            ),
        ),
        array(
            'type' => 'textarea',
            'heading' => esc_html__('Title', 'cryptech'),
            'param_name' => 'title',
            'description' => 'Enter title.',
            'group' => esc_html__('Title', 'cryptech'),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Text Color', 'cryptech'),
            'param_name' => 'title_color',
            'value' => '',
            'group' => esc_html__('Title', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Font Size', 'cryptech'),
            'param_name' => 'title_font_size',
            'description' => 'Enter ..px',
            'group' => esc_html__('Title', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Line Height', 'cryptech'),
            'param_name' => 'title_line_height',
            'description' => 'Enter ..px',
            'group' => esc_html__('Title', 'cryptech'),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Font Weight', 'cryptech'),
            'param_name' => 'font_weight',
            'value' => array(
                'SemiBold' => '600',
                'Normal' => '400',
                'Medium' => '500',
                'Bold' => '700',
            ),
            'std' => '600',
            'group'      => esc_html__('Title', 'cryptech'),
        ),

        /* Description */
        array(
            'type' => 'textarea',
            'heading' => esc_html__('Description', 'cryptech'),
            'param_name' => 'description',
            'description' => 'Enter description.',
            'group' => esc_html__('Description', 'cryptech'),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Text Color', 'cryptech'),
            'param_name' => 'description_color',
            'value' => '',
            'group' => esc_html__('Description', 'cryptech'),
        ),

        /* Button */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Text', 'cryptech'),
            'param_name' => 'button_text',
            'description' => 'Enter text button.',
            'group' => esc_html__('Button', 'cryptech'),
        ),
        array(
            'type' => 'vc_link',
            'class' => '',
            'heading' => esc_html__('Link', 'cryptech'),
            'param_name' => 'button_link',
            'value' => '',
            'group' => esc_html__('Button', 'cryptech'),
        ),

        /* Icon */
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Icon Type', 'cryptech'),
            'param_name' => 'icon_type',
            'value' => array(
                'Icon' => 'icon',        
                'Image' => 'image',        
            ),
            'group' => esc_html__('Icon', 'cryptech'),
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_fancybox.php',
                    'cms_fancybox--layout2.php',
                    'cms_fancybox--layout4.php',
                )
            ),
        ),  
        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'Image', 'cryptech' ),
            'param_name' => 'icon_image',
            'value' => '',
            'description' => esc_html__( 'Select icon image from media library.', 'cryptech' ),
            'dependency' => array(
                'element'=>'icon_type',
                'value'=>array(
                    'image',
                )
            ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__('Icon Position', 'cryptech'),
            'param_name' => 'icon_position',
            'value' => array(
                'Middle' => 'middle',
                'Top' => 'top',
            ),
            'group' => esc_html__('Icon', 'cryptech'),
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_fancybox--layout2.php',
                )
            ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Bottom', 'cryptech'),
            'param_name' => 'icon_margin_bottom',
            'description' => 'Enter number.',
            'dependency' => array(
                'element'=>'icon_type',
                'value'=>array(
                    'image',
                )
            ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon Library', 'cryptech' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'cryptech' ) => 'fontawesome',
                esc_html__( 'Material Design', 'cryptech' ) => 'material_design',
                esc_html__( 'ET Line', 'cryptech' ) => 'etline',
            ),
            'param_name' => 'icon_list',
            'description' => esc_html__( 'Select icon library.', 'cryptech' ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'icon',
            ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Material', 'cryptech' ),
            'param_name' => 'icon_material_design',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'material-design',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'material_design',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon FontAwesome', 'cryptech' ),
            'param_name' => 'icon_fontawesome',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'fontawesome',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon ET Line', 'cryptech' ),
            'param_name' => 'icon_etline',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'etline',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'etline',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Color', 'cryptech'),
            'param_name' => 'icon_color',
            'value' => '',
            'group' => esc_html__('Icon', 'cryptech'),
            'dependency' => array(
                'element'=>'icon_type',
                'value'=>array(
                    'icon',
                )
            ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Number', 'cryptech'),
            'param_name' => 'number',
            'description' => 'Enter number.',
            'group' => esc_html__('Title', 'cryptech'),
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_fancybox--layout3.php',
                )
            ),
        ),
    )
));

class WPBakeryShortCode_cms_fancybox extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>