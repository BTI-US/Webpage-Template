<?php
    if(class_exists('Crypto_Currency_Price_Widget')) {
        $coins = get_posts( 'post_type="ccpw"&numberposts=-1' );
        $shortcodes = array();
        if ( $coins ) {
            foreach ( $coins as $coin_ticker ) {
                $shortcodes[ $coin_ticker->post_title ] = $coin_ticker->ID;
            }
        } else {
            $shortcodes[ esc_html__( 'No contact forms found', 'cryptech' ) ] = 0;
        }

        vc_map(array(
            'name' => 'Coin Ticker',
            'base' => 'cms_coin_ticker',
            'icon' => 'cs_icon_for_vc',
            'class' => 'cms-vc-icon',
            'category' => esc_html__('CSH Crypto Shortcodes', 'cryptech'),
            'params' => array(
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Select Shortcode', 'cryptech' ),
                    'param_name' => 'id',
                    'value' => $shortcodes,
                    'save_always' => true,
                    'admin_label' => true,
                ),
                /* Extra */
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'cryptech' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__( 'Animation Style', 'cryptech' ),
                    'param_name' => 'animation',
                    'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
                    'admin_label' => false,
                    'weight' => 0,
                ),
                array(    
                    'type' => 'dropdown',
                    'heading' => esc_html__('Styles', 'cryptech'),
                    'param_name' => 'style',
                    'value' => array(  
                        'Default' => 'default',                       
                        'Primary' => 'primary',         
                    ),
                ),
            )
        ));

        class WPBakeryShortCode_cms_coin_ticker extends CmsShortCode
        {

            protected function content($atts, $content = null)
            {
                return parent::content($atts, $content);
            }
        }
    }
?>