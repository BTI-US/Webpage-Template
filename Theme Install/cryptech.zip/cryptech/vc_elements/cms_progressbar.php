<?php
vc_map(
	array(
		'name' => esc_html__('Progress Bar', 'cryptech'),
	    'base' => 'cms_progressbar',
	    'class' => 'cms-vc-icon',
	    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
	    'params' => array(
	    	array(
                'type' => 'cms_template_img',
                'param_name' => 'cms_template',
                'shortcode' => 'cms_progressbar',
                'heading' => esc_html__('Shortcode Template', 'cryptech'),
                'admin_label' => true,
                'std' => 'cms_progressbar.php',
                'group' => esc_html__('Template', 'cryptech'),
            ),
            array(
	            'type' => 'textfield',
	            'heading' => esc_html__('Extra Class', 'cryptech'),
	            'param_name' => 'el_class',
	            'value' => '',
	            'group' => esc_html__('Template', 'cryptech')
	        ),
	        array(
	            'type' => 'param_group',
	            'heading' => esc_html__( 'Progress Bar Lists', 'cryptech' ),
	            'param_name' => 'cms_progressbar_list',
	            'value' => '',
	            'params' => array(
	                array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Item Title', 'cryptech'),
			            'param_name' => 'item_title',
			            'value' => '',
			            'group' => esc_html__('Progress Bar Settings', 'cryptech'),
			            'admin_label' => true,
			        ),
					array(
						'type' => 'textfield',
						'class' => '',
						'value' => '',
						'heading' => esc_html__( 'Value', 'cryptech' ),
						'param_name' => 'value',
						'description' => 'Enter number only 1 to 100',
						'group' => esc_html__('Progress Bar Settings', 'cryptech'),
						'admin_label' => true,
					),
	            ),
	        ),
	    )
	)
);
class WPBakeryShortCode_cms_progressbar extends CmsShortCode{
	protected function content($atts, $content = null){
		/* CSS */
	    wp_enqueue_style('progressbar', get_template_directory_uri() . '/assets/css/progressbar.min.css', array(), '0.7.1');
	    /* JS */
	    wp_enqueue_script('progressbar', get_template_directory_uri() . '/assets/js/progressbar.min.js', array( 'jquery' ), '0.7.1', true);
	    wp_enqueue_script('cms-progressbar', get_template_directory_uri() . '/assets/js/cms-progressbar.js', array( 'jquery' ), 'all', true);
	    wp_enqueue_script('waypoints');
		return parent::content($atts, $content);
	}
}

?>