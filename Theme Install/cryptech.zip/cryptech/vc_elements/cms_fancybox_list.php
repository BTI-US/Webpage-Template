<?php
$args = array(
    "name" => 'Fancybox List Carousel',
    "base" => "cms_fancybox_list",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(

        array(
            'type' => 'param_group',
            "heading" => esc_html__( 'Fancybox List', 'cryptech' ),
            'value' => '',
            'param_name' => 'fancybox_list',
            'params' => array(
                array(
                    "type" => "textfield",
                    "heading" =>esc_html__("Title", 'cryptech'),
                    "param_name" => "title",
                    'admin_label' => true,
                ), 
                array(
                    "type" => "textarea",
                    "heading" => esc_html__("Content", 'cryptech'),
                    "param_name" => "content",
                ),
                array(
                    'type' => 'iconpicker',
                    'heading' => esc_html__( 'Icon ET Line', 'cryptech' ),
                    'param_name' => 'icon_etline',
                    'settings' => array(
                        'emptyIcon' => true,
                        'type' => 'etline',
                        'iconsPerPage' => 200,
                    ),
                    'dependency' => array(
                        'element' => 'icon_list',
                        'value' => 'etline',
                    ),
                    'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
                ),
            ),
        ),

        array(
            'type'       => 'dropdown',
            'heading'    => esc_html__('Rows', 'cryptech'),
            'param_name' => 'rows',
            'value'      => array(
                '1' => '1',
                '2' => '2',
                '3' => '3',
                '4' => '4',
            ),
            'std'        => '1',
            'group' => 'Carousel Settings'
        ),

        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
        ),

    ));

$args = cryptech_add_vc_extra_param($args);
vc_map($args);

class WPBakeryShortCode_cms_fancybox_list extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>