<?php
vc_map(array(
    "name" => 'Space',
    "base" => "cms_space",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(

        array(
            "type" => "textfield",
            "heading" => esc_html__("Space Large Devices", 'cryptech'),
            "param_name" => "space_lg",
            "description" => "Enter number."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Space Medium Devices", 'cryptech'),
            "param_name" => "space_md",
            "description" => "Enter number."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Space Small Devices", 'cryptech'),
            "param_name" => "space_sm",
            "description" => "Enter number."
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Space Mini Devices", 'cryptech'),
            "param_name" => "space_xs",
            "description" => "Enter number."
        ),
        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'Backgroung Image', 'cryptech' ),
            'param_name' => 'bg_image',
            'value' => '',
            'description' => esc_html__( 'Select icon image from media library.', 'cryptech' ),
            "group" => esc_html__("Background", 'cryptech'),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Backgroung Position", 'cryptech'),
            'param_name' => 'bg_position',
            'value' => array(
                'Center' => 'center',       
                'Top Left' => 'top left',       
                'Top Right' => 'top right',       
                'Bottom Left' => 'bottom left',       
                'Bottom Right' => 'bottom right',       
            ),
            "group" => esc_html__("Background", 'cryptech'),
        ),  
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Backgroung Size", 'cryptech'),
            'param_name' => 'bg_size',
            'value' => array(
                'Default' => 'initial',      
                'Contain' => 'contain',      
                'Cover' => 'cover',       
                'Fixed' => 'fixed',       
            ),
            "group" => esc_html__("Background", 'cryptech'),
        ),  
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Backgroung Repeat", 'cryptech'),
            'param_name' => 'bg_repeat',
            'value' => array(
                'No Repeat' => 'no-repeat',       
                'Repeat' => 'repeat',       
            ),
            "group" => esc_html__("Background", 'cryptech'),
        ),  
    )
));

class WPBakeryShortCode_cms_space extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>