<?php
vc_map(array(
    'name' => 'Button',
    'base' => 'cms_button',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Text', 'cryptech' ),
            'param_name' => 'button_text',
            'value' => '',
            'admin_label' => true,
            'group' => esc_html__('Button Settings', 'cryptech')
        ),
        array(
            'type' => 'vc_link',
            'class' => '',
            'heading' => esc_html__('Link', 'cryptech'),
            'param_name' => 'button_link',
            'value' => '',
            'group' => esc_html__('Button Settings', 'cryptech')
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Style', 'cryptech'),
            'param_name' => 'button_style',
            'value' => array(
                'Button Default' => 'btn-default',
                'Button Outline White Hover Dark' => 'btn-outline-white',
                'Button Outline White Hover Primary' => 'btn-outline-white hover-primary',
            ),
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Shapes', 'cryptech'),
            'param_name' => 'button_shapes',
            'value' => array(
                'Button Normal' => '',
                'Button Round' => 'btn-round',
            ),
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),  
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Size', 'cryptech'),
            'param_name' => 'button_size',
            'value' => array(
                'Button Medium' => 'btn-size-md',
                'Button Large' => 'btn-size-lg',
            ),
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Align LG', 'cryptech'),
            'param_name' => 'button_align',
            'value' => array(
                'Left' => 'left',                
                'Center' => 'center',        
                'Right' => 'right',        
            ),
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ), 
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Align MD', 'cryptech'),
            'param_name' => 'button_align_md',
            'value' => array(
                'Left' => 'left',                
                'Center' => 'center',        
                'Right' => 'right',        
            ),
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ), 
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Align SM', 'cryptech'),
            'param_name' => 'button_align_sm',
            'value' => array(
                'Left' => 'left',                
                'Center' => 'center',        
                'Right' => 'right',        
            ),
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ), 
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Button Align XS', 'cryptech'),
            'param_name' => 'button_align_xs',
            'value' => array(
                'Left' => 'left',                
                'Center' => 'center',        
                'Right' => 'right',        
            ),
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ), 
        /* Padding */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Top', 'cryptech'),
            'param_name' => 'padding_top',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Right', 'cryptech'),
            'param_name' => 'padding_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Bottom', 'cryptech'),
            'param_name' => 'padding_bottom',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Left', 'cryptech'),
            'param_name' => 'padding_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),

        /* Margin */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Top', 'cryptech'),
            'param_name' => 'margin_top',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Right', 'cryptech'),
            'param_name' => 'margin_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Bottom', 'cryptech'),
            'param_name' => 'margin_bottom',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Left', 'cryptech'),
            'param_name' => 'margin_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),

        /* Border radius */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Top Left', 'cryptech'),
            'param_name' => 'br_top_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Top Right', 'cryptech'),
            'param_name' => 'br_top_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Bottom Right', 'cryptech'),
            'param_name' => 'br_bottom_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Bottom Left', 'cryptech'),
            'param_name' => 'br_bottom_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
            'group' => esc_html__('Button Settings', 'cryptech'),
        ),
        /* Icon */
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Icon Type', 'cryptech'),
            'param_name' => 'icon_type',
            'value' => array(
                'Icon' => 'icon',        
                'Image' => 'image',        
            ),
            'group' => esc_html__('Icon', 'cryptech'),
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_fancybox.php',
                    'cms_fancybox--layout2.php',
                )
            ),
        ),  
        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'Image', 'cryptech' ),
            'param_name' => 'icon_image',
            'value' => '',
            'description' => esc_html__( 'Select icon image from media library.', 'cryptech' ),
            'dependency' => array(
                'element'=>'icon_type',
                'value'=>array(
                    'image',
                )
            ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon Library', 'cryptech' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'cryptech' ) => 'fontawesome',
                esc_html__( 'Material Design', 'cryptech' ) => 'material_design',
                esc_html__( 'ET Line', 'cryptech' ) => 'etline',
            ),
            'param_name' => 'icon_list',
            'description' => esc_html__( 'Select icon library.', 'cryptech' ),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'icon',
            ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Material', 'cryptech' ),
            'param_name' => 'icon_material_design',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'material-design',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'material_design',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon FontAwesome', 'cryptech' ),
            'param_name' => 'icon_fontawesome',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'fontawesome',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon ET Line', 'cryptech' ),
            'param_name' => 'icon_etline',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'etline',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'etline',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
            'group' => esc_html__('Icon', 'cryptech'),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Font Size', 'cryptech'),
            'param_name' => 'icon_font_size',
            'description' => 'Enter px, em',
            'group' => esc_html__('Icon', 'cryptech'),
            'dependency' => array(
                'element' => 'icon_type',
                'value' => 'icon',
            ),
        ),

        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Icon Align', 'cryptech'),
            'param_name' => 'icon_align',
            'value' => array(
                'Left' => 'icon-left',        
                'Right' => 'icon-right',        
            ),
            'group' => esc_html__('Icon', 'cryptech'),
        ), 

        /* Extra */
        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
            "group"      => esc_html__("Extra", "cryptech"),
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            "group" => esc_html__("Extra", 'cryptech'),
        ) 
    )
));

class WPBakeryShortCode_cms_button extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>