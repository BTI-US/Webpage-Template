<?php
/*
 * VC
 */
vc_add_param("vc_row", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Custom Style", 'cryptech'),
    "param_name" => "cms_row_class",
    "value" => array(
        'None' => '', 
        'Row Overlay' => 'row-overlay',
        'Row Background Color Primary' => 'bg-primary', 
        'Row Background Color Primary Gradient' => 'bg-gradient', 
        'Row Visible' => 'row-visible',
    ),
    "group" => esc_html__("Customs", 'cryptech'),   
));

vc_add_param("vc_column", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Custom Style", 'cryptech'),
    "param_name" => "cms_column_class",
    "value" => array(
        'None' => '',
        'Column Overlay' => 'col-overlay', 
        'Remove Padding (Left/Right) Large Devices ( < 1199px ) to 15px' => 'rm-padding-lg',
        'Remove Padding (Left/Right) Medium Devices ( < 991px ) to 15px' => 'rm-padding-md',
        'Remove Padding (Left/Right) Small Devices ( < 767px ) to 15px' => 'rm-padding-sm',
        'Remove Padding (Left/Right) Mini Devices ( < 575px ) to 15px' => 'rm-padding-xs',
        'Remove Margin Small Devices Small Devices ( < 767px ) to 0px' => 'rm-margin-sm',
    ),   
    "group" => esc_html__("Customs", 'cryptech'), 
));

vc_add_param("vc_column", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Column Offset", 'cryptech'),
    "param_name" => "cms_column_offset",
    "value" => array(
        'None' => '',
        'Offset Container Left' => 'col-offset-left', 
        'Offset Container Right' => 'col-offset-right'
    ),   
    "group" => esc_html__("Customs", 'cryptech'), 
));

vc_add_param("vc_column_inner", array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Custom Style", 'cryptech'),
    "param_name" => "cms_column_inner_class",
    "value" => array(
        'None' => '', 
        'Remove Padding (Left/Right) Large Devices ( < 1199px ) to 15px' => 'rm-padding-lg',
        'Remove Padding (Left/Right) Medium Devices ( < 991px ) to 15px' => 'rm-padding-md',
        'Remove Padding (Left/Right) Small Devices ( < 767px ) to 15px' => 'rm-padding-sm',
        'Remove Padding (Left/Right) Mini Devices ( < 575px ) to 15px' => 'rm-padding-xs',
        'Remove Margin Small Devices Small Devices ( < 767px ) to 0px' => 'rm-margin-sm',
    ),   
    "group" => esc_html__("Customs", 'cryptech'), 
));

vc_add_param("vc_column_inner", 
    array(
        'type' => 'animation_style',
        'heading' => esc_html__( 'Animation', 'cryptech' ),
        'param_name' => 'animation_column',
        'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
        'admin_label' => false,
        'weight' => 0,
        "group" => esc_html__("Customs", 'cryptech'),
    )
);
