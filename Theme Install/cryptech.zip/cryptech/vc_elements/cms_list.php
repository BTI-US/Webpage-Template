<?php
vc_map(array(
    'name' => 'Lists',
    'base' => 'cms_list',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(

        array(
            'type' => 'param_group',
            'heading' => esc_html__( 'Lists', 'cryptech' ),
            'param_name' => 'cms_list',
            'description' => esc_html__( 'Enter values for list item', 'cryptech' ),
            'value' => '',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' =>esc_html__('List item', 'cryptech'),
                    'param_name' => 'cms_list_item',
                    'admin_label' => true,
                ), 
            ),
        ),

        array(
            'type' => 'textfield',
            'heading' =>esc_html__('Font Size', 'cryptech'),
            'param_name' => 'cms_list_fontsize',
            'value' => '',
            'description' => 'Enter: ...px;'
        ),
        array(
            'type' => 'textfield',
            'heading' =>esc_html__('Line Height', 'cryptech'),
            'param_name' => 'cms_list_lineheight',
            'value' => '',
            'description' => 'Enter: ...px;'
        ),
        array(
            'type' => 'colorpicker',
            'heading' =>esc_html__('List item Color', 'cryptech'),
            'param_name' => 'cms_list_color',
            'value' => '',
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Style', 'cryptech'),
            'param_name' => 'style',
            'value' => array(
                'Check' => 'check',        
                'Round' => 'round',        
            ),
        ),  
    )
));

class WPBakeryShortCode_cms_list extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}
?>