<?php
vc_map(array(
    "name" => 'Bitcoin Donation',
    "base" => "cms_bitcoin_donation",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(

        array(
            "type" => "textarea",
            "heading" => esc_html__("Title", 'cryptech'),
            "param_name" => "title",
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__("Wallet Bitcon", 'cryptech'),
            "param_name" => "wallet_bitcon",
        ),
        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'QR', 'cryptech' ),
            'param_name' => 'qr_code',
            'value' => '',
            'description' => esc_html__( 'Select icon image from media library.', 'cryptech' ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
            "group"            => esc_html__("Extra", "cryptech")
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            'group' => esc_html__('Extra', 'cryptech'),
        ),
    )
));

class WPBakeryShortCode_cms_bitcoin_donation extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>