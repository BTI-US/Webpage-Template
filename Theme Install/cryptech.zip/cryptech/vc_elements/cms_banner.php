<?php
vc_map(array(
    'name' => 'Banner',
    'base' => 'cms_banner',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(

        array(
            'type' => 'attach_image',
            'heading' => esc_html__( 'Image', 'cryptech' ),
            'param_name' => 'image',
            'value' => '',
            'description' => esc_html__( 'Select image from media library.', 'cryptech' ),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__('Banner Position', 'cryptech'),
            'param_name' => 'banner_position',
            'value' => array(
                'Top Right' => 'top-right',
                'Bottom Left' => 'bottom-left',
            ),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__('Banner Size', 'cryptech'),
            'param_name' => 'banner_size',
            'value' => array(
                'Small' => 'size-small',
                'Medium' => 'size-medium',
            ),
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Banner Background Color", 'cryptech'),
            "param_name" => "banner_bg_color",
            "value" => "",
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra class name', 'cryptech' ),
            'param_name' => 'el_class',
            'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
            'group' => esc_html__('Extra', 'cryptech')
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            'group' => esc_html__('Extra', 'cryptech')
        ),
    )
));

class WPBakeryShortCode_cms_banner extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>