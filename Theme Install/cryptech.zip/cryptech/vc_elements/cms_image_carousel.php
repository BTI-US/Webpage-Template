<?php
$args = array(
    "name" => 'Image Carousel',
    "base" => "cms_image_carousel",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(
        
        array(
            'type' => 'param_group',
            "heading" => esc_html__( 'Image List', 'cryptech' ),
            'value' => '',
            'param_name' => 'image_list',
            'params' => array(
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Image', 'cryptech' ),
                    'param_name' => 'image',
                    'value' => '',
                    'description' => esc_html__( 'Select image from media library.', 'cryptech' ),
                    'admin_label' => true,
                ),
                array(
                    'type' => 'vc_link',
                    'class' => '',
                    'heading' => esc_html__('Link', 'cryptech'),
                    'param_name' => 'item_link',
                    'value' => '',
                ),
            ),
        ),


    ));

$args = cryptech_add_vc_extra_param($args);
vc_map($args);

class WPBakeryShortCode_cms_image_carousel extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>