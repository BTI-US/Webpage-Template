<?php
vc_map(array(
    "name" => 'Bitcoin Price Chart',
    "base" => "cms_bitcoin_price_chart",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('CSH Crypto Shortcodes', 'cryptech'),
    "params" => array(
        /* Template */
        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            "shortcode" => "cms_bitcoin_price_chart",
            "heading" => esc_html__("Shortcode Template", 'cryptech'),
            "admin_label" => true,
            "group" => esc_html__("Template", 'cryptech'),
            'std' => 'cms_bitcoin_price_chart.php'
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
            "group"            => esc_html__("Template", "cryptech")
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            "group" => esc_html__("Template", 'cryptech'),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Chart Styles", 'cryptech'),
            'param_name' => 'chart_styles',
            'value' => array(
                'Dark' => 'chart_dark',                
                'Light' => 'chart_light',      
            ),
            'dependency' => array(
                'element' => 'cms_template',
                'value' => 'cms_bitcoin_price_chart.php',
            ),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__("Simple Bitcoin Type", 'cryptech'),
            'param_name' => 'simple_bitcoin_type',
            'value' => array(
                'BTC/USD' => 'eur',     
                'BTC/EUR' => 'eur',     
                'BTC/JPY' => 'btc-jpy',     
            ),
            'dependency' => array(
                'element' => 'cms_template',
                'value' => 'cms_bitcoin_price_chart--layout2.php',
            ),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Simple Bitcoin Style", 'cryptech'),
            'param_name' => 'simple_bitcoin_styles',
            'value' => array(
                'Dark' => 'simple_dark',                
                'Light' => 'simple_light',      
            ),
            'dependency' => array(
                'element' => 'cms_template',
                'value' => 'cms_bitcoin_price_chart--layout2.php',
            ),
        ),
    )
));

class WPBakeryShortCode_cms_bitcoin_price_chart extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
} ?>