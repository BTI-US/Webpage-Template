<?php
    if(class_exists('WPCF7')) {
        $cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );
        $contact_forms = array();
        if ( $cf7 ) {
            foreach ( $cf7 as $cform ) {
                $contact_forms[ $cform->post_title ] = $cform->ID;
            }
        } else {
            $contact_forms[ __( 'No contact forms found', 'cryptech' ) ] = 0;
        }

        vc_map(array(
            'name' => 'Contact Form',
            'base' => 'cms_contact_form',
            'icon' => 'cs_icon_for_vc',
            'class' => 'cms-vc-icon',
            'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
            'params' => array(
                array(
                    'type' => 'cms_template_img',
                    'param_name' => 'cms_template',
                    'shortcode' => 'cms_contact_form',
                    'heading' => esc_html__('Shortcode Template', 'cryptech'),
                    'admin_label' => true,
                    'std' => 'cms_contact_form.php',
                    'group' => esc_html__('Template', 'cryptech'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Title', 'cryptech'),
                    'param_name' => 'el_title',
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => __( 'Select contact form', 'cryptech' ),
                    'param_name' => 'id',
                    'value' => $contact_forms,
                    'save_always' => true,
                    'description' => __( 'Choose previously created contact form from the drop down list.', 'cryptech' ),
                ),
                array(    
                    'type' => 'dropdown',
                    'heading' => esc_html__('Styles', 'cryptech'),
                    'param_name' => 'style',
                    'value' => array(  
                        'Default' => 'default',                       
                        'Box' => 'box',         
                    ),
                    "dependency" => array(
                        "element"=>"cms_template",
                        "value"=>array(
                            "cms_contact_form.php",
                        )
                    ),
                ),

                array(    
                    'type' => 'dropdown',
                    'heading' => esc_html__('Styles', 'cryptech'),
                    'param_name' => 'style_l2',
                    'value' => array(  
                        'Primary' => 'style-primary',                       
                        'Classic' => 'style-classic',         
                    ),
                    "dependency" => array(
                        "element"=>"cms_template",
                        "value"=>array(
                            "cms_contact_form--layout2.php",
                        )
                    ),
                ),
                /* Extra */
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'cryptech' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
                    'group' => esc_html__('Extra', 'cryptech'),
                ),
                array(
                    'type' => 'animation_style',
                    'heading' => esc_html__( 'Animation Style', 'cryptech' ),
                    'param_name' => 'animation',
                    'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
                    'admin_label' => false,
                    'weight' => 0,
                    'group' => esc_html__('Extra', 'cryptech'),
                ),
            )
        ));

        class WPBakeryShortCode_cms_contact_form extends CmsShortCode
        {

            protected function content($atts, $content = null)
            {
                return parent::content($atts, $content);
            }
        }
    }
?>