<?php
vc_map(
    array(
        'name'     => esc_html__('Demos Grid', 'cryptech'),
        'base'     => 'cms_demo_grid',
        'class'    => 'cms-vc-icon',
        'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
        'params'   => array(
            array(
                'type' => 'param_group',
                'heading' => esc_html__( 'Content', 'cryptech' ),
                'param_name' => 'content_list',
                'description' => esc_html__( 'Enter values for team item', 'cryptech' ),
                'value' => '',
                'group' => esc_html__('Source Settings', 'cryptech'),
                'params' => array(
                    array(
                        'type' => 'attach_image',
                        'heading' => esc_html__( 'Image', 'cryptech' ),
                        'param_name' => 'image',
                        'value' => '',
                        'description' => esc_html__( 'Select image from media library.', 'cryptech' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' =>esc_html__('Title', 'cryptech'),
                        'param_name' => 'title',
                        'admin_label' => true,
                    ),
                    array(
                        'type' => 'vc_link',
                        'class' => '',
                        'heading' => esc_html__('Link', 'cryptech'),
                        'param_name' => 'item_link',
                        'value' => '',
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Readmore Text', 'cryptech'),
                        'param_name' => 'readmore_text',
                    ),
                ),
            ),
            array(
                'type'             => 'dropdown',
                'heading'          => esc_html__('Columns XS Devices', 'cryptech'),
                'param_name'       => 'col_xs',
                'edit_field_class' => 'vc_col-sm-3 vc_column',
                'value'            => array(1, 2, 3, 4, 6, 12),
                'std'              => 1,
                'group'            => esc_html__('Grid Settings', 'cryptech')
            ),
            array(
                'type'             => 'dropdown',
                'heading'          => esc_html__('Columns SM Devices', 'cryptech'),
                'param_name'       => 'col_sm',
                'edit_field_class' => 'vc_col-sm-3 vc_column',
                'value'            => array(1, 2, 3, 4, 6, 12),
                'std'              => 2,
                'group'            => esc_html__('Grid Settings', 'cryptech')
            ),
            array(
                'type'             => 'dropdown',
                'heading'          => esc_html__('Columns MD Devices', 'cryptech'),
                'param_name'       => 'col_md',
                'edit_field_class' => 'vc_col-sm-3 vc_column',
                'value'            => array(1, 2, 3, 4, 6, 12),
                'std'              => 3,
                'group'            => esc_html__('Grid Settings', 'cryptech')
            ),
            array(
                'type'             => 'dropdown',
                'heading'          => esc_html__('Columns LG Devices', 'cryptech'),
                'param_name'       => 'col_lg',
                'edit_field_class' => 'vc_col-sm-3 vc_column',
                'value'            => array(1, 2, 3, 4, 6, 12),
                'std'              => 4,
                'group'            => esc_html__('Grid Settings', 'cryptech')
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Extra class name', 'cryptech' ),
                'param_name' => 'el_class',
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
                'group'            => esc_html__('Grid Settings', 'cryptech')
            ),
        )
    )
);

class WPBakeryShortCode_cms_demo_grid extends CmsShortCode
{
    protected function content($atts, $content = null)
    {
        $html_id = cmsHtmlID('cms-grid-demo');
        $atts['html_id'] = $html_id;
        return parent::content($atts, $content);
    }
}

?>