<?php
vc_map(array(
    'name' => 'Video',
    'base' => 'cms_video',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(

        /* Template */
        array(
            'type' => 'cms_template_img',
            'param_name' => 'cms_template',
            'shortcode' => 'cms_video',
            'heading' => esc_html__('Shortcode Template', 'cryptech'),
            'admin_label' => true,
            'group' => esc_html__('Template', 'cryptech'),
            'std' => 'cms_video.php'
        ),
        array(
            'type' => 'textfield',
            'heading' => __ ( 'Video Url', 'cryptech' ),
            'param_name' => 'video_url',
            'value' => 'https://www.youtube.com/watch?v=ytPzZBDbpTE',
        ),
        array(
            'type' => 'textfield',
            'heading' => __ ( 'Button Play Text', 'cryptech' ),
            'param_name' => 'btn_video_text',
            'value' => '',
        ),
        array(
            'type' => 'attach_image',
            'heading' => __ ( 'Box Video Background Image', 'cryptech' ),
            'param_name' => 'video_bg_image',
            'value' => '',
        ),
        array(
            'type' => 'textfield',
            'heading' => __ ( 'Box Video Height', 'cryptech' ),
            'param_name' => 'video_height',
            'value' => '',
            'description' => 'Enter: ..px (Default 485px)',
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_video.php',
                )
            ),
        ),
        array(
            'type'       => 'dropdown',
            'heading'    => esc_html__('Show Border Box', 'cryptech'),
            'param_name' => 'border_box',
            'value'      => array(
                'No'   => 'no-border-box',
                'Show' => 'border-box',
            ),
            'dependency' => array(
                'element'=>'cms_template',
                'value'=>array(
                    'cms_video.php',
                )
            ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra class name', 'cryptech' ),
            'param_name' => 'el_class',
            'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
            'group'            => esc_html__('Extra', 'cryptech')
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            'group' => esc_html__('Extra', 'cryptech'),
        ),
    )
));

class WPBakeryShortCode_cms_video extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>