<?php
vc_map(
    array(
        'name'     => esc_html__('Team Member', 'cryptech'),
        'base'     => 'cms_team_member',
        'class' => 'cms-vc-icon',
        'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
        'params'   => array(
            array(
                'type' => 'cms_template_img',
                'param_name' => 'cms_template',
                'shortcode' => 'cms_team_member',
                'heading' => esc_html__('Shortcode Template', 'cryptech'),
                'admin_label' => true,
                'group' => esc_html__('Template', 'cryptech'),
            ),
            
            /* Source Settings */
            array(
                'type' => 'textfield',
                'heading' =>esc_html__('Title', 'cryptech'),
                'param_name' => 'title',
                'admin_label' => true,
                'group' => esc_html__('Source Settings', 'cryptech'),
            ), 
            array(
                'type' => 'textfield',
                'heading' =>esc_html__('Position', 'cryptech'),
                'param_name' => 'position',
                'group' => esc_html__('Source Settings', 'cryptech'),
            ), 
            array(
                'type' => 'attach_image',
                'heading' => esc_html__( 'Image', 'cryptech' ),
                'param_name' => 'image',
                'value' => '',
                'description' => esc_html__( 'Select image from media library.', 'cryptech' ),
                'group' => esc_html__('Source Settings', 'cryptech'),
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__( 'Social', 'cryptech' ),
                'param_name' => 'social',
                'description' => esc_html__( 'Enter values for team item', 'cryptech' ),
                'value' => '',
                'group' => esc_html__('Source Settings', 'cryptech'),
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__( 'Icon', 'cryptech' ),
                        'param_name' => 'icon',
                        'value' => '',
                        'settings' => array(
                            'emptyIcon' => true,
                            'type' => 'fontawesome',
                            'iconsPerPage' => 200,
                        ),
                        'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' =>esc_html__('Link', 'cryptech'),
                        'param_name' => 'social_link',
                        'admin_label' => true,
                    ), 
                ),
            ),
            
            /* Extra */
            array(
                'type' => 'textfield',
                'heading' => esc_html__( 'Extra class name', 'cryptech' ),
                'param_name' => 'el_class',
                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
                'group'            => esc_html__('Extra', 'cryptech')
            ),
            array(
                'type' => 'animation_style',
                'heading' => esc_html__( 'Animation Style', 'cryptech' ),
                'param_name' => 'animation',
                'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
                'admin_label' => false,
                'weight' => 0,
                "group" => esc_html__("Extra", 'cryptech'),
            ),
        )
    )
);

class WPBakeryShortCode_cms_team_member extends CmsShortCode
{
    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>