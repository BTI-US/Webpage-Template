<?php
vc_map(array(
    "name" => 'Heading',
    "base" => "cms_heading",
    "icon" => "cs_icon_for_vc",
    'class' => 'cms-vc-icon',
    "category" => esc_html__('7oroof Shortcodes', 'cryptech'),
    "params" => array(
        array(
            "type" => "textarea",
            "heading" => esc_html__( 'Text', 'cryptech' ),
            "param_name" => "text",
            "value" => '',
            'admin_label' => true,
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Element tag", 'cryptech'),
            'param_name' => 'tag',
            'value' => array(
                'h1' => 'h1',
                'h2' => 'h2',
                'h3' => 'h3',
                'h4' => 'h4',
                'h5' => 'h5',
                'h6' => 'h6',
                'p' => 'p',
                'div' => 'div',
            ),
            'std' => 'h3',
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Text align large", 'cryptech'),
            'param_name' => 'align_lg',
            'value' => array(  
                'left' => 'align-left',                       
                'right' => 'align-right',
                'center' => 'align-center',         
            ),
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Text align medium", 'cryptech'),
            'param_name' => 'align_md',
            'value' => array(  
                'left' => 'align-left-md',                       
                'right' => 'align-right-md',
                'center' => 'align-center-md',         
            ),
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Text align small", 'cryptech'),
            'param_name' => 'align_sm',
            'value' => array(                       
                'left' => 'align-left-sm',                       
                'right' => 'align-right-sm',
                'center' => 'align-center-sm',         
            ),
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Text align mini", 'cryptech'),
            'param_name' => 'align_xs',
            'value' => array(  
                'left' => 'align-left-xs',                       
                'right' => 'align-right-xs',
                'center' => 'align-center-xs',         
            ),
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin top", 'cryptech'),
            "param_name" => "margin_top",
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin right", 'cryptech'),
            "param_name" => "margin_right",
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin bottom", 'cryptech'),
            "param_name" => "margin_bottom",
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Margin left", 'cryptech'),
            "param_name" => "margin_left",
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),

        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Font size large', 'cryptech' ),
            "param_name" => "font_size",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Font size medium', 'cryptech' ),
            "param_name" => "font_size_md",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Font size small', 'cryptech' ),
            "param_name" => "font_size_sm",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Font size mini', 'cryptech' ),
            "param_name" => "font_size_xs",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),

        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Line height large', 'cryptech' ),
            "param_name" => "line_height",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Line height medium', 'cryptech' ),
            "param_name" => "line_height_md",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Line height small', 'cryptech' ),
            "param_name" => "line_height_sm",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Line height mini', 'cryptech' ),
            "param_name" => "line_height_xs",
            "value" => '',
            "description" => "Enter: ..px",
            "edit_field_class" => "vc_col-sm-3 vc_column",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Font Weight", 'cryptech'),
            'param_name' => 'font_weight',
            'value' => array(
                'SemiBold' => '600',
                'Normal' => '400',
                'Medium' => '500',
                'Bold' => '700',
            ),
            'std' => '600',
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Font Style", 'cryptech'),
            'param_name' => 'h_font_style',
            'value' => array(
                'Italic' => 'italic',
                'Normal' => 'normal',
            ),
            'std' => '600',
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Letter Spacing', 'cryptech' ),
            "param_name" => "letter_spacing",
            "value" => '',
            "description" => "Enter: ..px, ...em",
            "group"      => esc_html__("Title", "cryptech"),
        ),

        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Text Color", 'cryptech'),
            "param_name" => "text_color",
            "value" => "",
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__("Custom Google Fonts", 'cryptech'),
            'param_name' => 'custom_fonts',
            'value' => array(
                'No' => 'false',
                'Yes' => 'true',
            ),
            "group"      => esc_html__("Title", "cryptech"),
        ),
        array(
            'type' => 'google_fonts',
            'param_name' => 'google_fonts',
            'value' => 'font_family:Abril%20Fatface%3Aregular|font_style:400%20regular%3A400%3Anormal',
            'settings' => array(
                'fields' => array(
                    'font_family_description' => esc_html__( 'Select font family.', 'cryptech' ),
                    'font_style_description' => esc_html__( 'Select font styling.', 'cryptech' ),
                ),
            ),
            "dependency" => array(
                "element"=>"custom_fonts",
                "value"=>array(
                    "true",
                )
            ),
        ),
         array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Divider", 'cryptech'),
            'param_name' => 'title_divider',
            'value' => array(
                'Hide' => 'no-divider',
                'Show' => 'show-divider',
            ),
            'std' => '600',
            "group"      => esc_html__("Title", "cryptech"),
        ),
        /* Sub Title */
        array(
            "type" => "textfield",
            "heading" => esc_html__("Sub Title", 'cryptech'),
            "param_name" => "sub_title",
            "group"      => esc_html__("Sub Title", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Font Size', 'cryptech' ),
            "param_name" => "sub_title_font_size",
            "value" => '',
            "description" => "Enter: ..px",
            "group"      => esc_html__("Sub Title", "cryptech"),
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", 'cryptech'),
            "param_name" => "sub_title_color",
            "value" => "",
            "group"      => esc_html__("Sub Title", "cryptech"),
        ),

        /* Description */
        array(
            "type" => "textarea",
            "heading" => esc_html__( 'Description', 'cryptech' ),
            "param_name" => "description",
            "value" => '',
            "group"      => esc_html__("Description", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Max Width", 'cryptech'),
            'param_name' => 'description_m_width',
            'value' => array(  
                'No' => 'h-full-width',                       
                'Yes' => 'h-boxed',         
            ),
            "group"      => esc_html__("Description", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Font Size', 'cryptech' ),
            "param_name" => "description_font_size",
            "value" => '',
            "description" => "Enter: ..px",
            "group"      => esc_html__("Description", "cryptech"),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__( 'Line Height', 'cryptech' ),
            "param_name" => "description_line_height",
            "value" => '',
            "description" => "Enter: ..px",
            "group"      => esc_html__("Description", "cryptech"),
        ),
        array(
            "type" => "colorpicker",
            "heading" => esc_html__("Color", 'cryptech'),
            "param_name" => "description_color",
            "value" => "",
            "group"      => esc_html__("Description", "cryptech"),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Font Weight", 'cryptech'),
            'param_name' => 'desc_font_weight',
            'value' => array(
                'Normal' => '',
                'Medium' => '500',
                'SemiBold' => '600',
                'Bold' => '700',
            ),
            'std' => '',
            "group"      => esc_html__("Description", "cryptech"),
        ),
        /* Extra */
        array(
            "type" => "textfield",
            "heading" => esc_html__( "Extra class name", "cryptech" ),
            "param_name" => "el_class",
            "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in Custom CSS.", "cryptech" ),
            "group"      => esc_html__("Extra", "cryptech"),
        ),
        array(
            'type' => 'animation_style',
            'heading' => esc_html__( 'Animation Style', 'cryptech' ),
            'param_name' => 'animation',
            'description' => esc_html__( 'Choose your animation style', 'cryptech' ),
            'admin_label' => false,
            'weight' => 0,
            "group" => esc_html__("Extra", 'cryptech'),
        ),
        
    )
));

class WPBakeryShortCode_cms_heading extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        $html_id = cmsHtmlID('cms-heading');
        $atts['html_id'] = $html_id;
        return parent::content($atts, $content);
    }
}

?>