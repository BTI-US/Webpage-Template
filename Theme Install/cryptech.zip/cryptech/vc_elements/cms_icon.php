<?php
vc_map(array(
    'name' => 'Icon',
    'base' => 'cms_icon',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(
        /* Icon */
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon Library', 'cryptech' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'cryptech' ) => 'fontawesome',
                esc_html__( 'Material Design', 'cryptech' ) => 'material_design',
                esc_html__( 'ET Line', 'cryptech' ) => 'etline',
            ),
            'param_name' => 'icon_list',
            'description' => esc_html__( 'Select icon library.', 'cryptech' ),
            'admin_label' => true,
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Material', 'cryptech' ),
            'param_name' => 'icon_material_design',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'material-design',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'material_design',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon FontAwesome', 'cryptech' ),
            'param_name' => 'icon_fontawesome',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'fontawesome',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon ET Line', 'cryptech' ),
            'param_name' => 'icon_etline',
            'settings' => array(
                'emptyIcon' => true,
                'type' => 'etline',
                'iconsPerPage' => 200,
            ),
            'dependency' => array(
                'element' => 'icon_list',
                'value' => 'etline',
            ),
            'description' => esc_html__( 'Select icon from library.', 'cryptech' ),
        ),

        array(
            'type' => 'vc_link',
            'class' => '',
            'heading' => esc_html__('Icon Link', 'cryptech'),
            'param_name' => 'icon_link',
            'value' => '',
        ),

        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Icon Color', 'cryptech'),
            'param_name' => 'icon_color',
            'value' => '',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Background Color', 'cryptech'),
            'param_name' => 'icon_bg_color',
            'value' => '',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Icon Font Size', 'cryptech'),
            'param_name' => 'icon_font_size',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Icon Line Height', 'cryptech'),
            'param_name' => 'icon_line_height',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),

        array(
            'type' => 'textfield',
            'heading' => esc_html__('Icon Border Width', 'cryptech'),
            'param_name' => 'icon_border_width',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-4 vc_column',
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__("Icon Border Style", 'cryptech'),
            'param_name' => 'icon_border_style',
            'value' => array(  
                'None' => '',         
                'Solid' => 'solid',         
                'Dotted' => 'dotted',         
                'Dashed' => 'dashed',         
                'Double' => 'double',         
                'Groove' => 'groove',         
                'Ridge' => 'ridge',         
                'Inset' => 'inset',         
                'Outset' => 'outset',         
                'Initial' => 'initial',         
                'Inherit' => 'inherit',         
            ),
            "edit_field_class" => "vc_col-sm-4 vc_column",
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Icon Border Color', 'cryptech'),
            'param_name' => 'icon_border_color',
            'value' => '',
            'edit_field_class' => 'vc_col-sm-4 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Icon Width', 'cryptech'),
            'param_name' => 'icon_width',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-6 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Icon Height', 'cryptech'),
            'param_name' => 'icon_height',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-6 vc_column',
        ),

        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Icon Color', 'cryptech'),
            'param_name' => 'icon_color_hover',
            'value' => '',
            "group"      => esc_html__("Icon Hover", "cryptech"),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Background Color', 'cryptech'),
            'param_name' => 'icon_bg_color_hover',
            'value' => '',
            "group"      => esc_html__("Icon Hover", "cryptech"),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Border Color', 'cryptech'),
            'param_name' => 'icon_border_color_hover',
            'value' => '',
            "group"      => esc_html__("Icon Hover", "cryptech"),
        ),

        /* Padding */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Top', 'cryptech'),
            'param_name' => 'padding_top',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Right', 'cryptech'),
            'param_name' => 'padding_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Bottom', 'cryptech'),
            'param_name' => 'padding_bottom',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Padding Left', 'cryptech'),
            'param_name' => 'padding_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),

        /* Margin */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Top', 'cryptech'),
            'param_name' => 'margin_top',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Right', 'cryptech'),
            'param_name' => 'margin_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Bottom', 'cryptech'),
            'param_name' => 'margin_bottom',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Margin Left', 'cryptech'),
            'param_name' => 'margin_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),

        /* Border radius */
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Top Left', 'cryptech'),
            'param_name' => 'br_top_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Top Right', 'cryptech'),
            'param_name' => 'br_top_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Bottom Right', 'cryptech'),
            'param_name' => 'br_bottom_right',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Radius Bottom Left', 'cryptech'),
            'param_name' => 'br_bottom_left',
            'description' => 'Enter px, em',
            'edit_field_class' => 'vc_col-sm-3 vc_column',
        ),

        /* Extra */
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Extra class name', 'cryptech' ),
            'param_name' => 'el_class',
            'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in Custom CSS.', 'cryptech' ),
        ),
    )
));

class WPBakeryShortCode_cms_icon extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>