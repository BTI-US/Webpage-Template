<?php
vc_map(array(
    'name' => 'Row Overlay',
    'base' => 'cms_overlay',
    'icon' => 'cs_icon_for_vc',
    'class' => 'cms-vc-icon',
    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
    'params' => array(
        
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Type', 'cryptech'),
            'param_name' => 'color',
            'value' => array(  
                'Regular' => 'regular',         
                'Gradient' => 'gradient',         
            ),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Flip', 'cryptech'),
            'param_name' => 'flip',
            'value' => array(  
                'Horizontal' => 'horizontal',         
                'Vertical' => 'vertical',         
            ),
            'dependency' => array(
                'element'=>'color',
                'value'=>array(
                    'gradient',
                )
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Color', 'cryptech'),
            'param_name' => 'regular_color',
            'value' => '',
            'dependency' => array(
                'element'=>'color',
                'value'=>array(
                    'regular',
                )
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Color 1', 'cryptech'),
            'param_name' => 'gradient_color1',
            'value' => '',
            'edit_field_class' => 'vc_col-sm-6 vc_column',
            'dependency' => array(
                'element'=>'color',
                'value'=>array(
                    'gradient',
                )
            ),
        ),
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__('Color 2', 'cryptech'),
            'param_name' => 'gradient_color2',
            'value' => '',
            'edit_field_class' => 'vc_col-sm-6 vc_column',
            'dependency' => array(
                'element'=>'color',
                'value'=>array(
                    'gradient',
                )
            ),
        ),
        array(    
            'type' => 'dropdown',
            'heading' => esc_html__('Position', 'cryptech'),
            'param_name' => 'position',
            'value' => array(  
                'Bottom' => 'bottom',         
                'Top' => 'top',         
            ),
            'dependency' => array(
                'element'=>'color',
                'value'=>array(
                    'gradient',
                )
            ),
        ),
        array(
            'type' => 'textfield',
            'heading' => esc_html__('Height', 'cryptech'),
            'param_name' => 'height',
            'description' => 'px, %, em: Default height 100%',
            'dependency' => array(
                'element'=>'color',
                'value'=>array(
                    'gradient',
                )
            ),
        ),
        
    )
));

class WPBakeryShortCode_cms_overlay extends CmsShortCode
{

    protected function content($atts, $content = null)
    {
        return parent::content($atts, $content);
    }
}

?>