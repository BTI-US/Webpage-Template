<?php
vc_map(
	array(
		'name' => esc_html__('History', 'cryptech'),
	    'base' => 'cms_history',
	    'class' => 'cms-vc-icon',
	    'category' => esc_html__('7oroof Shortcodes', 'cryptech'),
	    'params' => array(
	    	array(
                'type' => 'cms_template_img',
                'param_name' => 'cms_template',
                'shortcode' => 'cms_history',
                'heading' => esc_html__('Shortcode Template', 'cryptech'),
                'admin_label' => true,
                'std' => 'cms_history.php',
                'group' => esc_html__('Template', 'cryptech'),
            ),
            array(
	            'type' => 'textfield',
	            'heading' => esc_html__('Extra Class', 'cryptech'),
	            'param_name' => 'el_class',
	            'value' => '',
	            'group' => esc_html__('Template', 'cryptech')
	        ),
	        array(
	            'type' => 'param_group',
	            'heading' => esc_html__( 'History Lists', 'cryptech' ),
	            'param_name' => 'cms_history_list',
	            'value' => '',
	            'params' => array(
	            	array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Day', 'cryptech'),
			            'param_name' => 'day',
			            'value' => '',
			            'admin_label' => true,
			            'description' => esc_html__('Ex: 22', 'cryptech'),
			        ),
	            	array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Month/Year', 'cryptech'),
			            'param_name' => 'year',
			            'value' => '',
			            'admin_label' => true,
			            'description' => esc_html__('Ex: Oct, 2017', 'cryptech'),
			        ),
	                array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Title', 'cryptech'),
			            'param_name' => 'title',
			            'value' => '',
			            'admin_label' => true,
			        ),
			        array(
			            'type' => 'textarea',
			            'heading' => esc_html__( 'Content', 'cryptech' ),
			            'param_name' => 'desc',
			            'value' => '',
			        ),
	            ),
	        ),
	    )
	)
);
class WPBakeryShortCode_cms_history extends CmsShortCode{
	protected function content($atts, $content = null){
		return parent::content($atts, $content);
	}
}

?>